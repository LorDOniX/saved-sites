<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; padding: 4px;}
      td.center {text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Bonusy p�edm�t�</h2>
   <p>&nbsp;</p>
   
   <p>Ve h�e m�te k dispozici �adu p�edm�t�, kter� m��e postava p�i sv�m cestov�n� pou��vat. Jsou to zbran�, zbroje, prsteny, amulety, knihy kouzel, svitky, lektvary a r�zn� �kolov� p�edm�ty. Ka�d� z dan�ch p�edm�t� m��e krom� sv�ch z�kladn�ch vlastnost� disponovat je�t� ur�it�m bonusem nav�c. Bonus se projevuje bu�to jako p��davek do z�kladn�ch a sekund�rn�ch vlastnost� postavy (prim�rn� atributy, zdrav�, mana, t��da zbroje, odolnosti) anebo jako bonus k dovednosti, ke zran�n�, k magii aj. Velikost bonusu m��e b�t prom�nn� (viz prvn� tabulka) nebo m��e b�t bonus konstantn� (viz druh� tabulka).</p>
   <p>V p��pad� bonus� k z�kladn�m vlastnostem postavy (tak� nap�. pro TZ, zdrav� a manu) se bonusy jednotliv�ch p�edm�t� vz�jemn� s��taj�. V p��pad� bonus� k dovednostem se pak ze v�ech p�edm�t�, kter� m� postava na sob�, bere v �vahu jen p�edm�t s nejsiln�j��m bonusem - nap�. z trojice prsten� +5, +10 a +15 ke vzdu�n� magii se po��t� jen bonus +15 (tedy nikoliv cel�ch +30). Z tohoto d�vodu nem� ��dn� smysl nosit v�ce p�edm�t� se stejn�m bonusem k p��slu�n� dovednosti, ale je dobr� si vybrat jen ten nejlep��. Samoz�ejm� i tady nalezneme men�� vyj�mku. Pokud je bonusov�m p�edm�tem artefakt nebo relikvie, pak se jej� p��padn� bonus k dovednosti m��e p�i��st k ji� no�en�mu oby�ejn�mu bonusov�mu p�edm�tu - bonusy se vz�jemn� se�tou. Pokud tedy p�edchoz� �adu dopln�me o artefakt s bonusem +5 ke vzdu�n� magii, pak v�sledn� bonus bude 15 + 5 neboli +20 k magii vzduchu.</p>
   <p>P�edm�ty s bonusem je mo�n� ve h�e z�skat prohled�v�n�m truhel, mrtvol nep��tel, nakupov�n�m nebo m��ete p�edm�ty s bonusem vyr�b�t. K v�rob� p�edm�t� poslou�� jak�koliv dostate�n� kvalitn� neokouzlen� p�edm�t, na kter� pak zakouzl�me kouzlo vodn� magie O�aruj p�edm�t. V z�vislosti na �rovni dovednosti ve vodn� magii a na kvalit� p�edm�tu pak dostaneme odpov�daj�c� trval� o�arov�n�. Nekvalitn� p�edm�t se p�i pokusu o o�arov�n� rozbije. Stejn� tak rozbit� o�arovan� p�edm�t ztr�c� sv�j bonus do t� doby, ne� je znovu opraven. Krom kouzla O�aruj p�edm�t m�te k dispozici je�t� dal�� dv� kouzla. Prvn�m je Ohniv� aura, kter� na ni���ch �rovn�ch poskytuje zbrani do�asn� bonus dodate�n�ho zran�n� ohn�m, na velmistrovsk� �rovni je pak bonus trval�. Druh�m kouzlem je kouzlo Up��� zbra�, kter� zbrani p�id� up��� vlastnost, tedy zdrav� odebran� nestv��e touto zbran� je p�id�no tomu, kdo zbra� pou��v� a� do maxim�ln� hodnoty zdrav� postavy. Na velmistrovsk� �rovni se op�t jedn� o trval� efekt. Podobn�m zp�sobem jako kouzla funguj� i lektvary mistrovsk� �rovn� alchymie, kter� dod�vaj� do�asn� i magick� efekty ostatn�ch �kol magie.</p>
   <p>O�arov�n� p�edm�t� m� krom v�hod bonus� je�t� jednu v�raznou vlastnost. Okouzlen�m roste hodnota dan�ho p�edm�tu. O kolik bude vy��� pak z�vis� na s�le a mno�stv� "uv�zn�n�ho" kouzla. N�r�st ceny je u p�edm�t� s konstantn�mi bonusy st�le stejn�, u p�edm�t� s prom�nou velikost� bonusu se pak li�� pr�v� podle mno�stv� bod�, kter� do vlastnosti poskytuje. Pro p�edm�ty s prom�n�m bonusem se zav�d� tzv. jednotkov� hodnota, tedy o kolik vzroste hodnota p�edm�tu, kdy� se hodnota bonusu zv��� o jedna (viz prvn� tabulka). Nap�. v�sledn� cena �arod�jnick�ho prstenu My�len� s bonusem +5 k Intelektu bude cena prstenu + 5 x jednotkov� hodnota, tedy 1100 + 5 x 100 = 1600.</p>
   <p><span class="tucne">N�sleduj�c� tabulka uv�d� p�ehled bonus� s prom�nou velikost� bonusu:</span></p>

   <div style="text-align: center;">
   <table width="550px" celspacing="0" cellpadding="0" border="1" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;" class="center">Bonus</td>
         <td style="width: 100px;" class="center">Cena p�edm�tu se zv��� o</td>
         <td style="width: 350px;" class="center">Popis</td>
      </tr>
      <tr>
         <td>my�len�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Inteligence.</td>
      </tr>
      <tr>
         <td>�armu</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Osobnosti.</td>
      </tr>
      <tr>
         <td>vitality</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Odolnosti.</td>
      </tr>
      <tr>
         <td>p�esnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do P�esnosti.</td>
      </tr>
      <tr>
         <td>rychlosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Rychlosti.</td>
      </tr>
      <tr>
         <td>�t�st�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do �t�st�.</td>
      </tr>
      <tr>
         <td>zdrav�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Zdrav�.</td>
      </tr>
      <tr>
         <td>magie</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Many.</td>
      </tr>
      <tr>
         <td>obrany</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do T��dy zbroje.</td>
      </tr>
      <tr>
         <td>ohniv� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti ohni.</td>
      </tr>
      <tr>
         <td>vzdu�n� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti vzduchu.</td>
      </tr>
      <tr>
         <td>vodn� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti vod�.</td>
      </tr>
      <tr>
         <td>zemsk� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti zemi.</td>
      </tr>
      <tr>
         <td>my�lenkov� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti mysli.</td>
      </tr>
      <tr>
         <td>t�lesn� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti t�lu.</td>
      </tr>
      <tr>
         <td>alchymie</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Alchymie.</td>
      </tr>
      <tr>
         <td>kraden�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Kraden�.</td>
      </tr>
      <tr>
         <td>zne�kodn�n�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Odstran�n� past�.</td>
      </tr>
      <tr>
         <td>v�ci</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Identifikace v�c�.</td>
      </tr>
      <tr>
         <td>nestv�r</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Identifikace nestv�r.</td>
      </tr>
      <tr>
         <td>mistrovstv�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Mistr zbran�.</td>
      </tr>
      <tr>
         <td>uh�b�n�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Uh�b�n�.</td>
      </tr>
      <tr>
         <td>p�sti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do dovednosti Beze zbran�.</td>
      </tr>
   </table>
   </div>   
      
   <p><span class="tucne">N�sleduj�c� tabulka uv�d� p�ehled bonus� s konstantn� velikost� bonusu:</span></p>   
      
   <div style="text-align: center;">
   <table width="550px" celspacing="0" cellpadding="0" border="1" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;" class="center">Bonus</td>
         <td style="width: 100px;" class="center">Cena p�edm�tu se zv��� o</td>
         <td style="width: 350px;" class="center">Popis</td>
      </tr>
      <tr>
         <td>ochrany</td>
         <td class="center">100</td>
         <td>+10 do v�ech odolnost�.</td>
      </tr>
      <tr>
         <td>boh�</td>
         <td class="center">3000</td>
         <td>+10 do v�ech sedmi statistik.</td>
      </tr>
      <tr>
         <td>masakru</td>
         <td class="center">5000</td>
         <td>V�bu�n� dopad!</td>
      </tr>
      <tr>
         <td>chladu</td>
         <td class="center">500</td>
         <td>P�id� 3-4 body zran�n� chladem.</td>
      </tr>
      <tr>
         <td>mrazu</td>
         <td class="center">1000</td>
         <td>P�id� 6-8 bod� zran�n� chladem.</td>
      </tr>
      <tr>
         <td>ledu</td>
         <td class="center">2000</td>
         <td>P�id� 9-12 bod� zran�n� chladem.</td>
      </tr>
      <tr>
         <td>jisker</td>
         <td class="center">500</td>
         <td>P�id� 2-5 bod� zran�n� vzduchem.</td>
      </tr>
      <tr>
         <td>blesku</td>
         <td class="center">1000</td>
         <td>P�id� 4-10 bod� zran�n� vzduchem.</td>
      </tr>
      <tr>
         <td>hromu</td>
         <td class="center">2000</td>
         <td>P�id� 6-15 bod� zran�n� vzduchem.</td>
      </tr>
      <tr>
         <td>ohn�</td>
         <td class="center">500</td>
         <td>P�id� 1-6 bod� zran�n� ohn�m.</td>
      </tr>
      <tr>
         <td>plamene</td>
         <td class="center">1000</td>
         <td>P�id� 2-12 bod� zran�n� ohn�m.</td>
      </tr>
      <tr>
         <td>pekla</td>
         <td class="center">2000</td>
         <td>P�id� 3-18 bod� zran�n� ohn�m.</td>
      </tr>
      <tr>
         <td>jedu</td>
         <td class="center">500</td>
         <td>P�id� 5 bod� t�lesn�ho zran�n�.</td>
      </tr>
      <tr>
         <td>otravy</td>
         <td class="center">1000</td>
         <td>P�id� 8 bod� t�lesn�ho zran�n�.</td>
      </tr>
      <tr>
         <td>kyseliny</td>
         <td class="center">2000</td>
         <td>P�id� 12 bod� t�lesn�ho zran�n�.</td>
      </tr>
      <tr>
         <td>Up���</td>
         <td class="center">1100</td>
         <td>Vys�v� z c�le �ivoty.</td>
      </tr>
      <tr>
         <td>uzdraven�</td>
         <td class="center">200</td>
         <td>Zkracuje dobu zotaven�.</td>
      </tr>
      <tr>
         <td>imunity</td>
         <td class="center">1000</td>
         <td>Nositel je odoln� v��i nemoc�m.</td>
      </tr>
      <tr>
         <td>p���etnosti</td>
         <td class="center">1000</td>
         <td>Nositel je odoln� v��i ��lenstv�.</td>
      </tr>
      <tr>
         <td>svobody</td>
         <td class="center">2000</td>
         <td>Nositel je odoln� v��i ochromen�.</td>
      </tr>
      <tr>
         <td>protijedu</td>
         <td class="center">1000</td>
         <td>Nositel je odoln� v��i jedu.</td>
      </tr>
      <tr>
         <td>poplach�</td>
         <td class="center">500</td>
         <td>Nositel je odoln� v��i usnut�.</td>
      </tr>
      <tr>
         <td>med�zy</td>
         <td class="center">2000</td>
         <td>Nositel je odoln� v��i zkamen�n�.</td>
      </tr>
      <tr>
         <td>n�sil�</td>
         <td class="center">500</td>
         <td>Odhazuje c�l do v�t�� vzd�lenosti.</td>
      </tr>
      <tr>
         <td>moci</td>
         <td class="center">2500</td>
         <td>+5 �rovn�</td>
      </tr>
      <tr>
         <td>magie vzduchu</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel vzduchu.</td>
      </tr>
      <tr>
         <td>magie t�la</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel t�la.</td>
      </tr>
      <tr>
         <td>magie temnoty</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel temnoty.</td>
      </tr>
      <tr>
         <td>magie zem�</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel zem�.</td>
      </tr>
      <tr>
         <td>magie ohn�</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel ohn�.</td>
      </tr>
      <tr>
         <td>magie sv�tla</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel sv�tla.</td>
      </tr>
      <tr>
         <td>magie mysli</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel mysli.</td>
      </tr>
      <tr>
         <td>magie ducha</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel ducha.</td>
      </tr>
      <tr>
         <td>magie vody</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��innost kouzel vody.</td>
      </tr>
      <tr>
         <td>zlod�jstv�</td>
         <td class="center">2000</td>
         <td>Zvy�uje �ance na odstran�n� past�.</td>
      </tr>
      <tr>
         <td>kryt�</td>
         <td class="center">1000</td>
         <td>Polovi�n� zran�n� st�eln�mi �toky.</td>
      </tr>
      <tr>
         <td>regenerace</td>
         <td class="center">1000</td>
         <td>Postupn� obnovuje zdrav�.</td>
      </tr>
      <tr>
         <td>many</td>
         <td class="center">1000</td>
         <td>Postupn� obnovuje manu.</td>
      </tr>
      <tr>
         <td>Zhouba d�mon�</td>
         <td class="center">1100</td>
         <td>Dvojn�sobn� zran�n� proti d�mon�m.</td>
      </tr>
      <tr>
         <td>Zhouba drak�</td>
         <td class="center">1100</td>
         <td>Dvojn�sobn� zran�n� proti drak�m.</td>
      </tr>
      <tr>
         <td>Temnoty</td>
         <td class="center">2200</td>
         <td>Vys�v� �ivoty z ter�e �toku a zvy�uje rychlost zbran�.</td>
      </tr>
      <tr>
         <td>zhouby</td>
         <td class="center">750</td>
         <td>+1 do sedmi statistik, zdrav�, many, t��dy zbroje a odolnosti</td>
      </tr>
      <tr>
         <td>Zem�</td>
         <td class="center">2000</td>
         <td>+10 do odolnosti, t��dy zbroje a zdrav�</td>
      </tr>
      <tr>
         <td>�ivota</td>
         <td class="center">2000</td>
         <td>+10 zdrav� a postupn� obnovuje zdrav�.</td>
      </tr>
      <tr>
         <td>Lupi�sk�</td>
         <td class="center">500</td>
         <td>+5 rychlost a p�esnost.</td>
      </tr>
      <tr>
         <td>draka</td>
         <td class="center">3000</td>
         <td>P�id� 10-20 bod� zran�n� ohn�m +25 s�la.</td>
      </tr>
      <tr>
         <td>zatm�n�</td>
         <td class="center">2000</td>
         <td>+10 bod� many a postupn� obnovuje manu.</td>
      </tr>
      <tr>
         <td>golema</td>
         <td class="center">1500</td>
         <td>+15 odolnost a +5 t��da zbroje.</td>
      </tr>
      <tr>
         <td>M�s�ce</td>
         <td class="center">1000</td>
         <td>+10 inteligence a �t�st�.</td>
      </tr>
      <tr>
         <td>F�nixe</td>
         <td class="center">3000</td>
         <td>+30 odolnost proti ohni a postupn� obnovuje zdrav�.</td>
      </tr>
      <tr>
         <td>Nebe</td>
         <td class="center">2500</td>
         <td>+10 bod� many, rychlosti a inteligence.</td>
      </tr>
      <tr>
         <td>Hv�zd</td>
         <td class="center">1000</td>
         <td>+10 odolnost a p�esnost.</td>
      </tr>
      <tr>
         <td>Slunce</td>
         <td class="center">1000</td>
         <td>+10 s�la a osobnost.</td>
      </tr>
      <tr>
         <td>trola</td>
         <td class="center">1500</td>
         <td>+15 odolnost a postupn� obnovuje zdrav�.</td>
      </tr>
      <tr>
         <td>Jednoro�ce</td>
         <td class="center">1500</td>
         <td>+15 �t�st� a postupn� obnovuje manu.</td>
      </tr>
      <tr>
         <td>V�le�nick�</td>
         <td class="center">500</td>
         <td>+5 s�la a odolnost.</td>
      </tr>
      <tr>
         <td>�arod�jsk�</td>
         <td class="center">500</td>
         <td>+5 inteligence a osobnost.</td>
      </tr>
      <tr>
         <td>Staro�itn�</td>
         <td class="center">9900</td>
         <td>Zvy�uje hodnotu p�edm�tu.</td>
      </tr>
      <tr>
         <td>Rychl�</td>
         <td class="center">1100</td>
         <td>Zvy�uje rychlost zbran�.</td>
      </tr>
      <tr>
         <td>Mni�sk�</td>
         <td class="center">1500</td>
         <td>+3 do dovednost� Beze zbran� a Uh�b�n�.</td>
      </tr>
      <tr>
         <td>Zlod�jsk�</td>
         <td class="center">1500</td>
         <td>+3 do dovednost� Kraden� a Odstran�n� past�.</td>
      </tr>
      <tr>
         <td>identifikace</td>
         <td class="center">1500</td>
         <td>+3 Identifikace p�edm�t� a nestv�r.</td>
      </tr>
      <tr>
         <td>Zhouba elf�</td>
         <td class="center">1100</td>
         <td>Dvojn�sobn� zran�n� proti elf�m.</td>
      </tr>
      <tr>
         <td>Zhouba nemrtv�ch</td>
         <td class="center">1100</td>
         <td>Dvojn�sobn� zran�n� proti nemrtv�m.</td>
      </tr>
      <tr>
         <td>Davida</td>
         <td class="center">1100</td>
         <td>Dvojn�sobn� zran�n� proti Tit�n�m.</td>
      </tr>
      <tr>
         <td>hojnosti</td>
         <td class="center">2500</td>
         <td>Postupn� obnovuje zdrav� a manu.</td>
      </tr>
      <tr>
         <td>Zabij�ck�</td>
         <td class="center">1000</td>
         <td>P�id� 5 bod� zran�n� magi� t�la a +2 do dovednosti Odstran�n� past�.</td>
      </tr>
      <tr>
         <td>Barbarsk�</td>
         <td class="center">1500</td>
         <td>P�id� 6-8 bod� zran�n� chladem a +5 t��da zbroje.</td>
      </tr>
      <tr>
         <td>bou�ky</td>
         <td class="center">1500</td>
         <td>+20 odolnost proti vzduchu a polovi�n� zran�n� st�elami.</td>
      </tr>
      <tr>
         <td>oce�nu</td>
         <td class="center">1000</td>
         <td>+10 odolnost proti vod� a +2 k Alchymii.</td>
      </tr>
      <tr>
         <td>vodn� ch�ze</td>
         <td class="center">1500</td>
         <td>Zabra�uje zran�n� topen�m.</td>
      </tr>
      <tr>
         <td>p�du p�rka</td>
         <td class="center">1000</td>
         <td>Zabra�uje zran�n� p�dem z v��ky.</td>
      </tr>
   </table>   
   </div>
   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
