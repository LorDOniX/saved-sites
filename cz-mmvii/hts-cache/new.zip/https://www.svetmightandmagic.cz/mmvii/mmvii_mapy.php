<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">
   <h2>Mapy oblast� a dungeon�</h2>
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" border="1" width="600px" style="margin: auto; border: 0px;">
      <tr class="hlavicka_tabulky">
         <td style="width: 200px;">Oblasti</td>
         <td style="width: 200px;">Dungeony/M�sta</td>
         <td style="width: 200px;">Dungeony uvnit� m�st apod.</td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvii_mapy.php?mapa=oblast01">Smaragdov� ostrov</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon01">Dra�� sluj</a></td>
         <td rowspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon02">Chr�m M�s�ce</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvii_mapy.php?mapa=oblast02">Harmondale</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon03">Hrad Harmondale</a></td>
         <td rowspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon04">Jeskyn� B�l�ho �tesu</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvii_mapy.php?mapa=oblast03">Mohylov� �dol�</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon07">Stra�ideln� d�m</a></td>
         <td rowspan="1">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon06s">Mohyly (schema propojen�)</a></td>
         <td>
            <a href="mmvii_mapy.php?mapa=dungeon06a">I</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06b">II</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06c">III</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06d">IV</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06e">V</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06f">VI</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06g">VII</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06h">VIII</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06i">IX</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06j">X</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06k">XI</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06l">XII</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06m">XIII</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06n">XIV</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06o">XV</a>,
            <a href="mmvii_mapy.php?mapa=dungeon06p">Zokarrova hrobka</a>
         </td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon05">Kamenn� m�sto</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon46">Nighonsk� tunely</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvii_mapy.php?mapa=oblast04">Tulareansk� les</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon08">Hrad Navan</a></td>
         <td rowspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon09">Tulareansk� jeskyn�</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon10">Clankerova laborato�</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5"><a href="mmvii_mapy.php?mapa=oblast05">Erathie</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon11">Hrad Gryphonhearth</a></td>
         <td rowspan="5">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon12">Pevnost Riverstride</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon13">Erathijsk� stoka</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon14">Jeskyn� bandit�</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon15">Ztracen� hrobka</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5"><a href="mmvii_mapy.php?mapa=oblast06">Brakadsk� pou��</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon16">�kola kouzelnictv�</a></td>
         <td rowspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon17">Doly rud�ho trpasl�ka</a></td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvii_mapy.php?mapa=dungeon18">Obla�n� m�sto</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon19">Hrad Lambent</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon20">Ml�n� st�ny</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon21">Chr�m Sv�tla</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5"><a href="mmvii_mapy.php?mapa=oblast07">Tatalie</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon22">Z�me�ek v�vody Markhama</a></td>
         <td rowspan="5">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon23">Vinn� skl�pek</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon24">P��bojov� jeskyn�</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon25">Cech �old�k�</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon26">Wromthraxova jeskyn�</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvii_mapy.php?mapa=oblast08">Avlee</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon27">S�� pod horou</a></td>
         <td rowspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon28">Chr�m Baa</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon29">Tit�nsk� pevnost</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="6"><a href="mmvii_mapy.php?mapa=oblast09">Deyja</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon30">Str�n� v� 6</a></td>
         <td rowspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon31">V� Williama Setaga</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon32">P�eds�n� j�my</a></td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvii_mapy.php?mapa=dungeon33">J�ma</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon34">Hrad Gloaming</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon35">L�he�</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon36">Chr�m Temnoty</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvii_mapy.php?mapa=oblast10">Evenmorsk� ostrovy</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon37">Velechr�m Slunce</a></td>
         <td rowspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon38">Velechr�m M�s�ce</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvii_mapy.php?mapa=oblast11">Nighon</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon39">Hromov� hora</a></td>
         <td rowspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon40">Labyrint</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvii_mapy.php?mapa=oblast12">Zem� obr� (Eofol)</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon41">Kolonie Zod</a></td>
         <td rowspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon42">Dra�� jeskyn�</a></td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon43">Eofolsk� tunely</a></td>
      </tr>
      <tr>
         <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvii_mapy.php?mapa=oblast13">M�l�iny</a></td>
         <td><a href="mmvii_mapy.php?mapa=dungeon44">Lincoln</a></td>
         <td rowspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvii_mapy.php?mapa=dungeon45">Podivn� chr�m</a></td>
      </tr>
   </table>
   </div>
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
