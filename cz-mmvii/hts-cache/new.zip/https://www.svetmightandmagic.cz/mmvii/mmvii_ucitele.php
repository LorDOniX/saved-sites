<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {border: solid 1px maroon;}
      table {border: solid 1px maroon; /*border-collapse: separate;*/}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Um�st�n� u�itel�</h2>
   <p>&nbsp;</p>
   <table cellspacing="0" cellpadding="0" border="1" width="600">
      <tr class="hlavicka_tabulky">
         <td width="75px">Dovednost</td>
         <td width="75px">�rove�</td>
         <td width="225px">U�itel</td>
         <td width="225px">Oblast</td>
      </tr>
      <tr>
         <td rowspan="4">Me�</td>
         <td rowspan="2">expert</td>
         <td>Flynn Arin</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>Payge Rivenhill</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Tugor Slicer</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Chadric Townsaver</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">H�l</td>
         <td rowspan="2">expert</td>
         <td>Garic Hawthorne</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>Ton Withersmythe</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Elsie Pederton</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Jillian Mithrit</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Beze zbran�</td>
         <td rowspan="2">expert</td>
         <td>Puddle Stone</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>Kira Steeleye</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Ulbrecht the Brawler</td>
         <td>Evenmorsk� ostrovy</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Noris</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5">D�ka</td>
         <td rowspan="2">expert</td>
         <td>Smiling Jack</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>Mortie Ottin</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Aznog Slasher</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td rowspan="2">velmistr</td>
         <td>Tonken Fist</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>Bill Lasker</td>
         <td>Erathie-stoky</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Kop�</td>
         <td rowspan="2">expert</td>
         <td>Cassandra Holden</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>Kerin Greydawn</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Claderin Silverpoint</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Seline Falconeye</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Palc�t</td>
         <td rowspan="2">expert</td>
         <td>Aldrin Tamlock</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>Norbert Havest</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>bratr Rotham</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Patwin Fellbern</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Sekera</td>
         <td rowspan="2">expert</td>
         <td>Turgon Woodsplitter</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Wort Goblinreaver</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Dalin Keenedge</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Karn Stonecleaver</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Luk</td>
         <td rowspan="2">expert</td>
         <td>Will Rudyman</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>Jaycin Suretrail</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Lanshee Ravensight</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Cardric the Steady</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="6">Blaster</td>
         <td rowspan="2">expert</td>
         <td>Dark Shade</td>
         <td>J�ma</td>
      </tr>
      <tr>
         <td>Sir Caneghem</td>
         <td>Obla�n� m�sto</td>
      </tr>
      <tr>
         <td rowspan="2">mistr</td>
         <td>Maximus</td>
         <td>J�ma</td>
      </tr>
      <tr>
         <td>Crag Hack</td>
         <td>Obla�n� m�sto</td>
      </tr>
      <tr>
         <td rowspan="2">velmistr</td>
         <td>Kastor</td>
         <td>J�ma</td>
      </tr>
      <tr>
         <td>Ressurectra</td>
         <td>Obla�n� m�sto</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Ko�en� zbroj</td>
         <td rowspan="2">expert</td>
         <td>Douglas Iverson</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Mikel Deerhunter</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Rabisa Nedlon</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Miyon the Quick</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Krou�kov� zbroj</td>
         <td rowspan="2">expert</td>
         <td>Gilad Bith</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>Tricia Steelcoif</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Medwari Dragontracker</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Halian Nevermore</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Pl�tov� zbroj</td>
         <td rowspan="2">expert</td>
         <td>Critias Burnkindle</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>Weldrik Lotts</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Dekian Forgewright</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Brandt the Maker</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Uh�b�n�</td>
         <td rowspan="2">expert</td>
         <td>Spyder</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>Sheldon Mist</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Oberic Crane</td>
         <td>Evenmorsk� ostrovy</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Kenneth Wain</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">�t�t</td>
         <td rowspan="2">expert</td>
         <td>Randal Wolverton</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Isram Gallowswell</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Fedwin Smithson</td>
         <td>Evenmorsk� ostrovy</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Mistr zbran�</td>
         <td rowspan="2">expert</td>
         <td>Edgar Botham</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>Trent Steele</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Paula Brightspear</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Lasiter the Slayer</td>
         <td>Eofol (Zem� obr�)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Posilov�n�</td>
         <td rowspan="2">expert</td>
         <td>Kelli Hollyfield</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>Trip Thorinson</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Wanda Foestryke</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Evander Thomas</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Opravov�n�</td>
         <td rowspan="2">expert</td>
         <td>Shane Thomas</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Balan Gizmo</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Thomas Moore</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Gareth the Fixe</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Obchodov�n�</td>
         <td rowspan="2">expert</td>
         <td>Jobber Thain</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>Matric Weatherson</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Bethold Caverhill</td>
         <td>Evenmorsk� ostrovy</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Bringham the Frugal</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5">Odstran�n� past�</td>
         <td rowspan="3">expert</td>
         <td>Taren the Lifter</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>Gretchin Fiddlebone</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>Bill Lasker</td>
         <td>Erathie-stoky</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Lenord Skinner</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Silk Quicktongue</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5">Kraden�</td>
         <td rowspan="3">expert</td>
         <td>Elmo the Pincher</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>Peryn Lightfingers</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Bill Lasker</td>
         <td>Erathie-stoky</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Leane Shadowrunner</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Everil Nightwalker</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Vn�m�n�</td>
         <td rowspan="2">expert</td>
         <td>Gregory Weider</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Kethric Otterton</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Garret Dotes</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Petra Cleareye</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Alchymie</td>
         <td rowspan="2">expert</td>
         <td>Bryce Waterrshed</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>Edgar Willowbark</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Elzbet Winterspoon</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Lucid Apple</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Identifikace p�edm�t�</td>
         <td rowspan="2">expert</td>
         <td>Hollis the True</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>Fenton Krewlen</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Samuel Benson</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Payge Blueswan</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Identifikace nestv�r</td>
         <td rowspan="2">expert</td>
         <td>Christie Nosewort</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>Alton Black</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Jeni Swiftfoot</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Raven the Hunter</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Meditace</td>
         <td rowspan="2">expert</td>
         <td>Barbara Wiseman</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>Stewart Whitesky</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Tessa Greensward</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Kaine</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Vzd�l�v�n�</td>
         <td rowspan="2">expert</td>
         <td>Agatha Putnam</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>Isac Applebee</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Dorothy Senjac</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>William Smithson</td>
         <td>Evenmorsk� ostrovy</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie ohn�</td>
         <td rowspan="2">expert</td>
         <td>Kindle Treasurestone</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>Lisha Redding</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Ashen Temper</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Blayze</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie vody</td>
         <td rowspan="2">expert</td>
         <td>Herald Whitecap</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>Karla Ravenhair</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Tobren Rainshield</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Torrent</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie vzduchu</td>
         <td rowspan="2">expert</td>
         <td>Sethrik Windsong</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>Kyra Stormeye</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Rislyn Greenstorm</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Gayle</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie zem�</td>
         <td rowspan="2">expert</td>
         <td>Johanson Kern</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Jasper Welman</td>
         <td>Kamenn� m�sto</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Lara Stonewright</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Avalanch</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie mysli</td>
         <td rowspan="2">expert</td>
         <td>Helga Whitesky</td>
         <td>Nighon</td>
      </tr>
      <tr>
         <td>Julian the Delver</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Myles Featherwind</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Xavier Bremen</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie t�la</td>
         <td rowspan="2">expert</td>
         <td>Straton Hillsman</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Tristen Heartsworn</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>bratr Bombah</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Tempus</td>
         <td>Avlee</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie ducha</td>
         <td rowspan="2">expert</td>
         <td>Bertram Stillwater</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>Solomon Riverstone</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Heather Dreamwright</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Benjamin the Balanced</td>
         <td>Tulareansk� les</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie sv�tla</td>
         <td rowspan="2">expert</td>
         <td>Ethan Lightsworn</td>
         <td>Brakada</td>
      </tr>
      <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Helena Morningstar</td>
         <td>Obla�n� m�sto</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Gavin Magnus</td>
         <td>Obla�n� m�sto (hrad Lambent)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4">Magie temnoty</td>
         <td rowspan="2">expert</td>
         <td>Jasp the Nightcrawler</td>
         <td>Deyja</td>
      </tr>
      <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Seth Darkenmore</td>
         <td>J�ma</td>
      </tr>
      <tr>
         <td>velmistr</td>
         <td>Archibald Ironfist</td>
         <td>J�ma (hrad Gloaming)</td>
      </tr>
   </table>
   
   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
