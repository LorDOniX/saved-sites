<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Um�st�n� jednotliv�ch cech� magie</h2>
   <p>&nbsp;</p>
   
   <p>Ka�d� z cech� magie nab�z� k prodeji kouzla r�zn�ch �rovn� a podle toho se d�l� na cech pro za��te�n�ky, pro adepty, pro mistry a pro velmistry. V cechu pro za��te�n�ky koup�te jen kouzla norm�ln� �rovn� dovednosti, v cechu pro adepty budete moci koupit nav�c i kouzla expertn� �rovn�, v cechu pro mistry p�ibudou kouzla mistrovsk� �rovn� a nakonec ve velmistrovsk�m cechu budete moci koupit kouzla v�ech �rovn�.</p>
   <p>Rozm�st�n� jednotliv�ch �rovn� cech� v�cem�n� odpov�d� postupu va�� dru�iny po kontinentu, tak�e v�t�ina za��te�nick�ch cech� je na Smaragdov�m ostrov� a ��st v Harmondale, cechy pro adepty jsou pak hned v p�ilehl�ch oblastech. Podobn� jsou rozm�st�ni i expertn� u�itel�.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="600px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 75px;">Cech/pro</td>
         <td style="width: 75px;">zem�</td>
         <td style="width: 75px;">vody</td>
         <td style="width: 75px;">vzduchu</td>
         <td style="width: 75px;">ohn�</td>
         <td style="width: 75px;">ducha</td>
         <td style="width: 75px;">t�la</td>
         <td style="width: 75px;">mysli</td>
      </tr>
      <tr>
         <td>za��te�n�ky</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Smaragdov� ostrov</td>
         <td>Smaragdov� ostrov</td>
         <td>Smaragdov� ostrov</td>
         <td>Smaragdov� ostrov</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>adepty</td>
         <td>Tulareansk� les</td>
         <td>Tulareansk� les</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>mistry</td>
         <td>Kamenn� m�sto</td>
         <td>Brakadsk� pou��</td>
         <td>Tulareansk� les</td>
         <td>Tulareansk� les</td>
         <td>Deyja</td>
         <td>Erathie</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>velmistry</td>
         <td>J�ma</td>
         <td>Evenmorsk� ostrovy</td>
         <td>Obla�n� m�sto</td>
         <td>Nighon</td>
         <td>Erathie</td>
         <td>Avlee</td>
         <td>Avlee</td>
      </tr>
   </table>
   </div>
   
   <p>V tabulce jsem neuvedl cechy sv�tla a temnoty, proto�e k jejich kouzl�m nebudete m�t p��stup ihned od po��tku hry, ale budete se je moci nau�it a� pozd�ji. Nav�c v z�vislosti na volb� cesty se budete moci nau�it jen jedno odv�tv� t�to magie. Pro ka�dou z uveden�ch �kol jsou pouze dv� �rovn� cech�. Pro magii temnoty je to Cech noci (adepti) v Deyje a Cech soumraku (velmist�i) v J�m�. Pro magii sv�tla je to Cech z��e (adepti) v Brakadsk� pou�ti a Cech osv�cen� (velmist�i) v Obla�n�m m�st�. Nakupovat kouzla v nich budete moci a� ve chv�li, kdy si p�i volb� soudce zvol�te p��slu�nou stranu, ��m� se stanete �leny cechu. Jakmile spln�te i vstupn� �kol (proj�t L�hn� nebo Ml�n�mi st�nami), budete se moci v cechu nau�it i p��slu�nou dovednost magie.</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
