<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h1>Might and Magic VII - For Blood and Honor</h1>
   
   <ul>
      <li><a href="mmvii_recenze.php">Recenze</a></li>
      <li><a href="mmvii_prolog.php">Prolog</a></li>
      <li><a href="mmvii_manual.php">Archibald�v den�k</a></li>
      <li><a href="mmvii_pribehcs.php">P��b�h za cestu sv�tla</a></li>
      <li><a href="mmvii_pribehct.php">P��b�h za cestu temnoty</a></li>
      <li><a href="mmvii_vlastnosti.php">Vlastnosti postav</a></li>
      <li><a href="mmvii_dovednosti.php">Dovednosti</a></li>
      <li><a href="mmvii_povolani.php">Povol�n� postav</a></li>
      <li><a href="mmvii_levely.php">Tr�nink postav</a></li>
      <li><a href="mmvii_ucitele.php">Um�st�n� u�itel�</a></li>
      <li><a href="mmvii_alchymie.php">Alchymie</a></li>
      <li><a href="mmvii_obchodovani.php">Obchodov�n�</a></li>
      <li><a href="mmvii_cechy.php">Rozm�st�n� cech� v Erathii a okol�</a></li>
      <li class="li_1">Hern� postavy
      <ul>
         <li><a href="mmvii_npc.php">Naj�m�n� NPC</a></li>
      </ul>
      </li>
      <li class="li_1">P�ehled monster
      <ul>
         <li><a href="mmvii_bestiar.php">Besti��</a></li>
      </ul>
      </li>
      <li class="li_1">P�edm�ty
      <ul>
         <li><a href="mmvii_zbrane.php">Zbran�</a></li>
         <li><a href="mmvii_zbroje.php">Zbroje</a></li>
         <li><a href="mmvii_ostatni.php">�apky, amulety, prsteny, opasky, h�lky</a></li>
         <li><a href="mmvii_artefakty.php">Artefakty</a></li>
         <li><a href="mmvii_relikvie.php">Relikvie</a></li>
         <li><a href="mmvii_specialpred.php">Speci�ln� p�edm�ty</a></li>
         <li><a href="mmvii_bonusy.php">Bonusy p�edm�t�</a></li>
         <li><a href="mmvii_ruda.php">V�roba p�edm�t� z rudy</a></li>
      </ul>
      </li>
      <li class="li_1">Magie
      <ul>
         <li><a href="mmvii_svitky.php">Kouzeln� knihy, svitky a h�lky</a></li>
         <li><a href="mmvii_kouzla_seznam.php">Abecedn� seznam kouzel</a></li>
         <li class="li_2">P�ehled kouzel podle �koly magie
         <ul>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=ohne">Magie ohn�</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=vzduchu">Magie vzduchu</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=vody">Magie vody</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=zeme">Magie zem�</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=ducha">Magie ducha</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=mysli">Magie mysli</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=tela">Magie t�la</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=svetla">Magie sv�tla</a></li>
            <li style="list-style: circle;"><a href="mmvii_kouzla.php?magie=temnoty">Magie temnoty</a></li>
         </ul>
				 </li>
      </ul>
      </li>
      <li class="li_1">Mapy, cestov�n�, respawn
      <ul>
         <li><a href="mmvii_mapy.php">Mapy oblast� a dungeon�</a></li>
         <li><a href="mmvii_mestskabrana.php">M�stsk� br�na</a></li>
         <li><a href="mmvii_cestovani.php">Cestov�n� po Erathii a okoln�ch zem�ch</a></li>
         <li><a href="mmvii_vmapa.php">Velk� mapa Erathie</a></li>
         <li><a href="mmvii_respawn.php">Obnoven� (respawn) map</a></li>
      </ul>
      </li>
      <li class="li_1">N�vod, tipy
      <ul>
         <li><a href="mmvii_navod.php">N�vod na hru Might and Magic VII</a></li>
         <li><a href="mmvii_ukoly.php">P�ehled jednotliv�ch �kol�</a></li>
         <li><a href="mmvii_sifra.php">�ifra</a></li>
         <li><a href="mmvii_malwick.php">Pan Malwick</a></li>
      </ul>
      </li>
      <li class="li_1">Ostatn� (dopl�kov� informace)
      <ul>     
         <li><a href="mmvii_mcechy.php">Um�st�n� jednotliv�ch cech� magie</a></li>
         <li><a href="mmvii_hadanka.php">H�danka z obelisk�</a></li>
         <li><a href="mmvii_hry.php">Hry o vlastnosti - V�zvy</a></li>
         <li><a href="mmvii_piedestaly.php">Piedestaly</a></li>
         <li><a href="mmvii_studny.php">Rozm�st�n� studn� s bonusy, sudy a kotle</a></li>
         <li><a href="mmvii_jidlo.php">Spot�eba j�dla p�i odpo�inku</a></li>
         <li><a href="mmvii_arcomage.php">Arcomage</a></li>
         <li><a href="mmvii_prekupnici.php">P�ekupn�ci</a></li>
         <li><a href="mmvii_lampy.php">D�inovy lampy</a></li>
         <li><a href="mmvii_svatyne.php">Rozm�st�n� svaty� s trval�mi bonusy</a></li>
         <li><a href="mmvii_cas.php">Hern� �as</a></li>
         <li><a href="../pmm/pmm_akceleram7m8.php">Pot��e s barevn�m zobrazen�m</a></li>
         <li><a href="mmvii_tipdruidi.php">Atypick� dru�iny aneb putov�n� s druidy</a></li>
         <li><a href="../pmm/pmm_atypdruziny.php">Atypick� dru�iny (hr��i)</a></li>
      </ul>
      </li>
      <li class="li_1">Zaj�mavosti
      <ul>
         <li><a href="mmvii_zajimavosti.php">Zaj�mavosti, n�pady, triky</a></li>
      </ul>
      </li>
   </ul>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
