<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 15px;}
      td {text-align: left; border: none; text-indent: 5px;}
      .popis {text-align: justify;}
      .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Speci�ln� p�edm�ty</h2>
   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/01.png" width="33px" height="36px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Clanker�v amulet</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Achymie +15) Tento amulet, mocn� n�stroj alchymist�, je kl��em ke Clankerovu �sp�chu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/02.png" width="49px" height="192px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�epel smrti</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">For testing ... remove befor final release aneboli �esky "Pro testov�n� ... odstranit p�ed fin�ln�m vyd�n�m". Tato zaj�mav� zbra� se skute�n� nikde ve h�e nevyskytuje, je jen sou��st� editoru.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>666</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/03.png" width="31px" height="27px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Doprovod d�my</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Ch�ze po vod�, P�d p�rka, ochrany, �ena) Magick� 'doprovod' navr�en� m�gem Terraxem pro jednu z jeho p��telky�, kter� za n�m musela cestovat z daleka. Prsten chr�n� nositelku proti �ivl�m, p�du a topen�. D�ma se bohu�el vydala do Erathie a kr�tce na to prsten zmizel.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/04.png" width="29px" height="148px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�stojn�k�v tes�k</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d5+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tes�k z kvalitn� ocele. Je ostr� a p�ipraven� k akci.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/05.png" width="37px" height="100px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ka lady Carmine</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(+5 bod� t�lesn�ho zran�n�, odstran�n� past� +5) Vruby a �kr�bance na �epeli t�to nechutn� d�ky sv�d�� o jej�m �etn�m pou��v�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/06.png" width="108px" height="160px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elf� krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+30</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(uzdraven�, rychlost +15, p�esnost +15, Elf) P�ed v�lkou proti lidem a goblin�m byly elf� zbroje jako tato b�n�j��. Stalet� boj� spolu s upadaj�c�m um�n�m pl�tn��� sn��ilo po�et zbroj� prakticky na nulu. Pou�it�m leh��ch materi�l� a stylem zpracov�n�, kter� vyhovovalo pouze elf�m, poskytovala zbroj nositeli v�ce voln�ho pohybu a t�m rychlej�� a p�esn�j�� v�pady.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/07.png" width="29px" height="148px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Grognard�v tes�k</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Zhouba elf�) Pozoruhodn� zpracovan� a okouzlen� goblin� zbra�. I kdy� byla p�vodn� vytvo�ena pro zab�jen� elf�, spln� skv�le sv� posl�n� i u jin�ch ras.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/08.png" width="67px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hermovy sand�ly</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+20</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Rychlost +100, P�esnost +50, odolnost proti vzduchu +50, regenerace zdrav�, regenerace many, P�d p�rka) Tyto ok��dlen� sand�ly, o kter�ch se ��k�, �e pat�ily boh�m, zaru�uj� sv�mu majiteli obrovsk� schopnosti.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/09.png" width="71px" height="26px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hrdin�v opasek</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Mistr zbran� +5, s�la +15, regenerace zdrav�, Mu�) Tento opasek navr�en� pro svat�ho Perciho zaru�uje state�nost v boji, mimo��dnou s�lu a regeneraci. Svat� Perci tohoto opasku hojn� u��val, ale ani s jeho pomoc� se nemohl vyhnout smrti ve sp�rech draka Wromthraxe.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/10.png" width="32px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kov��sk� rukavice</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Odolnost proti ohni +30, s�la +15, odolnost +15, Trpasl�k) Kov��sk� rukavice vyrobil Mekorig pro sv� pomocn�ky. Rukavice jim m�ly pomoci ve slu�b� Mekorigovi. Rukavice, zvy�uj� u� tak skv�lou trpasli�� s�lu a v�dr�, zaru�ovaly mimo��dnou odolnost v��i ohni, co� se u v�hn� tak �hav�, jako byla Mekorigova, ur�it� hodilo.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/11.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">M�s��n� plṻ</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+11</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie temnoty) Zvy�uje ��innost kouzel magie temnoty. Tento plṻ je v�razem nejvy��� hodnosti dosa�iteln� Kn�zi M�s�ce. Nebylo vyrobeno v�ce ne� dev�t takov�ch plṻ� - jeden pro ka�d�ho �lena rady M�s�ce.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/12.png" width="66px" height="145px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Minotaurova sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d3+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(s�la +25) Skv�l� trofej! A�koli byla tato sekyra vyrobena pro minotaura a je velmi t�k�, magick� s�ly, kter�mi je napln�na, umo��uj� jej� pou��v�n� k�mkoliv.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/13.png" width="62px" height="46px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Oko mysli</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Inteligence +15, osobnost +15, regenerace many, �lov�k) Oko mysli vytvo�il Mekorig pro velk�ho druida Larette Weismana. Helma zesiluje intelekt i osobnost nositele, postupn� regeneruje jeho manu a slou�� i jako ochrana hlavy. Bohu�el, Oko mysli se hod� pouze na lidskou hlavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/14.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ov�� rouno</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Imunita v��i nemoci, ��lenstv�, ochromen�, usnut� a zkamen�n�, inteligence -20 osobnost -20) Plṻ nosili velekn�� ��du Baa. I navzdory jeho u�ite�nosti se v�ak zd�, �e jeho nositel� pomalu vymizeli.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/15.png" width="31px" height="28px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Prsten ducha</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie ducha) Star� podivn� prsten, kter� se zd� b�t na dotek neobvykle tepl�. Zesiluje spojen� nositele s duchem.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/16.png" width="63px" height="228px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Skv�l� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zd� se, �e luk s�m odhal� st�elcovu s�lu a p�izp�sob� se j�. Nikdy se nemus� nam�hat s nata�en�m t�tivy a bez probl�m� luk udr��� a� do chv�le v�st�elu. Des�tky drobn�ch �prav, jako jsou tyto, �in� z luku to nejlep��, co jsi kdy vid�l.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>4000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/17.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Slune�n� plṻ</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+11</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie sv�tla) Zvy�uje ��innost kouzel magie sv�tla. Tento plṻ je v�razem nejvy��� hodnosti dosa�iteln� Kn�zi Slunce. Nebylo vyrobeno v�ce ne� dev�t takov�ch plṻ� - jeden pro ka�d�ho �lena rady Slunce.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/18.png" width="50px" height="55px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">St�nov� maska</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Kraden� +3, odstran�n� past� +3) Maska ur�en� k ukryt� nositelovy toto�nosti. Je z�rove� okouzlena, aby poskytovala dobrou ochranu a pom�hala zlod�jsk�m snah�m.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/19.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Up��� pl�t�nka</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+9</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(+10 inteligence a �t�st�) Tuto pl�t�nku, kterou lze naj�t u up�r�, lze pova�ovat za mal� z�zrak. Chr�n� t�lo up�ra p�ed slune�n�mi paprsky, ale jeho tv�� uchr�nit nedok�e.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <p>&nbsp;</p>
   
   <p>Up��� pl�t�nka je vcelku zaj�mav� p�edm�t, kter� je v�ak pops�n nejsp��e jen v datov�ch souborech. V samotn� h�e se mi jej� existenci prok�zat nepoda�ilo (tedy vyjma domn�nky, �e jsem j� kdysi v jedn� z her opravdu z�skal, co� u� ale nem�m jak dolo�it). Datov� soubory se na jednom z m�st zmi�uj� i o jist� oprav�, kdy byl ze hry odstran�n P�n up�r�. Dle m�ho n�zoru se tato postava m�la nach�zet ve Vinn�m skl�pku v Tatalii a m�la b�t ozdobena pr�v� t�mto pl�t�m. D�ky jeho neexistenci se pak tato pl�t�nka stala nedostupnou.</p>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/20.png" width="32px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�l� prsten</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie vzduchu) Vz�cn� a velmi mocn� prsten vyroben� v�lami. N�co podobn�ho vid�la jen hrstka smrteln�k�!</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/21.png" width="46px" height="192px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zhouba elf�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d6+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Kryt�, Zhouba elf�, Goblin) Tento me� vyrobili goblini pro sv�ho v�dce Grognara. Bohu�el, goblini v�lku prohr�li a me� se na n�jak� �as ztratil. Me�, kter� je okouzlen, aby rozs�val zk�zu mezi elfy a chr�nil sv�ho vlastn�ka p�ed ��py, d�l� skute�n� �est sv�mu jm�nu. Zvl�tn� vedlej�� ��inek zp�sobuje, �e me� nem��e pou��t nikdo jin� ne� goblin.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/22.png" width="43px" height="181px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zloduch�v me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vys�v� �ivoty z protivn�ka. T�mto me�em �asto popravoval William Setag sv� v�zn�, ��m� hojil sv� drobn� poran�n�. Zbra� je na dotek chladn� a v ruce se nepatrn� chv�je.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/23.png" width="37px" height="272px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zokarrova sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+13</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(+10 T��da zbroje, odolnost a zdrav�) Zbra� d�d�n� v Zokarrov� dynastii z otce na syna. Tato sekyra poskytuje sv�mu dr�iteli velk� sp��zn�n� s magi� zem�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/specpred/24.png" width="27px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zrcadlo med�zy</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nositel tohoto amuletu je zcela imunn� v��i zkamen�n�. Bylo by p��jemn� z�skat ho o n�co d��ve.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>5000</td>
      </tr>
   </table>

   <p>&nbsp;</p>   
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
