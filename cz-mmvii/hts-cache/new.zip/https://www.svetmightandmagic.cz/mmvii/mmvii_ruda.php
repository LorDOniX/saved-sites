<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 20px; border: 1px solid maroon;}
      td {text-align: left; border: none; text-indent: 0px; padding: 4px;}
     .popis {text-align: justify;}
     .popis_2 {text-align: justify; border: 1px solid maroon;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>V�roba p�edm�t� z rudy</h2>
   <p>&nbsp;</p>
   
   <p>V sedm�m d�le m�te mo�nost sb�rat r�zn� druhy rud, kter� se li�� svou kvalitou. Trojice obyvatel ve Steadwicku v Erathii v�m z nich pak m��e vyrobit ur�it� typ p�edm�tu. Robert Sourbrow vyr�b� zbroje, Qillain Laraselle zbran�, ostatn� p�edm�ty vyr�b� Cloud Agraynel. ��m kvalitn�j�� rudu m�te, t�m lep�� p�edm�t v�m z n� dan� postava m��e vyrobit, ale neni to pravidlem. I ze Staltov� rudy v�m s klidem m��ou vyrobit p�edm�t n�zk� kvality.</p>

   <table cellspacing="0" cellpadding="4px" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/ruda/item353.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">�elezn� ruda</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� hrouda �elezn� rudy. Zku�en� kov�� dok�e z t�to rudy vykovat zbra�, amulet, prsten, zbroj nebo jinou u�ite�nou v�c.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>5</td>
      </tr>
   </table>
   <table cellspacing="0" cellpadding="4px" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/ruda/item354.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Siertalov� ruda</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� hrouda siertalov� rudy. Ruda je pevn�j�� a leh�� ne� ocel a zku�en� kov�� dok�e z t�to rudy vykovat vyj�me�nou zbra�, amulet, prsten, zbroj nebo jinou u�ite�nou v�c.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   <table cellspacing="0" cellpadding="4px" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/ruda/item355.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Phyltov� ruda</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� hrouda phyltov� rudy. Phylt se �asto pou��v� k legov�n� ocele pro zv��en� jej� pevnosti a schopnosti okouzlen�. Zku�en� kov�� dok�e z t�to rudy vykovat zbra�, amulet, prsten, zbroj nebo jinou u�ite�nou v�c.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   <table cellspacing="0" cellpadding="4px" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/ruda/item356.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Kergarov� ruda</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� hrouda kergarov� rudy. Kergar se ve mnoh�m podob� oceli, ale je sn�ze okouzliteln�. Zku�en� kov�� dok�e z t�to rudy vykovat magickou zbra�, amulet, prsten, zbroj nebo jinou u�ite�nou v�c.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   <table cellspacing="0" cellpadding="4px" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/ruda/item357.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Erudinov� ruda</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� hrouda erudinov� rudy. Vz�cn� magick� ruda se nach�z� pouze v n�kolika oblastech Erathie. Zku�en� kov�� dok�e z t�to rudy vykovat mocnou zbra�, amulet, prsten, zbroj nebo jinou u�ite�nou v�c.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   <table cellspacing="0" cellpadding="4px" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/ruda/item358.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Staltov� ruda</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� hrouda staltov� rudy. Tato ruda je snadno okouzliteln� a tvrd� jako obsidi�n. Zku�en� kov�� dok�e z t�to rudy vykovat neuv��iteln� mocnou zbra�, amulet, prsten, zbroj nebo jinou u�ite�nou v�c.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
