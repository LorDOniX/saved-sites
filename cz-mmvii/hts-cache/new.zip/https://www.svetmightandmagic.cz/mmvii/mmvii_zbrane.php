<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; border: none; text-indent: 5px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <a class="zalozka" name="00"></a>
   <h2>Zbran�</h2>
   
   <ul>
      <li><a href="#01">Me�e</a></li>
      <li><a href="#02">D�ky</a></li>
      <li><a href="#03">Sekyry</a></li>
      <li><a href="#04">Kop�</a></li>
      <li><a href="#05">Halapartny</a></li>
      <li><a href="#06">Trojzubce</a></li>
      <li><a href="#07">Luky</a></li>
      <li><a href="#08">Ku�e</a></li>
      <li><a href="#09">Palc�ty a �emdihy</a></li>
      <li><a href="#10">Kladiva</a></li>
      <li><a href="#11">Kyje</a></li>
      <li><a href="#12">Hole</a></li>
      <li><a href="#13">Blastery</a></li>
   </ul>
   
   <h3><a class="zalozka" name="01">Me�e</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>V�echny me�e ve h�e se d�l� celkem do �ty� samostatn�ch kategori� - na dlouh� me�e, obouru�n� me�e, �irok� me�e, �avle a tes�ky. Krom obouru�n�ch me�� se v�echny ostatn� dr�� jen v jedn� ruce. Mezi �avlemi a tes�ky prakticky neexistuje rozd�l a tak jsou uvedeny spole�n�. Ka�d� z kategori� je pak op�t se�azena podle kvality od nejhor��ho po nejlep��.</p>
   
   <h4>Dlouh� me�e</h4>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item001.png" width="34px" height="156px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Oby�ejn� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Bez ohledu na �etn� zuby a z��ezy je tento me� ��innou zbran�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item002.png" width="29px" height="185px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elf� �avle</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">B�n� zbra� elf�. Smrt�c�, le� ni��m v�jime�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item003.png" width="14px" height="150px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">B�itk� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">A�koliv tento me� vypad� pom�rn� sta�e, jeho �epel je neoby�ejn� ostr�. Pravd�podobn� je to zp�sobeno n�jak�m okouzlen�m p�i jeho v�rob�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>350</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item004.png" width="31px" height="169px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elegantn� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Me� vysok� kvality, ozna�en� monogramem pod hlavic�, kter� vypov�d�, �e byl ukov�n mistrem zbroj��em Mekorigem Slep�m mezi lety 780-800.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item005.png" width="43px" height="181px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Soubojov� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto vz�cn� �epele byly ukov�ny p�ed dobou Ticha a po stalet� byly pou��v�ny vzne�en�mi duelanty, kte�� tou�ili po smrti na �rovni. ��dn� dva me�e nejsou stejn�, ke v�em se v�� krvav� p��b�hy.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <h4>Obouru�n� me�e</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item006.png" width="39px" height="183px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Obouru�n� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Prost� obouru�n� me� s ko�en�m j�lcem a vzhledem b�n�m po cel� Erathii.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item007.png" width="49px" height="192px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Skv�l� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Efektivn� smrt�c� zbra� pou��van� v pr�b�hu �asu v�ce �i m�n� uk�zn�n�mi arm�dami. Kov��, kter� tento me� ukoval, si dal z�le�et i na krevn�m �l�bku, t�hnouc�m se prost�edkem �epele.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item008.png" width="46px" height="192px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hrdinsk� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jak�si �erm�� kdysi p�i�el na to, �e vlnit� �epel je pevn�j�� ne�li p��m�, i na to, �e p�i z�sahu zp�sob� rozs�hlej�� zran�n�. Mo�n� je to pravda, mo�n� ne, jedna v�c je ale jist�. Jde o jednu z nejprecizn�j��ch �emesln�ch prac�, jak� kdy byly vid�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>800</td>
      </tr>
   </table>
   
   <h4>�irok� me�e</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item009.png" width="33px" height="159px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�irok� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Le�t�n� �irok� me�, b�n� pou��van� v�emi vojsky po cel� Erathii.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item010.png" width="32px" height="145px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� �irok� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Skv�l� Erathijsk� ocelov� me� je pozoruhodn� jak svou vyt��benou kvalitou, tak i ostrost�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item011.png" width="32px" height="155px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Me� �ampi�n�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e �avle ne�li me�, p�esto ale bez ohledu na sv� st��� vynik� mimo��dn� ostrou �epel�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h4>�avle a tes�ky</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item012.png" width="32px" height="129px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tes�k</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�ern�n� povrch tohoto tes�ku m�l protivn�ka zm�st p�i odhadu d�lky �epele. Mnoho nezku�en�ch �erm��� podlehlo t�to z�ke�n� �prav�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item013.png" width="29px" height="148px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Goblin� tes�k</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Podivn� slitina mosazi a n�jak�ho dal��ho �ervenav�ho kovu dodala t�to zbrani nezvyklou barvu i neoby�ejnou pevnost. Goblin� kov��i se obvykle nezab�vaj� vzhledem, ale pokud jde o zab�jen�, jsou neomyln�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>290</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item014.png" width="32px" height="160px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Regnansk� tes�k</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mistrn� skryt� inici�ly u hlavice tohoto tes�ku prozrazuj�, �e jeho tv�rcem byl Alec Teling, kov��sk� mistr Harecka IX, p�na na Regn� a c�sa�e Nekone�n�ho oce�nu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>590</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="02">D�ky</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>Podobn� jako je tomu u me��, tak se i d�ky d�l� do dvou samostatn�ch kategori� - na oby�ejn� d�ky a na dlouh� d�ky. Ka�d� z kategori� je op�t �azena podle kvality od nejhor�� po nejlep��.</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item015.png" width="18px" height="100px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Prost� d�ka, jakou lze nal�zt v rukou zlod�j� a rv��� prakticky kdekoliv.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>8</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item016.png" width="36px" height="102px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trpasli�� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Pro trpasl�ka je to sp��e kr�tk� me� ne� d�ka, p�esto je to vynikaj�c� p��klad skv�l� trpasli�� pr�ce a um�leck� tvo�ivosti.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item017.png" width="43px" height="84px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�ralo�� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�epel t�to d�ky je ve skute�nosti zubem �raloka vyloven�ho z vod Klidn�ho oce�nu a upevn�n�m do zdobn�ho j�lce. Je velmi ostr� a lehk�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item018.png" width="45px" height="100px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vrahova d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Z�tita t�to d�ky je skl�dac�, co� umo��uje jej� snadn� ukryt�. Tla��tko na hlavici d�ky otev�e p���ky z�tity velmi rychle, jakmile je zbra� vyta�ena z pochvy.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item019.png" width="37px" height="100px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">M�gova d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zbra� z �as� Z�zrak�. Dnes ji� nelze vyrobit ost�ej�� nebo pevn�j�� �epel.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>
   
   <h4>Dlouh� d�ky</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item020.png" width="28px" height="113px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dlouh� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Dlouh� d�ka spojuje v�hodu dosahu me�e s v�hodou snadn�ho ukryt� d�ky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item021.png" width="28px" height="106px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Erathijsk� dlouh� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e kr�tk� me� ne� d�ka, �zk� �epel t�to zbran� je pozoruhodn� svou pevnost� i pravd�podobn� okouzlen�m b�item.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item022.png" width="38px" height="114px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Honosn� dlouh� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3+7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�sporn�, ale p�ita�liv� vzhled t�to d�ky je typick� pro pam�tky z �as� p�ed dobou Ticha. Tento konkr�tn� styl byl v dan� dob� velmi obl�ben�, ale vzhledem k tomu, �e od t�ch dob uplynulo v�ce ne� tis�c let, dochovalo se jen p�r takov�ch zbran�. Stejn� jako v�echno z doby Ticha, i tato d�ka vypad� stejn� nov� jako v den, kdy byla vyrobena.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>350</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="03">Sekyry</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>Aby to nebylo tak snadn�, tak i sekyry maj� sv� dv� samostatn� kategorie. Krom b�n�ch seker se ve h�e setk�me i s obouru�n�mi sekyrami, kter� se zcela dle o�ek�v�n� dr�� ob�ma rukama. Nem��ete je tedy pou��vat spole�n� s me�i. Ka�d� z kategori� je op�t d�lena podle kvality od nejhor�� po nejlep��.</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item023.png" width="39px" height="114px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Oby�ejn� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato oby�ejn� sekyra je sp��e n�strojem ne� zbran�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item024.png" width="47px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Bojov� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Obl� b�it t�to zbran� je b�n� mezi levn�mi lidsk�mi arm�dami a bandity.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item025.png" width="39px" height="134px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trpasli�� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Typick� trpasli�� v�roba: siln�, praktick� a jednoduch�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item026.png" width="43px" height="155px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jedna z n�kolika beden pln�ch podobn�ch sekyr byla trpasl�k�m ukradena nighonsk�mi �arod�jnicemi. Ka�d� z t�chto zbran� byla vytvrzena a okouzlena v kov�rn� Kamenn�ho m�sta a ozna�ena jeho zna�kou.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item027.png" width="66px" height="145px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Minotau�� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Dvojb�it� sekyry jako je tato jsou mocn� okouzleny minotau��mi kouzeln�ky v tajn�m procesu, kter� je zn�m� pouze jim. Tyto sekyry jsou lehk�, a�koli by m�ly b�t t�k�, a proniknou kovem stejn� snadno jako suknem.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>550</td>
      </tr>
   </table>
   
   <h4>Obouru�n� sekyry</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item028.png" width="70px" height="221px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dlouh� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento styl dlouh� sekyry m� del�� dosah a je ni�iv�j�� ne� b�n� jednoru�n� sekyra.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>225</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item029.png" width="48px" height="272px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�le�n�kova dlouh� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato dlouh� sekyra m� ost�ej�� �epel vybavenou ve�ker�mi vojensk�mi vyn�lezy - �l�bkem na krev, p���alami, protiz�va��m i drobnou �epel� za rati�t�m pro n�ro�n� a slo�it� kryty.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item030.png" width="37px" height="272px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Poprav�� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Pojmenov�na po obl�ben�m n�stroji kat�. Je vybaven� dlouhou �epel�, kter� m� zamezit v�skytu nep��jemn�ch a choulostiv�ch chyb kat�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>900</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="04">Kop�</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item031.png" width="17px" height="265px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Oby�ejn� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�esto�e je toto kop� tvo�eno jen ostr�m �lomkem kamene, zasazen�m do hrub�ho rati�t�, dok�e tato zbra� zp�sobit v�n� zran�n�. (+1D9 p�i dr�en� ob�ma rukama).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item032.png" width="31px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Voj�kovo kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Podobn� kop� lze nal�zt v�ude tam, kde je vy�adov�na jak v�hoda d�evcov� zbran�, tak zbran� pro boj zbl�zka.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item033.png" width="19px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elf� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Elf� zbran� jsou t�m�� v�dy stejn� vzne�en� jako praktick�. Elegance a vyt��benost tohoto kop� neohrozila jeho praktick� vlastnosti, jako nap��klad pevnost nasazen� hrotu na rati�t� nebo v�b�r materi�lu pro ob� sou��sti.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item034.png" width="34px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Z�ke�n� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Troj�heln�kov� tvar hrotu zp�sobuje obzvl�t� v�n� zran�n�, kter� se nehoj� lehce ani snadno. Runov� za��kadla vyryt� na jeho rati�ti vypov�daj� o okouzlen�, jeho� ��elem bylo zes�lit ��inek troj�heln�kov�ho hrotu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item035.png" width="28px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Prvot��dn� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>13</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kov��sk� zna�ka a letopo�et prozrazuj�, �e toto kop� bylo ukov�no v magick�ch zbroj��stv�ch vl�dce Padishe 12 let p�ed dobou Ticha.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="05">Halapartny</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item036.png" width="57px" height="287px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Halapartna</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Stejn� jako v�echny halapartny je i tato ve skute�nosti sekyrou na velmi dlouh�m rati�ti. Je to v�estrann� zbra� sdru�uj�c� v�hody kop� pro boj v omezen�m prostoru nebo hole vhodn� pro obranu. Tento exempl�� je b�n�ho materi�lu i zpracov�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item038.png" width="63px" height="286px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">T�k� halapartna</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Rati�t� t�to halapartny je vydlaban� a napln�n� olov�n�m j�drem. P�i �deru zbran� se olov�n� j�dro vymr�t� s hlasit�m rachotem k �epeli a zes�l� tak s�lu a �vih r�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item037.png" width="47px" height="296px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mocn� halapartna</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� zna�ka na hrotu halapartny prozrazuje, �e byla ukov�na v proslul� mekorigsk� v�hni samotn�m mistrem Mekorigem Slep�m. T�ko v �ir�m sv�t� najde� lep�� halapartnu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>700</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="06">Trojzubce</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item039.png" width="39px" height="268px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trojzubec</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Trojzubec - ur�it� obdoba selsk�ch vidl�; byl od po��tk� pou��v�n ryb��i. Nyn� je to tradi�n� zbra� n�mo�n�ch bojovn�k� po cel�m sv�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item040.png" width="40px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ostnat� trojzubec</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Konce hrot� tohoto trojzubce jsou vybaveny zp�tn�mi ostny, co� vylep�uje z�kladn� konstrukci zbran�. P�i vytr�en� zbran� z ob�ti zp�sobuje tato �prava rozs�hl� zran�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item041.png" width="57px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�le�n� trojzubec</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Styl obl�ben� u Regnansk�ho c�sa�sk�ho n�mo�nictva. Dva postrann� hroty tohoto trojzubce jsou tenk� a ostr�, co� umo��uje jak sek�n�, tak bod�n�. K dal��mu vystra�en� nep��tele slou�� i zpracov�n� hrot� v mosazi a rati�t� pomalovan� �lut�; to v�e vzbuzovalo dojem, �e Regnan� bojuj� se zlat�mi zbran�mi.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>700</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="07">Luky</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item042.png" width="52px" height="223px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Oby�ejn� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Oby�ejn� dlouh� luk vyroben� z b�n�ch materi�l� v obvykl�m proveden�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item043.png" width="56px" height="227px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dlouh� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kvalitn�j�� dlouh� luk vyroben� podle elf�ho luku, ale bez elf�ho umu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item044.png" width="46px" height="211px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elf� dlouh� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Leptan� monogram na lu�i�ti prozrazuje p�vod zbran�, vyroben� v d�ln� mistra luka�e Ivana Selvinga b�hem Timbersk�ch v�lek kolem roku 600.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item045.png" width="63px" height="228px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kompozitn� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kompozitn� luky jsou vyrobeny z rozli�n�ch materi�l� a d�l� nam�sto jednoho kusu d�eva. Obecn� jsou v�estrann�j�� a siln�j�� ne� b�n� luky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item046.png" width="95px" height="204px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Gryf� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Hr�zu nah�n�j�c� sou��stky tohoto luku - gryf� lebka a d�ly p�te�e se pou��vaj� k v�rob� obzvl�t� pevn�ch a siln�ch luk�. Net�eba dod�vat, �e tyto d�ly lze obt��n� z�skat, nebo� gryfov� se br�n� zu�iv�ji ne� tisy.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="08">Ku�e</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item047.png" width="52px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ku�e</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">A�koli maj� ku�e mnoho v�hod, uzam�en� t�tivy, v�t�� pr�raznost nebo snadn� ovl�d�n�, nelze je srovn�vat s dlouh�m lukem, co se t�k� dost�elu a rychlosti.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item048.png" width="39px" height="122px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">T�k� ku�e</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Takov� ku�e nashrom�dil Archibald kr�tce p�ed vypuknut�m N�slednick� v�lky proti sv�mu bratrovi. Jako v p��pad� jin�ch rozhodnut� t�kaj�c�ch se smrti, i tentokr�t zvolil Archibald moud�e. Jde o nejlep�� ku�e na zemi.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item049.png" width="64px" height="127px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ide�ln� ku�e</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto mimo��dn� ku�e, kter� jsou vybaveny natahovac� klikou a m��idly, jsou lep�� ne� kter�koliv ku�e p�ed nimi. P�esto je ale jejich p�vod dodnes zahalen tajemstv�m?</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="09">Palc�ty a �emdihy</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item050.png" width="31px" height="137px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Palc�t</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jen m�rn� vyt��ben�j�� ne� oby�ejn� sochor, ale i tak o n�co ��inn�j�� a trvanliv�j��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item051.png" width="39px" height="137px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ostnat� palc�t</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbra� je navr�ena tak, aby dostate�n� ohro�ovala obrn�n� i neobrn�n� protivn�ky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item052.png" width="43px" height="131px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Palc�t fanatik�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">B�n� palc�t z Karigoru vynik� vy��� kvalitou, podobn� jako v�echny ostatn� zbran� a v�zbroj z tohoto ostrova.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item053.png" width="40px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trpasli�� �emdih</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�emdih, ur�it� varianta palc�tu, je typick� sn��enou rychlost�, ale zv��enou ��innost�. Trny na kovov� kouli zaru�uj�, �e zasa�en� uc�t� s�lu �deru bez ohledu na sv�j panc�� nebo kryt.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item054.png" width="53px" height="132px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Prvot��dn� �emdih</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento �emdih je t�m�� stejn� z�ludn� pro majitele jako pro jeho protivn�ka. Tento druh pat�� mezi nejkvalitn�j�� a nav�c je o�arov�n cechem �arod�jnic z Nighonu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="10">Kladiva</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item055.png" width="31px" height="129px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kladivo</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Hrub� zbra�, p�ipom�naj�c� sp��e n�stroj, je dopln�na z�p�stn�m �et�zkem, kter� m� zabr�nit jej�mu upu�t�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>120</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item056.png" width="51px" height="126px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�le�n� kladivo</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbra� je pokro�ilej�� konstrukce a je obl�ben� u v�ech humanoidn�ch protivn�k�. Vzhledem k tomu, �e v�ichni v�d�, �e tito humanoidi zbran� nevyr�b�j�, vznik� ot�zka, 'kde k t�m zbran�m vlastn� p�i�li?'?</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item057.png" width="52px" height="122px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trpasli�� kladivo</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jde o nejvysp�lej�� zbra� mezi kladivy. Trpasli�� kladiva poch�zej� z v�hn� Kamenn�ho m�sta a ka�d� jejich vlastnost je vynikaj�c� - vyv�en�, celkov� v�ha, materi�l n�sady i konstrukce jeho hlavy. P�edstavuje to nejlep��, �eho lze modern�mi metalurgick�mi postupy dos�hnout.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="11">Kyje</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item058.png" width="23px" height="156px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kyj</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Primitivn� zbra� u��van� t�mi nejhloup�j��mi monstry. Tento kyj byl vyroben ze d�eva Erathijsk�ho dubu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item059.png" width="28px" height="122px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ostnat� kyj</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vylep�en�m b�n�ho kyje vznik� ostnat� kyj, kter�m lze zasadit krvav�j�� r�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item060.png" width="34px" height="138px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� kyj</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Symetrie a d�lka hlavice tohoto kyje je to jedin�, co jej odli�uje od palc�tu. Vyv�en� je dobr�, konstrukce solidn�, ale st�le je to jen kyj, a proto od n�ho nem��e� mnoho o�ek�vat. Pravd�podobn� poch�z� od Goblin�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="12">Hole</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item061.png" width="21px" height="261px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�l</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�l je roz���enou zbran� utla�ovan�ch.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item062.png" width="26px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�l se �elezn�m j�drem</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato h�l je uvnit� vypln�na �elezem, co� oproti b�n�m hol�m zvy�uje s�lu �deru. Vzhledem se ale p�esto nijak neli�� od oby�ejn� par�dn� vych�zkov� hole. Vyrobena je z le�t�n�ho jasanov�ho d�eva a zdoben� kr�sn�m ryt�m vzorem.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item063.png" width="28px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kouzelnick� h�l</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tajupln� kombinace d�eva, skla a hlin�ku tvo�� z�klad hole korunovan� na horn�m konci k�i���lovou lebkou. Cel� zbra� je spojena lepidlem i siln�mi kouzly, pro�e� jde o nejleh�� a p�itom nejpevn�j�� h�l na sv�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="13">Blastery</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item064.png" width="34px" height="61px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Blaster</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d5+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zbra� ��asn� s�ly byla zcela ur�it� vyrobena v �asech Z�zrak�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>0</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/item065.png" width="41px" height="124px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Blasterov� pu�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d5+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nejskv�lej�� osobn� zbra�, blasterov� pu�ka, byla vyrobena b�hem �asu Z�zrak� a dok�e rozs�vat smrt rychleji ne� kter�koliv jin� zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>0</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
