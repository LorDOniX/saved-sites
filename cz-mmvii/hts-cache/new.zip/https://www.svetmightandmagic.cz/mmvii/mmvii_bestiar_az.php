<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Abecedn� seznam monster</h2>
   <p>&nbsp;</p>
   <p>N�sleduj�c� seznam je abecedn�m seznamem monster, kter� se na kontinentu nach�zej�. Jsou v n�m vynech�ny postavy neutr�ln�ch  obyvatel m�st, oblast� a dungeon� (r�zn� d�ln�ci apod.). Ka�d� postava/nestv�ra je sou��st� ur�it� skupiny postav/monster, kter� jsou mimo jin� rozeps�ny na �vodn� str�nce <a href="mmvii_bestiar.php">besti��e</a> (zde najdete i vysv�tlivky k popisu). Odkaz u vybran� polo�ky v�s automaticky p�enese na str�nku dan� skupiny, tak�e krom vybran� nestv�ry uvid�te i charakteristiky zbyl�ch dvou nestv�r ze skupiny. Proto�e barevn� zobrazen� m��e zna�n� z�viset i na nastaven� hardwarov� akceleraci, doporu�uji si pro��st kapitolku <a href="../pmm/pmm_akceleram7m8.php">Pot��e s barevn�m zobrazen�m</a>.</p>
   <p>&nbsp;</p>
   
   <ul>
      <li><a href="mmvii_bzobrazeni.php?id=01">And�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=01">And�l vl�dce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=24">Arcim�g</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=01">Archand�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=02">Bandita</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=47">Ba�inn� trol</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=03">Behemot</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=25">Bleskov� krysa</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=04">Bojovnice</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=45">Bou�kov� tit�n</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=16">Bronzov� golem</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=29">C�sa�ovna med�z</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=52">Cykl�n</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=24">�arod�j</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=35">�ern� vdova</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=06">��belsk� kapit�n</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=06">��belsk� poskok</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=06">��belsk� v�le�n�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=13">D�s</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=44">Dobrodruh</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=56">Dra�� �ralok</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=08">Duch</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=08">Duch mohyl</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=09">D�in</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=09">D�inek</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=09">Efr�t</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=10">Elf� hrani���ka</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=11">Elf� kopin�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=10">Elf� lu�i�tnice</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=11">Elf� obr�nce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=10">Elf� pr�zkumnice</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=11">Elf� v�le�n�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=28">Elitn� lukost�elec</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=40">Fantom</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=13">Gh�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=14">Goblin</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=15">Gog</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=15">Gogl�nek</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=17">Gryf</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=18">Harpyje</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=37">Hl�dkov� robot</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=53">Hlin�n� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=14">Hobgoblin</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=47">Horsk� trol</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=38">Hromov� pt�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=19">Hydra chaosu</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=55">Chod�c� mrtvola</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=35">Jedovat� pavouk</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=20">Je�t�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=53">Kamenn� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=12">Kamenn� chrli�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=21">Klerik M�s�ce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=22">Klerik Slunce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=21">Kn�z M�s�ce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=22">Kn�z Slunce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=23">Kostlivec</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=24">Kouzeln�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=27">Kr�l lich�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=18">Kr�lovna harpyj�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=29">Kr�lovna med�z</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=32">Kr�lovna mrtv�ch</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=46">Kr�lovna troglodyt�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=50">Kr�lovna v�ek</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=17">Kr�lovsk� gryf</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=45">Krvav� tit�n</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=26">L�taj�c� oko</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=27">Lich</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=37">Likvida�n� robot</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=17">Loveck� gryf</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=28">Lu�i�tn�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=28">Lukost�elec</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=54">Lupi�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=15">Magog</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=42">Mal� sv�teln� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=57">Mantikora</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=29">Med�za</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=57">Minikora</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=30">Minotaurus</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=30">Minotau�� kat</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=31">Mistr</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=43">Mistr me�e</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=54">Mistr zlod�j</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=03">Mlad� behemot</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=32">Mluv�� za mrtv�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=31">Mnich</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=27">Mocn� lich</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=07">Modr� drak</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=16">Mosazn� golem</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=12">Mramorov� chrli�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=36">Mu� s blasterem </a></li>
      <li><a href="mmvii_bzobrazeni.php?id=02">N�jezdn�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=32">Nekromancer</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=21">Novic M�s�ce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=22">Novic Slunce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=25">Ob�� krysa</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=33">Ob�� netop�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=35">Ob�� pavouk</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=56">Ob�� �ralok</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=12">Obsidi�nov� chrli�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=05">Ohniv� �arod�jnice</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=19">Ohniv� hydra</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=25">Ohniv� krysa</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=50">Ohniv� v�ka</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=34">Ohniv� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=34">Ohniv� hl�da�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=34">Ohniv� str�ce</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=26">Oko zla</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=33">Pekeln� netop�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=56">Piran� �ralok</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=26">Pozorovatel</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=37">Pr�zkumn� robot</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=08">P��zrak</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=02">Raub��</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=04">Rekrutka</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=36">Robert Moudr�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=20">Rohat� je�t�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=38">Roch</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=39">Rub�nov� sliz</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=07">Rud� drak</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=47">���n� trol</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=39">Saf�rov� sliz</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=55">Shnil� mrtvola</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=39">Smaragdov� sliz</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=18">Star� harpyje</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=03">Starov�k� behemot</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=20">Starov�k� je�t�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=49">Star�� up�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=40">St�n</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=40">Stra�idlo</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=44">Str�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=41">Strom</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=41">Strom</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=41">Strom</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=42">Sv�teln� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=51">Sylfa</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=43">�ampi�n me�e</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=44">�erm��</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=57">�korpikora</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=45">Tit�n</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=36">Tolberti</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=46">Troglodyt� trubec</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=46">Troglodyt� voj�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=48">Trpasli�� pobo�n�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=48">Trpasli�� velitel</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=48">Trpasli�� voj�k</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=49">Up�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=33">Up��� netop�r</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=49">Up��� p�isluhova�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=23">V�le�n� kostlivec</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=50">V�ka</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=38">Velk� roch</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=42">Velk� sv�teln� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=52">Vichr</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=05">Vodn� �arod�jnice</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=51">Vodn� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=51">Vodn� sk��tek</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=04">Voj�nka</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=14">V�dce goblin�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=23">V�dce kostlivc�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=30">V�dce minotaur�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=05">Vzdu�n� �arod�jnice</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=19">Vzdu�n� hydra</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=52">Vzdu�n� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=31">Zasv�cenec</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=43">Zasv�cenec me�e</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=07">Zelen� drak</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=53">Zemsk� element�l</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=13">Zjeven�</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=16">Zlat� golem</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=54">Zlod�j</a></li>
      <li><a href="mmvii_bzobrazeni.php?id=55">Zombie</a></li>

   </ul>

   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
