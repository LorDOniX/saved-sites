<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {border: solid 1px maroon;}
      table {border: solid 1px maroon; /*border-collapse: separate;*/}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Zaj�mavosti, n�pady, triky</h2>
   
   <p>Aneb v�e okolo sedm�ho d�lu, co se neve�lo jinam, nebo si zaslou�� b�t zm�n�no zvlṻ.</p>
   
   <h3>Nep�emo�iteln� Tolberti a Robert Moudr�?</h3>
   
   <p>Z pohledu hry se jedn� o jasnou podp�sovku, proto�e abyste tento souboj dali opravdu �ist�, mus�te m�t vesm�s specificky slo�enou dru�inu a nav�c je�t� spr�vn� zvolenou cestu. Samoz�ejme, skute�n� hrdina loaduje tak dlouho, dokud souboj s jedn�m z t�chto akt�r� prost� ned� a opravdu to jde, ale je to hodn� o �t�st�. Vyplat� se kv�li tomu p�epnout do tahov�ho re�imu. Pokud m�te v dru�in� klerika, tak m�te vyhr�no, proto�e Ochrana p�ed magi� je pr�v� to, co v�m pom��e. V ostatn�ch p��padech dob�e zab�r� taktika ml�cen� p�es roh.</p>
   
   <p>Ale t�m v��et mo�nost� nekon��. Vzpome�te si, z jak�ch povol�n� se skl�d� defaultn� dru�ina? Je tam zlod�j. A zlod�j je jedinou postavou, kter� se um� nau�it kraden�, co� se n�m tu n�ramn� hod�. S pomoc� neviditelnosti se daj� oba akt��i o kontroln� kostku okr�st, ani� byste jim zk�ivili jedin� vl�sek na hlav�. Osobn� m�m v��i zlod�ji averzi, ale tento tip u� mi byl n�kolikr�t doporu�en, tak�e nem�m pochyb, �e je pln� funk�n� ;)</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
