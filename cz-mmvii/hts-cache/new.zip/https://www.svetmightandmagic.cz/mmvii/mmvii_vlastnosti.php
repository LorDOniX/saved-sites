<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Vlastnosti postav</h2>
   <p>&nbsp;</p>

   <p>Mezi vlastnosti postav se �ad� z�kladn� vlastnosti (prim�rn� atributy), kter�mi je postava obda�ena od sv�ho zrodu. Pat�� sem s�la, inteligence, osobnost, odolnost, p�esnost, rychlost, �t�st� a odolnosti (ohe�, vzduch, zem�, mysl, t�lo). Prim�rn� vlastnosti maj� p��m� vliv na odvozen� vlastnosti (sekund�rn� atributy), kam �ad�me zdrav�, manu, t��du zbroje, �to�n� bonus a zran�n�. Atributy se od <a href="mmvii_dovednosti.php">dovednost�</a> li�� pr�v� t�m, �e se jedn� o z�kladn� charakteristiky, se kter�mi se postava "rod�" a jsou v�em postav�m spole�n�. Dovednost je naproti tomu druhotn� vlastnost, kterou postava z�sk�v� u�en�m. Dovednosti pak mohou m�t zp�tn� vliv na atributy a naopak, n�kter� dovednosti se nelze bez dan� velikosti ur�it�ho atributu nau�it (nap�. odolnost versus posilov�n�).</p>

   <h3>Z�kladn� vlastnosti</h3>

   <p><span class="tucne">S�la</span></p>

   <p>S�la je ukazatel, kter� p�edstavuje fyzickou s�lu a schopnost postavy vynalo�it takovou s�lu, jak� je zrovna pot�eba. Postava s velkou silou d�v� v boji v�t�� �kody.</p>

   <p><span class="tucne">Inteligence</span></p>

   <p>Inteligence p�edstavuje schopnost postavy p�em��let a porozum�t slo�it�m abstraktn�m pojm�m. U zlod�je, kouzeln�ka, lui�tn�ka, hrani���e a druida vysok� inteligence p�isp�v� k v�t��mu mno�stv� jejich many.</p>

   <p><span class="tucne">Osobnost</span></p>

   <p>Osobnost p�edstavuje s�lu v�le a osobn� �arm postavy. U klerika, paladina, hrani���e, mnicha a druida m� osobnost vlvi na mno�stv� jejich many.</p>

   <p><span class="tucne">Odolnost</span></p>

   <p>Odolnost je m�ra t�lesn� hou�evnatosti a vytrvalosti postavy. Vysok� odolnost d�v� postav� v�t�� zdrav�.</p>

   <p><span class="tucne">P�esnost</span></p>

   <p>P�esnost vystihuje, jak p�esn� jsou �toky postavy a koordinace oko-ruka. Vysok� p�esnost umo�n� postav� v boji zas�hnout nestv�ru �ast�ji.</p>

   <p><span class="tucne">Rychlost</span></p>

   <p>Rychlost ud�v�, jak je postava rychl�. Vysok� rychlost zvy�uje t��du zbroje postavy a uruje, jak rychle se postava z �toku zotav�.</p>

   <p><span class="tucne">�t�st�</span></p>

   <p>�test� m� jemn� vliv skoro v�ude ve h�e, ale nejv�ce je viditeln� v schopnosti postavy odol�vat magick�m �tok�m a vyhnout se v�n�j��mu zran�n� zp�soben�mu pastmi.</p>
   
   <h3>Odvozen� vlastnosti</h3>
   
   <p><span class="tucne">Zdrav�</span></p>

   <p>Zdrav� ud�v�, jakou �jmu postava snese, ne� upadne do bezv�dom� nebo zem�e. Do bezv�dom� postava upadne tehdy, pokud ji zdrav� klesne na nulu nebo m�n�. Pokud klesne do z�poru v�ce, jak je hodnota odolnosti, postava zem�e. Zdrav� se obnov� po 8 hodin�ch nep�etr�it�ho odpo�inku.</p>
   
   <p><span class="tucne">Mana</span></p>

   <p>Mana je nun� pro ses�l�n� kouzel. Ka�d� kouzlo stoj� ur�it� po�et bod� many, kter� se p�i zakouzlen� ode��taj� z celkov�ho po�tu. Mana se obnov� po 8 hodin�ch nep�etr�it�ho odpo�inku.</p>
   
   <p><span class="tucne">T��da zbroje</span></p>

   <p>T��da zbroje ur�uje, jak obt��n� je pro nestv�ru zas�hnout postavu. ��m je t��da zbroje vy���, t�m je v�t�� �ance na vyhnut� se �toku.</p>
   
   <p><span class="tucne">�tok (�to�n� bonus)</span></p>

   <p>Je sou�et v�ech faktor� (dovednost, kouzla, p�esnost atd.), kter� maj� vliv na �anci, �e tv� postava danou zbran� nestv�ru ��inn� zas�hne.</p>
   
   <p><span class="tucne">Zran�n�</span></p>

   <p>Je sou�et v�ech faktor� (s�la, kouzla, �rove� dovednosti atd.), kter� maj� vliv na �kody zp�soben� postavou danou zbran�.</p>
   
   <p><span class="tucne">Ohe�</span></p>

   <p>Odolnost proti ohni p�edstavuje schopnost postavy minimalizovat �kody od kouzel ohn�. ��m vy��� je odolnost, t�m jsou utrp�n� �kody men��, ale postava proti nim nebude zcela imunn�.</p>
   
   <p><span class="tucne">Vzduch</span></p>

   <p>Odolnost proti vzduchu p�edstavuje schopnost postavy minimalizovat �kody od kouzel vzduchu. ��m vy��� je odolnost, t�m jsou utrp�n� �kody men��, ale postava proti nim nebude zcela imunn�.</p>
   
   <p><span class="tucne">Voda</span></p>

   <p>Odolnost proti vody p�edstavuje schopnost postavy minimalizovat �kody od kouzel vody. ��m vy��� je odolnost, t�m jsou utrp�n� �kody men��, ale postava proti nim nebude zcela imunn�.</p>
   
   <p><span class="tucne">Zem�</span></p>

   <p>Odolnost proti zemi p�edstavuje schopnost postavy minimalizovat �kody od kouzel zem�. ��m vy��� je odolnost, t�m jsou utrp�n� �kody men��, ale postava proti nim nebude zcela imunn�.</p>
   
   <p><span class="tucne">Mysl</span></p>

   <p>Odolnost proti mysli p�edstavuje schopnost postavy minimalizovat �kody od kouzel mysli. ��m vy��� je odolnost, t�m jsou utrp�n� �kody men��, ale postava proti nim nebude zcela imunn�.</p>
   
   <p><span class="tucne">T�lo</span></p>

   <p>Odolnost proti t�lu p�edstavuje schopnost postavy minimalizovat �kody od kouzel t�la. ��m vy��� je odolnost, t�m jsou utrp�n� �kody men��, ale postava proti nim nebude zcela imunn�.</p>
   
      <h3>Ovlivn�n� z�kladn�ch vlastnost�</h3>

   <p>Zvy�ov�n� prim�rn�ch vlastnost� je mo�n� b�hem tvorby postavy, jak nazna�uje n�sleduj�c� tabulka, nebo m��eme vyu��vat konzumace magick�ch n�poj� v sudech a pou��v�n� bonusov�ch p�edm�t� ve h�e. Tabulka ukazuje po��te�n� hodnoty atribut� pro jednotliv� povol�n�. Startovn� hodnoty je mo�no b�hem tvorby dru�iny zvy�ovat i sni�ovat, proto je uvedeno i mo�n� rozp�t� hodnot. Uveden� rozsahy jsou platn� pro jak�koliv povol�n�.</p>
   
   <table cellpadding="0" cellspacing="0" border="1" width="600px">
      <tr class="hlavicka_tabulky">
         <td style="width: 50px">Rasa</td>
         <td style="width: 70px">�rove�</td>
         <td style="width: 65px">S�la</td>
         <td style="width: 70px">Inteligence</td>
         <td style="width: 70px">Osobnost</td>
         <td style="width: 70px">Odolnost</td>
         <td style="width: 70px">P�esnost</td>
         <td style="width: 70px">Rychlost</td>
         <td style="width: 65px">�t�st�</td>
      </tr>
      <tr>
         <td rowspan="3">�lov�k</td>
         <td>Minim�ln�</td>
         <td>9</td>
         <td>9</td>
         <td>9</td>
         <td>7</td>
         <td>9</td>
         <td>9</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Startovn�</td>
         <td>11</td>
         <td>11</td>
         <td>11</td>
         <td>9</td>
         <td>11</td>
         <td>11</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Maxim�ln�</td>
         <td>25</td>
         <td>25</td>
         <td>25</td>
         <td>25</td>
         <td>25</td>
         <td>25</td>
         <td>25</td>
      </tr>
      <tr>
         <td rowspan="3">Elf</td>
         <td>Minim�ln�</td>
         <td>5</td>
         <td>12</td>
         <td>9</td>
         <td>5</td>
         <td>12</td>
         <td>9</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Startovn�</td>
         <td>7<sup>*)</sup></td>
         <td>14<sup>**)</sup></td>
         <td>11</td>
         <td>7<sup>*)</sup></td>
         <td>14<sup>**)</sup></td>
         <td>11</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Maxim�ln�</td>
         <td>15</td>
         <td>30</td>
         <td>30</td>
         <td>15</td>
         <td>30</td>
         <td>25</td>
         <td>20</td>
      </tr>
      <tr>
         <td rowspan="3">Trpasl�k</td>
         <td>Minim�ln�</td>
         <td>12</td>
         <td>9</td>
         <td>9</td>
         <td>12</td>
         <td>5</td>
         <td>5</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Startovn�</td>
         <td>14<sup>**)</sup></td>
         <td>11</td>
         <td>11</td>
         <td>14<sup>**)</sup></td>
         <td>7<sup>*)</sup></td>
         <td>7<sup>*)</sup></td>
         <td>9</td>
      </tr>
      <tr>
         <td>Maxim�ln�</td>
         <td>30</td>
         <td>25</td>
         <td>25</td>
         <td>30</td>
         <td>15</td>
         <td>15</td>
         <td>20</td>
      </tr>
      <tr>
         <td rowspan="3">Goblin</td>
         <td>Minim�ln�</td>
         <td>12</td>
         <td>5</td>
         <td>5</td>
         <td>9</td>
         <td>9</td>
         <td>12</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Startovn�</td>
         <td>14<sup>**)</sup></td>
         <td>7<sup>*)</sup></td>
         <td>7<sup>*)</sup></td>
         <td>11</td>
         <td>11</td>
         <td>14<sup>**)</sup></td>
         <td>9</td>
      </tr>
      <tr>
         <td>Maxim�ln�</td>
         <td>30</td>
         <td>15</td>
         <td>15</td>
         <td>25</td>
         <td>25</td>
         <td>30</td>
         <td>20</td>
      </tr>
   </table>
   
   <p>*) zv�t�en� vlastnosti o jeden bod stoj� 2 body, **) jeden bod zv�t�� vlastnost o dva body</p>
   
   <p>&nbsp;</p>
   
   <p>Tabulka je od t� z osm�ho d�lu odli�n� pr�v� proto, �e zde m�me mo�nost si k libovoln�mu povol�n� zvolit libovolnou rasu. Ka�d� rasa se pak li�� startovn�mi podm�nkami. V �est�m d�le existovala jen jedna rasa a v osm�m d�le byla rasa v�z�na na konkr�tn� povol�n�, tak�e se to zjednodu�ilo. Samoz�ejm�, �e pokud postav�m stejn�ho povol�n�, ale rozd�ln� rasy, navol�te shodn� hodnoty odolnosti, inteligence nebo odolnosti, tak se nebudou mezi sebou li�it. Rasy jsou jen bonusem ke h�e, proto�e vhodnou volbou si m��ete d�ky r�zn�m bonus�m za rasu zna�n� usnadnit po��tek hran�. Jak se vliv dan�ho atributu projev� na p��slu�n� vedlej�� vlastnosti je st�le ur�ov�no povol�n�m. Nap�. se zvy�uj�c� se odolnost� (za ka�d� dva body) se zvy�uje zdrav� bojovn�k� o 5 bod�, zat�mco m�g�m jen o 2 body. Naopak, m�g�m se bude s rostouc� inteligenc� zvy�ovat mana.</p>
   <p>Kdy� u� jsem ty rasy nakousl, tak je rovnou proberu cel�. K dispozici m�me celkem �ty�i rasy, kter� si m��eme do dru�iny vybrat. Jsou to lid�, elfov�, trpasl�ci a goblini.</p>
   <p><span class="tucne">Lid�</span> jsou pr�m�rn� rasa, kter� neopl�v� ��dn�mi speci�ln�mi vlastnosti a nemaj� ��dn� postihy. Jsou proto ve v�b�ru povol�n� univerz�ln�.</p>
   <p><span class="tucne">Elfov�</span> jsou od p��rody inteligentn� a d�ky dobr�mu zraku jsou v boji velmi p�esn�. Vzhledem k drobnosti sv�ch postav jsou v�ak slab� a maj� ni��� odolnost. Mezi elfy nalezneme mnoho m�g�. Jeden bod zv��� inteligenci a p�esnost o 2 body, na zv��en� s�ly a odolnosti o jeden bod jsou t�eba body dva.</p>
   <p><span class="tucne">Trpasl�ci</span> jsou zn�m� svou silou a odolnost�. �ivot pod zem� za tlumen�ho sv�tla lou�� a sv�c� jim v�ak oslabil zrak a mal� zavalit� postava neopl�v� p��li�nou rychlost�. Jsou jako stvo�eni pro boj. Jeden bod zv��� s�lu a odolnost o 2 body, na zv��en� p�esnosti a rychlosti o jeden bod jsou t�eba body dva.</p>
   <p><span class="tucne">Goblini</span> jsou siln� stvo�en�, kter� se d�ky sv� t�lesn� stavb� dok�� rychle pohybovat. Neopl�vaj� v�ak p��li�nou inteligenc� a o osobnosti se ned� prakticky hovo�it v�bec. Proto nejsou dobr�mi m�gy ani kleriky, za to se dok�� mocn� oh�n�t zbran�mi. Jeden bod zv��� s�lu a rychlost o 2 body, na zv��en� inteligence a osobnosti o jeden bod jsou t�eba body dva.</p>
   
   <p>Vliv z�kladn�ch vlastnost� na odvozen� vlastnosti je velmi �zce spjat s v�b�rem konkr�tn�ho povol�n�. Mno�stv� zdrav� je p��mo ovlivniteln� velikost� odolnosti a nejv�t�� bonus z odolnosti budou m�t ryt��i, nejmen�� pak kouzeln�ci. Naopak kouzeln�ci budou m�t nejvy��� bonus z inteligence, kter� zvy�uje mno�stv� many. Obecn� plat�, �e za ka�d� dva body investovan� do dan� vlastnosti se postav� zv��� sdru�en� z�kladn� vlastnost o dan� bonus. Nap�. pokud ryt��i, kter� m� bonus +5 zdrav�, p�id�me 2 body do odolnosti, pak se mu zdrav� zv��� o 5 bod�. Mnich m� tak� bonus +5, paladin, hrani���, zlod�j +4, lu�i�tn�k +3, klerik, kouzeln�k a druid +2 (+3 k man�). Vliv velikosti prim�rn�ch vlastnost� se v�ak nejv�ce projevuje jen do velikosti vlastnosti 25, pak u� se bonus za�n� projevovat a� po investici v�t��ho mno�stv� bod� a tento rozd�l se bude d�le zvy�ovat (pokud chcete v�d�t v�ce, tak se pod�vejte <a href="../pmm/pmm_vlastnosti.php">sem</a>).</p>
   <p>Tak� je dob�e patrn�, �e u ur�it�ch povol�n� nem��ete n�kter� vlastnosti p��li� sn��it. Zejm�na je to vid�t u inteligence a osobnosti. To je d�no t�m, �e pod minim�ln� �rovn� vlastnosti je hodnota many pro dan� povol�n� nulov�, tak�e postava by nemohla kouzlit. V tomto ohledu je zaj�mav� povol�n� druida, kter� m� mno�stv� many ur�ov�no inteligenc� a osobnost� z�rove�. Za ka�d� m� bonus +3 k man�. Pokud mu tedy rovnom�rn� zvy�ujete ob� vlastnosti, bude v�sledn� bonus +6 k man�. Druid je tak� povol�n�m s n�jv�t��m mno�stv�m many, co� je logick�, vzhledem k jeho kouzelnick�m schopnostem.</p>
   <p>Jen v kr�tkosti je�t� zm�n�m, �e s�la m� vliv na velikost zran�n� a p�esnost m� vliv na �to�n� bonus. S n�zkou p�esnost� bude postava p�i �toku penalizov�na. Rychlost pak ovliv�uje t��du zbroje (TZ).</p>
   
   <h3>Ovlivn�n� odvozen�ch vlastnost�</h3>

   <p>Odvozen� vlastnosti se zvy�uj� nejenom vlivem r�stu p��slu�n� prim�rn� vlastnosti, no�en�m bonusov�ch p�edm�t�, lektvary, kouzly apod., ale hlavn� se zvy�uj� s rostouc�m levelem a velk� vliv na n� m� samotn� povol�n� postavy a dosa�en� �rove� pov��en�. Ryt���m se tak bude zdrav� zvy�ovat pomaleji ne�-li �ampi�n�m. Jakmile v�ak postava pov���, dojde k dorovn�n� hodnot zdrav� a many tak, jako by postava byla pov��ena ji� od prvn�ho levelu. Nic tedy neztr�c�te. N�sleduj�c� tabulka ukazuje po��te�n� mno�stv� zdrav� a many pro jednotliv� povol�n�. Hodnoty odpov�daj� startovn�m podm�nk�m z p�edchoz� tabulky.</p>
  
   <table cellpadding="0" cellspacing="0" border="1" width="425px" style="margin-left: 15px;">
      <tr class="hlavicka_tabulky">
         <td style="width: 75px">Povol�n�</td>
         <td style="width: 70px">Vlastnost</td>
         <td style="width: 70px">�lov�k</td>
         <td style="width: 70px">Elf</td>
         <td style="width: 70px">Trpasl�k</td>
         <td style="width: 70px">Goblin</td>
      </tr>
      <tr>
         <td rowspan="2">Ryt��</td>
         <td>Zdrav�</td>
         <td>35</td>
         <td>30</td>
         <td>45</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
      </tr>
      <tr>
         <td rowspan="2">Paladin</td>
         <td>Zdrav�</td>
         <td>26</td>
         <td>22</td>
         <td>34</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>5</td>
         <td>5</td>
         <td>5</td>
         <td>3</td>
      </tr>
      <tr>
         <td rowspan="2">Hrani���</td>
         <td>Zdrav�</td>
         <td>26</td>
         <td>22</td>
         <td>34</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
      </tr>
      <tr>
         <td rowspan="2">Lu�i�tn�k</td>
         <td>Zdrav�</td>
         <td>27</td>
         <td>24</td>
         <td>33</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>5</td>
         <td>6</td>
         <td>5</td>
         <td>3</td>
      </tr>
      <tr>
         <td rowspan="2">Zlod�j</td>
         <td>Zdrav�</td>
         <td>31</td>
         <td>27</td>
         <td>39</td>
         <td>35</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
      </tr>
      <tr>
         <td rowspan="2">Mnich</td>
         <td>Zdrav�</td>
         <td>30</td>
         <td>25</td>
         <td>40</td>
         <td>35</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
      </tr>
      <tr>
         <td rowspan="2">Klerik</td>
         <td>Zdrav�</td>
         <td>23</td>
         <td>21</td>
         <td>27</td>
         <td>25</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>10</td>
         <td>10</td>
         <td>10</td>
         <td>4</td>
      </tr>
      <tr>
         <td rowspan="2">Druid</td>
         <td>Zdrav�</td>
         <td>18</td>
         <td>16</td>
         <td>22</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>7</td>
         <td>10</td>
         <td>7</td>
         <td>0</td>
      </tr>
      <tr>
         <td rowspan="2">�arod�j</td>
         <td>Zdrav�</td>
         <td>18</td>
         <td>16</td>
         <td>22</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Mana</td>
         <td>15</td>
         <td>18</td>
         <td>15</td>
         <td>9</td>
      </tr>
   </table>
   
   <p><a name="multiplikator"></a></p>
   <p>&nbsp;</p>
   
   <p>Dal�� tabulka pak ukazuje mno�stv� zdrav� a many, kter� postava dostane v dan�m povol�n� za ka�dou �rove�.</p>
   
   <table cellpadding="0" cellspacing="0" border="1" width="600px">
      <tr class="hlavicka_tabulky">
         <td rowspan="2">Povol�n�</td>
         <td colspan="3">Bod� zdrav� za �rove�</td>
         <td colspan="3">Bod� many za �rove�</td>
      </tr>
      <tr class="hlavicka_tabulky">
         <td>Z�kladn�</td>
         <td>1. pov��en�</td>
         <td>2. pov��en�</td>
         <td>Z�kladn�</td>
         <td>1. pov��en�</td>
         <td>2. pov��en�</td>
      </tr>
      <tr>
         <td>Ryt��</td>
         <td>5</td>
         <td>7</td>
         <td>9</td>
         <td>0</td>
         <td>0</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Paladin</td>
         <td>4</td>
         <td>5</td>
         <td>6</td>
         <td>1</td>
         <td>2</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Lu�i�tn�k</td>
         <td>3</td>
         <td>4</td>
         <td>6</td>
         <td>1</td>
         <td>2</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Hrani���</td>
         <td>4</td>
         <td>5</td>
         <td>6</td>
         <td>2</td>
         <td>3</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zlod�j</td>
         <td>4</td>
         <td>6</td>
         <td>8</td>
         <td>0</td>
         <td>1</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Mnich</td>
         <td>5</td>
         <td>6</td>
         <td>8</td>
         <td>0</td>
         <td>1</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Klerik</td>
         <td>2</td>
         <td>3</td>
         <td>4</td>
         <td>3</td>
         <td>4</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Druid</td>
         <td>2</td>
         <td>3</td>
         <td>4</td>
         <td>3</td>
         <td>4</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Kouzeln�k</td>
         <td>2</td>
         <td>3</td>
         <td>3</td>
         <td>3</td>
         <td>4</td>
         <td>6</td>
      </tr>
   </table>
   
   <p>&nbsp;</p>
   
   <h3>Stavy postavy</h3>
   <p>S vlastnostmi je je�t� ve velmi �zk�m kontaktu tzv. Stav postavy. Ten p�edstavuje moment�ln� stav/��inek, pod kter�m se postava nach�z�. M��e to b�t v nejjednodu��m p��pad� �nava, slabost nebo a� po ty z�va�n�j�� jako je nemoc, n�kaza a� smrt. Mnoh� z t�chto stav� maj� velmi neblah� d�sledky na bojov� schopnosti postavy a m�ly by b�t proto co nejd��ve odstran�ny (sp�nek, kouzlo Vyle� nemoc, Odstra� slabost apod.). Pro podrobn�j�� informace doporu�uji pod�vat se do ��sti <span class="tucne">Nejen pro za��te�n�ky</span> na kapitolu <a href="../pmm/pmm_vek.php">Vliv v�ku a negativn�ch stav� na vlastnosti postav</a>.</p>
   
   <p>&nbsp;</p>   
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
