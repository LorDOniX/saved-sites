<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin: 15px 15px 15px 15px;}
      td {padding: 2px;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Naj�m�n� NPC</h2>
   
   <p>Naj�m�n� NPC, neboli Non Player Character (nehern�ch charakter�), je pro Might and Magic typick�. Jejich p��tomnost pom�h� zejm�na v po��tku hry nebo u nevyv�en�ch dru�in, proto�e s jejich p��tomnost� v dru�in� se zvy�uj� ur�it� dovednosti nebo dru�iny mohou vyu��vat magick�ch dovednost� t�chto postav (nap�. kouzla L�t�n� a Ch�ze po vod�). V�t�ina NPC v�ak vy�aduje p�ed najmut�m ur�it� poplatek a krom povol�n� lupi�e bude po�adovat ur�it� obnos z ka�d�ho mno�stv� nalezen�ho zlata. N�kter� NPC se tak mohou dru�in� zna�n� prodra�it.</p>
   <p>Celkem je charakter� k najmut� oproti �est�mu d�lu m�n�, ale k najmut� zde m�te jen takov� NPC, kter� v�m budou poskytovat n�jak� bonus a t�ch je naopak v sedm�m d�le v�ce. Bohu�el je v p�ekladu p�r nep�esnost� a je mo�no n�kter� z nich zam�nit. Jedn� se o charaktery obchodn�k�, kouzeln�k� a bard�. V p��pad� obchodn�k� se jedn� v origin�le o Merchant versus Trader. Merchant je p�elo�en jako "Obchodov�n�" a Trader jako Obchodn�k. Z�ejm� tam vypadlo sl�vko Mistr obchodov�n�. U kouzeln�k� neni odli�en� ��dn�. V origin�le jde o postavy Fallen Wizard a Spellmaster. Prvn� poskytuje dru�in� kouzlo Hodinu moci, druh� p�id�v� bonus +4 do dovednost� element�rn� magie. Jak jsem vysledoval, Fallen Wizard se vyskytuje nej�ast�ji v Nighonu, kde�to jinde je sp��e Spellmaster. Posledn� p��pad se t�k� barda/bard�. Tady je oproti origin�lu velk� zm�na, proto�e p�elo�en� Bard odpov�d� v origin�le Piperovi, tedy Dud�kovi. Naopak, nepoda�ilo se mi ve h�e nal�zt charakter Diplomata a Barda jako takov�ho, jak uv�d� nap��klad seznam na Flamestryku. Domn�v�m se, �e jsou n�jak spjati s p�elo�en�m charakterem Barda, ale potvrdit to nemohu.</p>
   <p>N�sleduj�c�ch n�kolik tabulek charakter� je rozd�leno podle skupin bonus�, kter� obsa�en� NPC poskytuj�. V p��pad� NPC s v�ce bonusy je uva�ov�n jen ten hlavn�. Naleznete je mezi obyvateli, kte�� se voln� pohybuj� po jednotliv�ch oblastech. Um�st�n� NPC neni op�t jako v �est�m d�le striktn� v�z�no na p��slu�nou lokaci, p�i ka�d�m na�ten� mapy (opu�t�n� a op�tovn� vstup do oblasti, nov� hra, load autosave apod.), se pohybuj�c�m postav�m n�hodn� zm�n� charakter. Jakmile je nebudete nad�le v dru�in� pot�ebovat, m��ete je propustit. NPC se nezapojuj� do bitev a ani nejsou monstry zra�ov�na, nemus�te se o n� tedy nijak starat.</p>
   
   <h4>Obchodov�n� a finance</h4>
   
   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">obchodn�k</td>
         <td style="width: 350px">4 body k dovednosti obchodov�n�</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>obchodov�n�</td>
         <td>6 bod� k obchodov�n�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>�ejd��</td>
         <td>8 bod� k obchodov�n�, reputace klesne o jednu kategorii</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>prost�edn�k</td>
         <td>bonus 10% k nalezen�m zlat�m</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>bank��</td>
         <td>bonus 20% k nalezen�m zlat�m</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>J�dlo</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">sluha</td>
         <td style="width: 350px">spot�eba j�dla se b�hem t�bo�en� sn��� o 1 j�dlo</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>ubytovatel</td>
         <td>spot�eba j�dla se b�hem t�bo�en� sn��� o 2 j�dla</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>cik�n</td>
         <td>sn��en� spot�eba j�dla b�hem odpo�inku, obchodov�n� se zv��� o 3 body, reputace se sn��� o jednu kategorii</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kucha� </td>
         <td>vyrob� jedno j�dlo denn� (max na 14 dn�)</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>��fkucha�</td>
         <td>vyrob� dv� j�dla denn� (max na 14 dn�)</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Cestov�n�</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">pr�vodce</td>
         <td style="width: 350px">pohyb po map� je o 1 den rychlej��</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>stopa�</td>
         <td>pohyb po map� je o 2 dny rychlej��</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>v�dce</td>
         <td>pohyb po map� je o 3 dny rychlej��</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>jezdec</td>
         <td>cestov�n� ko�mo se zkr�t� o 2 dny</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>pir�t</td>
         <td>cesty lod� se o 2 dny zkr�t�, bonus 10% k nalezen�m zlat�m, reputace klesne o jednu kategorii</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>n�mo�n�k</td>
         <td>cesty lod� se o 2 dny zkr�t�</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>lodn�k</td>
         <td>cesty lod� se o 3 dny zkr�t�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>pr�zkumn�k</td>
         <td>v�echny cesty se o 1 den zkr�t�</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Kouzeln�ci</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">P�n vod</td>
         <td style="width: 350px">jednou denn� vykouzl� kouzlo Ch�ze po vod� po dobu 3 hodin</td>
         <td style="width: 130px">bere 10% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>P�n v�tru</td>
         <td>jednou denn� vykouzl� kouzlo L�t�n� po dobu 2 hodin</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>P�n bran</td>
         <td>jednou denn� vykouzl� kouzlo M�stsk� br�na na mistrovsk� �rovni (Edit podzim 2016: ve skute�nosti kouzl� P�n bran M�stskou br�nu na velmistrovsk� �rovni)</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kartograf</td>
         <td>kouzlo �arod�jovo oko na expertn� �rovni je trvale aktivn�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kaplan</td>
         <td>jednou denn� vykouzl� kouzlo Po�ehn�n� na mistrovsk� �rovni po dobu 2 hodin</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>bard</td>
         <td>jednou denn� vykouzl� kouzlo Hrdinstv� po dobu 2 hodin na mistrovsk� �rovni</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>l��itel</td>
         <td>jednou denn� vyl��� cel� dru�in� body zdrav�</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>zku�en� l��itel</td>
         <td>jednou denn� vyl��� cel� dru�in� body zdrav� a proklet� (krom� smrti a zkamen�n�)</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mistr l��itel</td>
         <td>jednou denn� vyl��� celou dru�inu, v�echna zran�n� a negativn� stavy</td>
         <td>bere 50% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kouzeln�k (Fallen Wizard)</td>
         <td>jednou denn� vykouzl� Hodinu moci po dobu 6-ti hodin</td>
         <td>bere 25% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Zbran� a zbroje</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">mistr zbran�</td>
         <td style="width: 350px">2 body k dovednosti mistr zbran�</td>
         <td style="width: 130px">bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>�erm��</td>
         <td>3 body k dovednosti mistr zbran�</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mnich</td>
         <td>2 body k dovednostem uh�b�n� a beze zbran�</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>zbrojno�</td>
         <td>2 body k dovednostem se zbran�mi a zbrojemi</td>
         <td>bere 6% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Identifikace a opravov�n�</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">u�enec</td>
         <td style="width: 350px">neomezen� identifikace p�edm�t�, +5% k z�skan�m zku�enostem</td>
         <td style="width: 130px">bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>lovec</td>
         <td>4 body do identifikace nestv�r</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mudrc</td>
         <td>6 bod� do identifikace nestv�r a p�edm�t�</td>
         <td>bere 7% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>alchymista</td>
         <td>neomezen� oprava magick�ch p�edm�t�</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kov��</td>
         <td>neomezen� oprava zbran�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>zbroj��</td>
         <td>neomezen� oprava zbroj�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>  
   </table>

   <h4>Bonusy k magick�m dovednostem postav</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">ministrant</td>
         <td style="width: 350px">2 body do dovednost� magie t�la, mysli a ducha</td>
         <td style="width: 130px">bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td style="width: 70px">zasv�cenec</td>
         <td style="width: 350px">2 body do dovednost� magie t�la, mysli a ducha</td>
         <td style="width: 130px">bere 10% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td style="width: 70px">Prel�t</td>
         <td style="width: 350px">4 body do dovednost� magie t�la, mysli a ducha</td>
         <td style="width: 130px">bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>adept</td>
         <td>2 body do dovednost� element�rn� magie</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mystik</td>
         <td>3 body do dovednost� element�rn� magie</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kouzeln�k (Spellmaster)</td>
         <td>4 body do dovednost� element�rn� magie</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>bylink��</td>
         <td>4 body do dovednosti alchymie</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>l�k�rn�k</td>
         <td>8 bod� do dovednosti alchymie</td>
         <td>bere 6% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Reputace a zku�enosti</h4>
   
   <p>Na reputaci maj� vliv i dal�� NPC, kter� jsou uvedena v jin�ch bonusech. Obvykle se toti� jedn� o vedlej�� efekt, najmut� takov� postavy reputaci sn��� o jednu kategorii (cik�ni, pir�ti, �ejd��i, lupi�i). Na mno�stv� z�skan�ch zku�enost� m� vliv i u�enec.</p>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td>u�itel</td>
         <td>bonus 10% k z�skan�m zku�enostem</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>instruktor</td>
         <td>bonus 15% k z�skan�m zku�enostem</td>
         <td>bere 7% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Vn�m�n� a odstran�n� past�</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td>m�dium</td>
         <td>5 bod� k bystrosti</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td style="width: 70px">zv�d</td>
         <td style="width: 350px">6 bod� k bystrosti</td>
         <td style="width: 130px">bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>dr�ten�k</td>
         <td>4 body k odpas�ov�n�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>z�me�n�k</td>
         <td>6 bod� k odpas�ov�n�</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>lupi�</td>
         <td>8 bod� k odpas�ov�n� a kraden�, reputace kles� o jednu kategorii</td>
         <td>nebere nic z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Bonusy k vlastnostem (�t�st�, odolnosti)</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">bl�zen</td>
         <td style="width: 350px">bonus 5 bod� ke �t�st�</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>komin�k</td>
         <td>bonus 20 bod� ke �t�st�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>za��k�va�</td>
         <td>v�echny odolnosti se zv��� trvale o 20 bod�</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
   
