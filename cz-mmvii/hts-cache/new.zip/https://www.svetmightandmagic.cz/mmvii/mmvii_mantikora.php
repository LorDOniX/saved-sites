<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Mantikory v Ar�n�</h2>
   <p>&nbsp;</p>
   
   <p>Jak u� jsem uvedl u popisku v besti��i, Mantikory byly z fin�ln� verze hry ��ste�n� odstran�ny, s ��m� jsou tak� spojeny ur�it� probl�my. Jedin� m�sto, kde se s nimi m��ete setkat je Ar�na, kter� je um� na z�klad� �daj� v datov�ch souborech vygenerovat. Ov�em pokud z�pas�te s podporou hardwarov� akcelerace (jak bylo uvedeno v kapitolce <a href="../pmm/pmm_akceleram7m8.php">Pot��e s barevn�m zobrazen�m</a>), pak se v�m klidn� m��e st�t, �e se nezobraz� jejich textura, a mantikory tak budou pr�hledn� a t�m p�dem neviditeln�. P�esto na v�s budou moci �to�it. V Ar�n� si v takov�m p��pad� snadno v�imnete, �e mezi ostatn�mi monstry jsou v�t�� mezery, kam by se ur�it� je�t� n�co ve�lo, ale kdy� se pokus�te v tomto prostoru o identifikaci, hra obvykle spadne do Windows. Pokud m�te tedy probl�m s hardwarovou akcelerac�, doporu�uji ji vypnout.</p>
   <p>V�skyt mantikor je podobn� jako v�skyt ostatn�ch monster v Ar�n� v�z�n i na aktu�ln� level postav v dru�in�. Setk�te se s nimi tedy nej�ast�ji okolo leveleu 25, kdy se na obt��nosti Vl�dce objevuj� �asto mantikory a �korpikory (n�kdy jsou v ar�n� vid�t oba typy), na ni���ch obt��nostech (Pano� apod.) se pak setk�te i s minikorami. Nad levelem 30 jejich v�skyt prudce kles�.</p>
   <p>Na obr�zc�ch n��e si m��ete v�echny t�i typy prohl�dnout, nijak se v�ak nedivte t� �rovni identifikace, �mysln� jsem pro tuto p��le�itost kouzeln�kovi zv��il dovednost identifikace nestv�r.</p>
   
   <div style="text-align: center; margin-top: 10px;">
      <img src="obrazky/m02.jpg" width="640px" height="480px" alt="" />
   </div>
   
   <div style="text-align: center; margin-top: 10px;">
      <img src="obrazky/m01.jpg" width="640px" height="480px" alt="" />
   </div>
   
   <div style="text-align: center; margin-top: 10px;">
      <img src="obrazky/m04.jpg" width="640px" height="480px" alt="" />
   </div>
   
   <p>Z�skat dostate�n� d�kaz o tom, �e mantikory disponuj� st�eleck�m �tokem je docela probl�m, proto�e screenshot se st�h� velmi �patn�. Ov�em pokud se pod�v�te na obr�zek n��e na t�lo druh� mantikory, uvid�te vodorovnou ��ru sm�rem k dru�in� ... ano, to je skute�n� st�ela :)</p>
   
   <div style="text-align: center; margin-top: 10px;">
      <img src="obrazky/m03.jpg" width="640px" height="480px" alt="" />
   </div>
   
   <div style="text-align: center; margin-top: 10px;">
      <img src="obrazky/m06.jpg" width="640px" height="480px" alt="" />
   </div>
   
   <div style="text-align: center; margin-top: 10px;">
      <img src="obrazky/m05.jpg" width="640px" height="480px" alt="" />
   </div>
   
   

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
