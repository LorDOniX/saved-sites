<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Cestov�n� po Erathii a okoln�ch zem�ch</h2>
   <p>&nbsp;</p>
   <p>Erathie se nach�z� na pom�rn� rozs�hl�m ostrov� a samotn� je obklopena n�kolika samostatn�mi ���emi. Nejv�znam�j�� z nich jsou Brakada, zem� m�g�, Deyja, zem� nekromant� a Avlee, zem� elf�. V Erathii existuj� 3 typy p�epravy. M��ete se vydat p�ky, lod� nebo vyu��t slu�eb ko�sk�ho povozu (st�j�). Lodn� p��stavy naleznete jen na �zem�ch pob�e�n�ch ���� a na Evenmorsk�ch ostrovech. Kupodivu neexistuje lodn� doprava v hust� os�dlen�m Nighonu. St�je k pozemn� p�eprav� naleznete na v�t�in� �zem�, vyjma Nighonu, Eofolu, Mohylov�m �dol� a samoz�ejm� na Evenmorsk�ch ostrovech. Trochu stranou stoj� startovn� pozice hry na Smaragdov�m ostrov�. Z n�j budete moci odcestovat lod� a� po spln�n� sout�e v�vody Markhama. Pak se sem ji� nebudete moci navr�tit. Alternativou k uveden�m zp�sob�m p�epravy je mo�nost vyu��t teleporta�n�ch kouzel. Pomoc� Lloydova maj�ku se m��ete p�epravit prakticky kamkoliv, kde si um�st�te zna�ku. Naproti tomu M�stsk� br�na v�m umo�n� p�epravu jen do oblast� s font�nou m�stk� br�ny, ze kter� se mus�te nejprve nap�t, jsou to Harmondale, Erathie, Tulareansk� les, Avlee, Nighon, J�ma a Obla�n� m�sto. Posledn� dv� jmenovan� oblasti nikde neuv�d�m samostatn�, proto�e jsou sou��st� jin�ch oblast�. Obla�n� m�sto naleznete v Brakad�, J�mu v Deyji.</p>
   <p>N�sleduj�c� schematick� mapka ukazuje rozlo�en� oblast� v Erathii, ale nenazna�uje mo�nosti p��ho cestov�n� po zemi (je to opravdu jen schema, narozd�l od MaM VI a VII neni rozlo�en� oblast� tak pravideln�). Mod�e or�movan� oblasti pat�� ostrovn�m oblastem, kam se samoz�ejm� pe�mo dostat nelze. Mapka je pon�kud zjednodu�ena, tak�e p�esn� neodpov�d� velk� map� Erathie. P�esto�e n�kter� oblasti na sebe zd�nliv� navazuj�, nelze se do ka�d� dostat tak snadno. Nap�. do Eofolu vede pouze cesta tunely pod Hromovou horou. Z�m�rn� jsem vynechal lokaci M�l�iny, proto�e mi do sch�matu pon�kud nezapad� ;)</p>
   
   <div style="text-align: center;">
   <img src="obrazky/mmvii_cestovanim.jpg" width="590px" height="784px" usemap="#mapa_slozena" /></td>
   <map name="mapa_slozena">
      <area shape="rect" coords="9,10,193,196" alt="Avlee" href="mmvii_obrazkym.php?obr=oblast08" />
      <area shape="rect" coords="202,9,387,193" alt="Tulareansk� les" href="mmvii_obrazkym.php?obr=oblast04" />
      <area shape="rect" coords="398,9,581,192" alt="Smaragdov� ostrov" href="mmvii_obrazkym.php?obr=oblast01" />
      <area shape="rect" coords="9,203,192,386" alt="Deyja" href="mmvii_obrazkym.php?obr=oblast09" />
      <area shape="rect" coords="202,203,386,386" alt="Zem� obr�" href="mmvii_obrazkym.php?obr=oblast12" />
      <area shape="rect" coords="397,203,580,385" alt="Nighon" href="mmvii_obrazkym.php?obr=oblast11" />
      <area shape="rect" coords="9,396,192,581" alt="Tatalie" href="mmvii_obrazkym.php?obr=oblast07" />
      <area shape="rect" coords="203,396,387,581" alt="Erathie" href="mmvii_obrazkym.php?obr=oblast05" />
      <area shape="rect" coords="396,397,579,580" alt="Harmondale" href="mmvii_obrazkym.php?obr=oblast02" />
      <area shape="rect" coords="9,590,192,775" alt="Brakadsk� pou��" href="mmvii_obrazkym.php?obr=oblast06" />
      <area shape="rect" coords="203,590,387,774" alt="Evenmorsk� ostrovy" href="mmvii_obrazkym.php?obr=oblast10" />
      <area shape="rect" coords="396,590,581,774" alt="Mohylov� �dol�" href="mmvii_obrazkym.php?obr=oblast03" />
   </map>
   </div>
   <p>&nbsp;</p>
   
   <script language="javascript" src="new_window.js"></script>
   <p>N�sleduj�c� t�i tabulky si kliknut�m <span class="odkaz" onclick="nove_okno('mmvii_tab02.html', 'mmvii_tab02', 940, 600)">sem</span> m��ete pro lep�� p�ehlednost zobrazit i v samostatn�m okn�.</p>
   
   <h4>St�je (��sla v z�vork�ch ud�vaj� d�lku p�epravy ve dnech)</h4>
   <table cellspacing="0" cellpadding="0" border="0" width="900px">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Lokace</td>
         <td style="width: 100px;">Pond�l�</td>
         <td style="width: 100px;">�ter�</td>
         <td style="width: 100px;">St�eda</td>
         <td style="width: 100px;">�tvrtek</td>
         <td style="width: 100px;">P�tek</td>
         <td style="width: 100px;">Sobota</td>
         <td style="width: 100px;">Ned�le</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Erathie (2)</td>
         <td>Tulareansk� les (2)</td>
         <td>Erathie (2)</td>
         <td>Tulareansk� les (2)</td>
         <td>Erathie (2)</td>
         <td>Tulareansk� les (2)</td>
         <td>Ar�na (4)</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Avlee (3)</td>
         <td>Deyja (2), Harmondale (2)</td>
         <td>Avlee (3)</td>
         <td>Harmondale (2)</td>
         <td>Avlee (3), Deyja (2)</td>
         <td>Harmondale (2)</td>
         <td>Deyja (2)</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Deyja (3), Tatalie (2)</td>
         <td>Harmondale (2)</td>
         <td>Tatalie (2), Brakadsk� pou�� (3)</td>
         <td>Deyja (3), Harmondale (2)</td>
         <td>Tatalie (2)</td>
         <td>Brakadsk� pou�� (3), Harmondale (2)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td>Erathie (3)</td>
         <td>Harmondale (5)</td>
         <td>Erathie (3)</td>
         <td>-</td>
         <td>Erathie (3)</td>
         <td>Harmondale (5)</td>
         <td>Erathie (3)</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>-</td>
         <td>Erathie (2)</td>
         <td>-</td>
         <td>Erathie (2)</td>
         <td>-</td>
         <td>Erathie (2)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Deyja</td>
         <td>Erathie (3)</td>
         <td>Tulareansk� les (2)</td>
         <td>Erathie (3)</td>
         <td>Tulareansk� les (2)</td>
         <td>Erathie (3)</td>
         <td>Tulareansk� les (2)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>-</td>
         <td>Tulareansk� les (3)</td>
         <td>Deyja (5)</td>
         <td>Tulareansk� les (3)</td>
         <td>-</td>
         <td>Tulareansk� les (3)</td>
         <td>Deyja (5)</td>
      </tr>
   </table>
   
   <p>&nbsp;</p>
   
   <h4>Lodn� doprava (��sla v z�vork�ch ud�vaj� d�lku p�epravy ve dnech)</h4>
   
   <p>Pozn�mka (jaro 2008): V ofici�ln� p��ru�ce strategie od Prima Games se z tabulky lodn� dopravy dozv�te o tom, �e lod� z Erathie a Tulareansk�ho lesa nab�zej� dv� cestovn� trasy (podobn� jako je tomu u n�kter�ch st�j�). Ve h�e je v�ak u obou lod� na v�b�r jen jedna cestovn� trasa.</p>
   
   <table cellspacing="0" cellpadding="0" border="0" width="900px">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Lokace</td>
         <td style="width: 100px;">Pond�l�</td>
         <td style="width: 100px;">�ter�</td>
         <td style="width: 100px;">St�eda</td>
         <td style="width: 100px;">�tvrtek</td>
         <td style="width: 100px;">P�tek</td>
         <td style="width: 100px;">Sobota</td>
         <td style="width: 100px;">Ned�le</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Avlee (4)</td>
         <td>Tatalie (2)</td>
         <td>Brakadsk� po�� (6)</td>
         <td>Tatalie (2)</td>
         <td>Avlee (4)</td>
         <td>Tatalie (2)</td>
         <td>Evenmorsk� ostrovy (7)</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td>Tatalie (4)</td>
         <td>Evenmorsk� ostrovy (1)</td>
         <td>Tatalie (4)</td>
         <td>Evenmorsk� ostrovy (1)</td>
         <td>Tatalie (4)</td>
         <td>Tulareansk� les (6)</td>
         <td>Erathie (6)</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Brakadsk� pou�� (6)</td>
         <td>Avlee (3)</td>
         <td>Brakadsk� pou�� (6)</td>
         <td>Avlee (3)</td>
         <td>-</td>
         <td>Avlee (3)</td>
         <td>Evenmorsk� ostrovy (7)</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Tulareansk� les (3)</td>
         <td>Erathie (4)</td>
         <td>Tulareansk� les (3)</td>
         <td>Tatalie (5)</td>
         <td>Tulareansk� les (3)</td>
         <td>Erathie (4)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Brakadsk� pou�� (4)</td>
         <td>Erathie (2)</td>
         <td>Brakadsk� pou�� (4)</td>
         <td>Erathie (2)</td>
         <td>Avlee (5)</td>
         <td>Erathie (2)</td>
         <td>Evenmorsk� ostrovy (5)</td>
      </tr>
      <tr>
         <td>Evenmorsk� ostrovy</td>
         <td>Tatalie (4)</td>
         <td>-</td>
         <td>Tatalie (4)</td>
         <td>-</td>
         <td>Tatalie (4)</td>
         <td>Tulareansk� les (6)</td>
         <td>-</td>
      </tr>
   </table>
   
   <p>&nbsp;</p>
   
   <h4>P�� p�eprava (doba cestov�n� z jedn� oblasti do sousedn� oblasti)</h4>
   <table cellspacing="0" cellpadding="0" border="0" width="900px">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Lokace</td>
         <td style="width: 100px;">Harmondale</td>
         <td style="width: 100px;">Tulareansk� les</td>
         <td style="width: 100px;">Avlee</td>
         <td style="width: 100px;">Deyja</td>
         <td style="width: 100px;">Erathie</td>
         <td style="width: 100px;">Mohylov� �dol�</td>
         <td style="width: 100px;">Brakadsk� pou��</td>
         <td style="width: 100px;">Tatalie</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Deyja</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
      </tr>
      <tr>
         <td>Mohylov� �dol�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   
   <p>P�esto�e je standardn� d�lka p��ho cestov�n� z dan� oblasti do sousedn� oblasti 5 dn�, existuje v sedm�m d�le n�kolik vyj�mek. Pokud se toti� vyd�te do sousedn� oblasti ��st�, kter� p��mo se sousedn� oblast� nesouvis�, bude d�lka p�epravy trvat o 2 dny d�le. Tedy pln�ch 7 dn�. Je to z�padn� cesta z Harmondale do Tulareansk�ho lesa, z�padn� cesta z Deyji do Erathie, ji�n� cesta z Avlee do Tulareansk�ho lesa, v�chodn� cesta z Mohylov�ho �dol� do Harmondale a ji�n� cesta z Mohylov�ho �dol� do Brakadsk� pou�t�. Je tedy t�eba si d�vat pozor, kter�m sm�rem oblast opou�t�me. S postupuj�c�m p��b�hem se n�m objev� mo�nost cestovat z Avlee do oblasti M�l�iny a cesta trv� 1 den.</p>
    
   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
