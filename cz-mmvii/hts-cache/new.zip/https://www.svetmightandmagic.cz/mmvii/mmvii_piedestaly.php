<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Piedestaly</h2>
   <p>&nbsp;</p>
   
   <p>Na r�zn�ch m�stech Erathie m�te mo�nost se v krajin� setkat se zvl�tn�m druhem svaty�, kter� postav�m do�asn� prop�j�uj� ur�it� ochrann� vlastnosti. Jedn� se o mal� sloupky s koul� ur�it� barvy, kter� se naz�vaj� piedestaly. Barva koule ur�uje, jak� kouzlo se na postavy se�le. Samotn� kouzlo je pak sesl�no na velmistrovsk� �rovni s 5 body v dovednosti (vyjma Zrychlen� a Dne Boh�, tam t�ch 5 bod� p��li� neodpov�d�). Sta�� tedy, kdy� na piedestal kliknete jen jednou postavou a kouzlo se se�le na celou dru�inu. Barevn� rozli�en� jednotliv�ch piedestal� a kouzlo, kter� k n� p��slu�� je sou��st� n�sleduj�c� tabulky.</p>
   
   <div style="text-align: center;">
   
   <table cellspacing="0" cellpadding="0px" width="64px" style="margin: auto; border: none;">
      <tr>
         <td style="border: none;"><img src="obrazky/piedestal.png" width="64px" height="128px" alt="" /></td>
      </tr>
      <tr>
         <td style="border: none;">&nbsp;</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="0" width="450px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Barva piedestalu</td>
         <td style="width: 150px;">Seslan� kouzlo</td>
         <td style="width: 200px;">V�sledn� efekt</td>
      </tr>
      <tr>
         <td>B�ov�</td>
         <td>Zrychlen�</td>
         <td>Kouzlo trv� 2 hodiny</td>
      </tr>
      <tr>
         <td>Modr�</td>
         <td>Odolnost proti vod�</td>
         <td>P�id� 20 bod� k odolnosti, kouzlo trv� 5 hodin</td>
      </tr>
      <tr>
         <td>Hn�d�</td>
         <td>Odolnost proti zemi</td>
         <td>P�id� 20 bod� k odolnosti, kouzlo trv� 5 hodin</td>
      </tr>
      <tr>
         <td>Zelen�</td>
         <td>�t�t</td>
         <td>Kouzlo trv� 6 hodin</td>
      </tr>
      <tr>
         <td>Zeleno�lut�</td>
         <td>Odolnost proti vzduchu</td>
         <td>P�id� 20 bod� k odolnosti, kouzlo trv� 5 hodin</td>
      </tr>
      <tr>
         <td>�ed�</td>
         <td>Kamenn� k��e</td>
         <td>P�id� 10 bod� k T��d� zbroje, kouzlo trv� 6 hodin</td>
      </tr>
      <tr>
         <td>Tmav� fialov�</td>
         <td>Odolnost proti mysli</td>
         <td>P�id� 20 bod� k odolnosti, kouzlo trv� 5 hodin</td>
      </tr>
      <tr>
         <td>Sv�tle fialov�</td>
         <td>Ob�tov�n�</td>
         <td>Kouzlo trv� 50 minut</td>
      </tr>
      <tr>
         <td>Tmav� �erven�</td>
         <td>Odolnost proti ohni</td>
         <td>P�id� 20 bod� k odolnosti, kouzlo trv� 5 hodin</td>
      </tr>
      <tr>
         <td>Sv�tle �erven�</td>
         <td>Odolnost proti t�lu</td>
         <td>P�id� 20 bod� k odolnosti, kouzlo trv� 5 hodin</td>
      </tr>
      <tr>
         <td>Oran�ov�</td>
         <td>Hrdinstv�</td>
         <td>Kouzlo trv� 6 hodin</td>
      </tr>
      <tr>
         <td>B�l�</td>
         <td>Den Boh�</td>
         <td>P�id� 35 bod� do v�ech sedmi statistik</td>
      </tr>
   </table>
   </div>
   
   <p>Pozn�mka: Pojmenov�n� barev berte m�rn� s rezervou, v instalaci hry, kterou jsem pro ov��en� efekt� pou�il je men�� probl�m s grafick�m zobrazen�m, tak�e jsem hodnoty barev opsal z ofici�ln� p��ru�ky (d�l� mi to z nezn�m�ch p���in jen s xp patchem). Nem�m tam tak z�eteln� rozd�ly mezi z�kladn� barvou a jej�m sv�tl�m odst�nem a u t�ch velmi sv�tl�ch m�m v�e b�l�. Ka�dop�dn� p�i najet� kurzoru my�i na piedestal se v oznamovac� oblasti okna objev� p�esn� n�zev piedestalu, tak�e se m��ete pohodln� ��dit i t�m. Kompletn� p�ehled jednotliv�ch piedestal� se�azen�ch podle barev v tabulce je vid�t na n�sleduj�c�m obr�zku (vyt�hl jsem to z datov�ho souboru).</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="600px" style="margin: auto; border: none;">
      <tr>
         <td style="border: none;"><img src="obrazky/piedestaly.png" width="600px" height="100px" alt="" /></td>
      </tr>
      <tr>
         <td style="border: none;">&nbsp;</td>
      </tr>
   </table>
   </div>
   
   <p>V�hodnost pou��v�n� piedestal� ocen�te zejm�na v po��tku hry, kdy budou m�t va�e postavy jen mal� hodnoty odolnost� nebo nebudete ovl�dat p��slu�n� klerick� kouzla na takto vysok� �rovni. V tomto ohledu je u�ite�n� zejm�na piedestal Kamenn� k��e a Hrdinstv�, kter� je tak� nejb�n�j��. S piedestalem Ob�tov�n� se setk�te jen v Eofolu.</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
