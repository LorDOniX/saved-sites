<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; border: none; text-indent: 5px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <a class="zalozka" name="00"></a>
   <h2>�apky, amulety, prsteny, opasky, h�lky</h2>
   
   <ul>
      <li><a href="#01">�apky, klobouky, koruny</a></li>
      <li><a href="#02">Opasky</a></li>
      <li><a href="#03">Prsteny</a></li>
      <li><a href="#04">Amulety</a></li>
      <li><a href="#05">H�lky</a></li>
   </ul>
   
   <h3><a class="zalozka" name="01">�apky, klobouky, koruny</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item094.png" width="57px" height="56px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Selsk� klobouk</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">B�n� textiln� klobouk s p�rem vetknut�m za stuhu pro zv��en� efektu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item095.png" width="58px" height="36px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Cestovn� �apka</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Oby�ejn� �apka, jej�m� ��elem je chr�nit hlavu cestovatele p�ed sluncem a prachem.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item096.png" width="42px" height="26px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Par�dn� �apka</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato �apka, u�it� podle posledn� m�dy, odpov�d� d��v�j��mu stylu pokr�vek hlavy pracuj�c�ch lid�. Nen� to ale sama �epice, co by bylo stylov�, je to vzor pracuj�c�ho �lov�ka, co� se mlad� �lechtici pokou�ej� napodobit, a pracuj�c� se zase sna�� vypadat jako �lechta?</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item097.png" width="63px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Koruna</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Lacin� koruna, jak� nos�vaj� goblini, aby zesm�nili lidsk� zvyky. Je vyrobena z bronzu a kameny v n� jsou sklen�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item098.png" width="60px" height="55px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�lechtick� koruna</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�kn�, pon�kud n�padn� koruna vyroben� ze zlat�ho plechu a velk�ch vysoce kvalitn�ch ametyst�. �lechtic�m tv�ho stavu dob�e padne.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item099.png" width="62px" height="59px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kr�lovsk� koruna</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Koruny jako je tato jsou �asto vyrobeny za pou�it� magie zesiluj�c� jejich p��stupnost okouzlen�. Pokud je nalezena bez okouzlen�, jde patrn� o d�lo z n�jak�ho d�vodu nedokon�en�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="02">Opasky</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item100.png" width="57px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Selsk� opasek. Tento je vyroben ze �patn� vy�in�n� k��e se �elezn�mi reziv�mi n�ty.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item101.png" width="63px" height="29px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Honosn� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�kn� zpracovan� opasek z dob�e vy�in�n� k��e a p�kn�m pro��v�n�m. P�ezka je vyrobena z le�t�n�ho st��bra.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item102.png" width="71px" height="34px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pevn� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tuh�, ale kvalitn� ko�en� opasek. Tento z�ejm� poch�z� ze z�padn� Erathie.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>225</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item103.png" width="70px" height="19px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">St��brn� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Velmi p�kn� zpracovan� st��brn� opasek. Star�, ale dob�e zachoval�. Na spoj�ch nen� patrn� ��dn� zakalen�, jen p�ezka je pon�kud za�l�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item104.png" width="71px" height="26px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zlat� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nevkusn� a� b�da. Je vyroben z prodan�ho 14 kar�tov�ho zlata. Na ka�d�m �l�nku je jin�, ne p��li� kvalitn� vyra�en� reli�f. Nevzhledn�, ale cenn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="03">Prsteny</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item120.png" width="31px" height="22px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mosazn� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Za�l� mosazn� prsten. Kdy� ho vyle�t��, mo�n� ho prod�? ale moc si od toho neslibuj.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item121.png" width="30px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Perlov� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tomuto jinak b�n�mu zlat�mu prstenu dominuje velk� nedokonal� perla.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item122.png" width="30px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Platinov� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Na prvn� pohled st��brn�, ale ve skute�nosti je tento prsten vyroben� z platiny. Kam�nek v n�m je mal�, kazov� diamant.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item123.png" width="30px" height="29px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Smaragdov� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Velk� brou�en� smaragd je zasazen do jinak oby�ejn�ho st��brn�ho prstenu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>700</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item124.png" width="30px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Saf�rov� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Do tohoto st��brn�ho a zlat�ho prstenu jsou zasazeny t�i mal� saf�ry. Prsteny t�to kvality b�vaj� �asto okouzleny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>900</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item125.png" width="33px" height="31px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arod�jnick� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato slo�it� a ok�zal� sestava ametyst� a platiny m��e b�t p�ita�liv�, pokud se ti takov� v�ci l�b�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item126.png" width="32px" height="28px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kouzeln� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Do p�kn�ho zlat�ho prstenu jsou vsazeny dva kameny v sob� - smaragd a gran�t.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item127.png" width="32px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Bly�tiv� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">N�dhern� r��ice rub�n� a smaragd� ve zlat�. Prsten samotn� je platinov�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item128.png" width="31px" height="28px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arod�jn� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">T�i dokonal� gran�ty zasazen� do st��bra kontrastuj� s magi�, j�� bylo pou�ito p�i v�rob� tohoto prstenu. P�i jeho dlouhodob�m no�en� t� za�ne brn�t ruka.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1700</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item129.png" width="31px" height="27px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">And�lsk� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Podivn� hn�d� k�men (zkamen�n� d�evo?) je zasazen do kovu, kter� vypad� jako zlato, ale je mnohem leh��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="04">Amulety</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item130.png" width="22px" height="64px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">O�n� bulva</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento zvl�tn� amulet tvo�� sklen�n� oko na levn�m mosazn�m �et�zku. Novinka, ale z�ejm� bezcenn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item131.png" width="31px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Bronzov� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nepravideln� bronzov� amulet s nejasn�m reli�fem na l�ci. Lacin� a nevkusn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item132.png" width="20px" height="54px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arod�j�in amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">K v�rob� tohoto podivn�ho st��brn�ho amuletu byl pou�it s�drov� odlitek d�tsk� ruky. V jeho st�edu je zn�t jak�si neidentifikovateln� symbol.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item133.png" width="27px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">P��v�sek se smrtihlavem</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tohle je v�c, jakou m��e� o�ek�vat od nekromant� a poch�z� p��mo z Deyje. St��brn� lebka ve st�edu p��v�sku je modelov�na podle skute�n� zmen�en� lebky a rub�ny v jej�ch o�n�ch d�lc�ch ve tm� z���.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item134.png" width="33px" height="36px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Slune�n� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vzne�en� zlat� amulet s prad�vn�m symbolem slunce uprost�ed. Poch�z� z Karigoru a jeho �emesln� zpracov�n� je dokonal�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="05">H�lky</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item135.png" width="13px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka ohn�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� proces, kter�m byla tato h�lka okouzlena, ji obarvil do nebesky modr�ho odst�nu. Je vyrobena ze d�eva a ze skla. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item135.png" width="13px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka jisker</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� proces, kter�m byla tato h�lka okouzlena, ji obarvil do nebesky modr�ho odst�nu. Je vyrobena ze d�eva a ze skla. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item135.png" width="13px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka jedu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� proces, kter�m byla tato h�lka okouzlena, ji obarvil do nebesky modr�ho odst�nu. Je vyrobena ze d�eva a ze skla. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item135.png" width="13px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka omr��en�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� proces, kter�m byla tato h�lka okouzlena, ji obarvil do nebesky modr�ho odst�nu. Je vyrobena ze d�eva a ze skla. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item135.png" width="13px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka zran�n�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� proces, kter�m byla tato h�lka okouzlena, ji obarvil do nebesky modr�ho odst�nu. Je vyrobena ze d�eva a ze skla. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item136.png" width="16px" height="153px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�l� h�lka sv�tla</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">D�ev�n� h�lka nat�en� na zeleno a kovan� mosaz�. Na jednom konci sed� velk� kazov� smaragd. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item136.png" width="16px" height="153px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�l� h�lka ledu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">D�ev�n� h�lka nat�en� na zeleno a kovan� mosaz�. Na jednom konci sed� velk� kazov� smaragd. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item136.png" width="16px" height="153px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�l� h�lka bi�e</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">D�ev�n� h�lka nat�en� na zeleno a kovan� mosaz�. Na jednom konci sed� velk� kazov� smaragd. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item136.png" width="16px" height="153px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�l� h�lka mysli</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">D�ev�n� h�lka nat�en� na zeleno a kovan� mosaz�. Na jednom konci sed� velk� kazov� smaragd. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item136.png" width="16px" height="153px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�l� h�lka roje hmyzu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">D�ev�n� h�lka nat�en� na zeleno a kovan� mosaz�. Na jednom konci sed� velk� kazov� smaragd. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item137.png" width="32px" height="132px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornsk� h�lka ohniv�ch koul�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lky, jako tato, vyroben� z dut�ho rohu jednoro�ce a korunovan� trnitou mosaznou koul�, jsou zplozeny zlem a krutost�. Jejich okouzlen� b�v� u�ite�n�, tak�e jedin�m probl�mem je, zdali si dok�e� mor�ln� zd�vodnit u��v�n� p�edm�tu tak zvr�cen� vytvo�en�ho. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item137.png" width="32px" height="132px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornsk� h�lka kyseliny</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lky, jako tato, vyroben� z dut�ho rohu jednoro�ce a korunovan� trnitou mosaznou koul�, jsou zplozeny zlem a krutost�. Jejich okouzlen� b�v� u�ite�n�, tak�e jedin�m probl�mem je, zdali si dok�e� mor�ln� zd�vodnit u��v�n� p�edm�tu tak zvr�cen� vytvo�en�ho. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item137.png" width="32px" height="132px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornsk� h�lka blesku</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lky, jako tato, vyroben� z dut�ho rohu jednoro�ce a korunovan� trnitou mosaznou koul�, jsou zplozeny zlem a krutost�. Jejich okouzlen� b�v� u�ite�n�, tak�e jedin�m probl�mem je, zdali si dok�e� mor�ln� zd�vodnit u��v�n� p�edm�tu tak zvr�cen� vytvo�en�ho. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item137.png" width="32px" height="132px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornsk� h�lka �epel�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lky, jako tato, vyroben� z dut�ho rohu jednoro�ce a korunovan� trnitou mosaznou koul�, jsou zplozeny zlem a krutost�. Jejich okouzlen� b�v� u�ite�n�, tak�e jedin�m probl�mem je, zdali si dok�e� mor�ln� zd�vodnit u��v�n� p�edm�tu tak zvr�cen� vytvo�en�ho. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item137.png" width="32px" height="132px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornsk� h�lka okouzlen�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lky, jako tato, vyroben� z dut�ho rohu jednoro�ce a korunovan� trnitou mosaznou koul�, jsou zplozeny zlem a krutost�. Jejich okouzlen� b�v� u�ite�n�, tak�e jedin�m probl�mem je, zdali si dok�e� mor�ln� zd�vodnit u��v�n� p�edm�tu tak zvr�cen� vytvo�en�ho. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item138.png" width="34px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tajemn� h�lka v�buchu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lka z le�t�n�ho ebenu korunovan� zmen�enou ozdobenou hlavou pora�en�ho nep��tele. Takov� h�lky jsou schopny pojmout siln� okouzlen�. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item138.png" width="34px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tajemn� h�lka p�sti</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lka z le�t�n�ho ebenu korunovan� zmen�enou ozdobenou hlavou pora�en�ho nep��tele. Takov� h�lky jsou schopny pojmout siln� okouzlen�. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item138.png" width="34px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tajemn� h�lka kamen�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lka z le�t�n�ho ebenu korunovan� zmen�enou ozdobenou hlavou pora�en�ho nep��tele. Takov� h�lky jsou schopny pojmout siln� okouzlen�. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item138.png" width="34px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tajemn� h�lka ochromen�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lka z le�t�n�ho ebenu korunovan� zmen�enou ozdobenou hlavou pora�en�ho nep��tele. Takov� h�lky jsou schopny pojmout siln� okouzlen�. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item138.png" width="34px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tajemn� h�lka oblak�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�lka z le�t�n�ho ebenu korunovan� zmen�enou ozdobenou hlavou pora�en�ho nep��tele. Takov� h�lky jsou schopny pojmout siln� okouzlen�. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item139.png" width="50px" height="146px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Okultn� h�lka imploze</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vz�cn� vejce f�nixe bylo uloupeno z ohn� d��ve, ne� se z n�j vyl�hlo ml�d�, aby z n�ho vznikla koruna t�to magick� h�lky. Jej� zbytek je vyroben z oceli a pozlacen. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item139.png" width="50px" height="146px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Okultn� h�lka deformace</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vz�cn� vejce f�nixe bylo uloupeno z ohn� d��ve, ne� se z n�j vyl�hlo ml�d�, aby z n�ho vznikla koruna t�to magick� h�lky. Jej� zbytek je vyroben z oceli a pozlacen. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item139.png" width="50px" height="146px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Okultn� h�lka st�epin</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vz�cn� vejce f�nixe bylo uloupeno z ohn� d��ve, ne� se z n�j vyl�hlo ml�d�, aby z n�ho vznikla koruna t�to magick� h�lky. Jej� zbytek je vyroben z oceli a pozlacen. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item139.png" width="50px" height="146px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Okultn� h�lka zmen�en�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vz�cn� vejce f�nixe bylo uloupeno z ohn� d��ve, ne� se z n�j vyl�hlo ml�d�, aby z n�ho vznikla koruna t�to magick� h�lky. Jej� zbytek je vyroben z oceli a pozlacen. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/item139.png" width="50px" height="146px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Okultn� h�lka zpopeln�n�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vz�cn� vejce f�nixe bylo uloupeno z ohn� d��ve, ne� se z n�j vyl�hlo ml�d�, aby z n�ho vznikla koruna t�to magick� h�lky. Jej� zbytek je vyroben z oceli a pozlacen. Abys ji pou�il, mus�� n� ozbrojit svou postavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
