<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>P�ekupn�ci</h2>
   <p>&nbsp;</p>
   
   <p>Ve h�e m�te mo�nost vyd�l�vat si pen�ze i t�m, �e budete po cel�m kontinentu nakupovat a p�epravovat zbo��. V mnoha oblastech naleznete p�ekupn�ka, kter� je ochoten od v�s ur�it� zbo�� koupit a z�rove� v�m jin� zbo�� prodat. Nov� zbo�� pot� op�t doprav�te jin�mu p�ekupn�kovi a prod�te mu ho za v�hodn�j�� cenu. N�sleduj�c� tabulka uv�d� seznam a um�st�n� jednotliv�ch p�ekupn�k�. ��sla v z�vork�ch ud�vaj� cenu prodeje a n�kupu.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="460px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Oblast</td>
         <td style="width: 100px;">P�ekupn�k</td>
         <td style="width: 130px;">Kupuje</td>
         <td style="width: 130px;">Prod�v�</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Rydrick</td>
         <td>tulareansk� d�evo (251 zl)</td>
         <td>hroty ��p� (200 zl)</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Robert Belknap</td>
         <td>gryf� pe�� (250 zl)</td>
         <td>tulareansk� d�evo (200 zl)</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Pip Hillier</td>
         <td>hroty ��p� (237 zl)</td>
         <td>gryf� pe�� (200 zl)</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Calindra Goldensight</td>
         <td>enrothsk� v�no (2250 zl)</td>
         <td>p�sek (2000 zl)</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Infernon</td>
         <td>sklen�n� l�hve (3000 zl)</td>
         <td>enrothsk� v�no (2000 zl)</td>
      </tr>
      <tr>
         <td>Mohylov� �dol�</td>
         <td>Arvin Beneclowd</td>
         <td>p�sek (2250 zl)</td>
         <td>sklen�n� l�hve (2000 zl)</td>
      </tr>
   </table>
   </div>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
