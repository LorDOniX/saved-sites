<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Respawn map</h2>
   <p>&nbsp;</p>
   <p>N�sleduj�c� tabulka ukazaje tzv. respawn map. Proto�e tento pojem nemus� b�t ka�d�mu z�ejm�, uvedu ve stru�nosti o� se jedn�. Ka�d� mapa, kter� se ve h�e vyskytuje, m� nastaven� ur�it� po��te�n� stav (monstra, obnoviteln� zdroje, existenci ur�it�ch postav a jejich chov�n� apod.). Jak se hrou pohybujete, doch�z� ke zm�n�m v tomto stavu. Typick�m p��kladem je zab�jen� nestv�r. Ka�d� mapa m� tedy krom po��te�n�ch podm�nek nastaven� i �as, za kter� se n�vr�t� do p�vodn�ho stavu (ten nemus� b�t striktn� toto�n� s po��te�n�mi podm�nkami). V praxi to pozn�te nejz�eteln�ji tak, �e se na ji� vy�i�t�n�ch m�stech op�t objev� p�vodn� nestv�ry. �as do respawnu je po��t�n �ist� jen jako �as ub�hl� ve h�e. B�hem respawnu se i tak��kaj�c vyma�e pam�t NPC, co� m� velk� praktick� v�znam. Pokud n�koho napadnete, tak si to dan� NPC nebude po t�to dob� ji� pamatovat. </p>

   <div style="text-align: center;">
   
   <h4>Oblasti</h4>
   
   <table width="400px" cellspacing="0" cellpadding="0" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 200px;">Oblast</td>
         <td style="width: 200px;">Respawn (dn�)</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Deyja</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hora Nighon</td>
         <td>672</td>
      </tr>
      <tr>
         <td>J�ma</td>
         <td>672</td>
      </tr>
      <tr>
         <td>M�l�iny</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Mohylov� �dol�</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Obla�n� m�sto</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Ostrov Evermorn</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Zem� obr�</td>
         <td>168</td>
      </tr>
   </table>
   </div>
   
   <div style="text-align: center;">
   
   <h4>Dungeony</h4>

   <table width="400px" cellspacing="0" cellpadding="0" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 200px;">Dungeon</td>
         <td style="width: 200px;">Respawn (dn�)</td>
      </tr>
      <tr>
         <td>Ar�na</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Cech �old�k�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Clankerova laborato�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Doly rud�ho trpasl�ka</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Dome�ek</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Dra�� jeskyn�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Dra�� sluj</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Eeofolsk� tunely</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Erathijsk� stoka</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrad Gloaming</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Hrad Gryphonheart</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Hrad Harmondale</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrad Lambent</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Hrad Navan</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Hromov� hora</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m Baa</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m M�s�ce</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m Sv�tla</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m Temnoty</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Jeskyn� bandit�</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Jeskyn� B�l�ho �tesu</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Kamenn� m�sto</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Kolonie Zod</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Labyrint</td>
         <td>672</td>
      </tr>
      <tr>
         <td>L�he�</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Lincoln</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Ml�n� st�ny</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Mohyla I</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla II</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla III</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla IV</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla IX</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla V</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla VI</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla VII</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla VIII</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla X</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla XI</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla XII</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla XIII</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla XIV</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mohyla XV</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Nighonsk� tunely</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Pevnost Riverstride</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Podivn� chr�m</td>
         <td>672</td>
      </tr>
      <tr>
         <td>P�eds�n� J�my</td>
         <td>672</td>
      </tr>
      <tr>
         <td>P��bojov� jeskyn�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>S�� pod horou</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Stra�ideln� d�m</td>
         <td>336</td>
      </tr>
      <tr>
         <td>Str�n� v� 6</td>
         <td>672</td>
      </tr>
      <tr>
         <td>�kola kouzelnictv�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Tit�nsk� pevnost</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Tulareansk� jeskyn�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Velechr�m M�s�ce</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Velechr�m Slunce</td>
         <td>672</td>
      </tr>
      <tr>
         <td>V� Williama Setaga</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Vinn� skl�pek</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Wromthraxova jeskyn�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Z�me�ek v�vody Markhama</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Zokarrova hrobka</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Ztracen� hrobka</td>
         <td>672</td>
      </tr>
   </table>
   </div>
   
   <p>V�echny hrady (Gryphonhearth, Navan, Gloaming a Lambent) se obnovuj� po 1 roce, L�he� a Ml�n� st�ny pak po ka�d�m vstupu do dungeonu.</p>
   <p>Mus�m je�t� zm�nit jednu podstatnou v�c. Ve sv�t� Might and Magic trv� hern� m�s�c 28 dn�, tedy rok m� celkem jen 336 dn�.</p>

   <p>&nbsp;</p>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
