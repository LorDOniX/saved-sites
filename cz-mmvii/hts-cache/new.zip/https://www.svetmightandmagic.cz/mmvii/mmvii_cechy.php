<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Rozm�st�n� cech� v Erathii a okol�</h2>
   <p>&nbsp;</p>
   
   <p>Od sedm�ho d�lu do�lo ke zm�n� v gildovn�m syst�mu. P�vodn� rozd�len� gild bylo zru�eno a gildy byly nav�c v �esk� verzi p�ejmenov�ny na cechy. Dovednosti se tak nyn� u��te p��mo u z�stupc� jednotliv�ch cech� (v p��slu�n�ch obchodech, chr�mech apod.). Bojov� dovednosti p�evzal cech kov���, obrann� dovednosti pak cech zbroj���. Magick� dovednosti p�evzaly jednotliv� cechy magie a ostatn� dovednosti se rozd�lily mezi cechy alchymist�, obchodn�k�, tren�r�, hospodsk�ch a chr�my, p�i�em� tyto cechy maj� v�dy shodnou nab�dku v�uky - nap�. hospoda v Harmondale v�s nau�� tot�, co hospoda v Nighonu (li�� se v�ak cenou). Pro podrobnosti se pod�vejte do n�sleduj�c� tabulky.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="500px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">Cech</td>
         <td style="width: 350px;">V�uka</td>
      </tr>
      <tr>
         <td>Tr�ninkov� haly</td>
         <td>mistrovstv� zbran�, posilov�n�</td>
      </tr>
      <tr>
         <td>Hospody</td>
         <td>kraden�, odstran�n� past�, vn�m�n�</td>
      </tr>
      <tr>
         <td>Alchymistick� obchody</td>
         <td>identifikace nestv�r, alchymie</td>
      </tr>
      <tr>
         <td>Magick� obchody</td>
         <td>identifikace v�c�, opravov�n�</td>
      </tr>
      <tr>
         <td>Chr�my</td>
         <td>beze zbran�, uh�b�n�, obchodov�n�</td>
      </tr>
   </table>
   </div>
   
   <p>N�sleduj�c� dv� tabulky pak uv�d� n�zvy jednotliv�ch cech� vyu�uj�c�ch ostatn� dovednosti a cenu za jejich v�uku.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="550px" style="margin: auto;" border="0">
      <tr>
         <td style="width: 100px;"></td>
         <td colspan="2" style="width: 150px;">Tr�ninkov� haly</td>
         <td colspan="2" style="width: 150px;">Hospody</td>
         <td colspan="2" style="width: 150px;">Chr�my</td>
      </tr>
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Oblast</td>
         <td style="width: px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>Ostrovn� cvi�i�t�</td>
         <td>500 zl.</td>
         <td>U dvou palem</td>
         <td>500 zl.</td>
         <td>L��itelin stan</td>
         <td>500 zl.</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Z�kladn� principy</td>
         <td>500 zl.</td>
         <td>Na ��et podniku</td>
         <td>500 zl.</td>
         <td>WelNinsk� katedr�la</td>
         <td>500 zl.</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Cvi�i�t�</td>
         <td>500 zl.</td>
         <td>Smaragdov� putyka</td>
         <td>500 zl.</td>
         <td>P��rodn� l��iva</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Ve slu�b�ch jej�ho veli�enstva</td>
         <td>500 zl.</td>
         <td>U Gryfa</td>
         <td>500 zl.</td>
         <td>D�m �t�chy</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td colspan="2">-</td>
         <td>P��telsk� m�sto</td>
         <td>500 zl.</td>
         <td>Chr�m sv�tla</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Z�klady tr�ninku</td>
         <td>1000 zl.</td>
         <td>U v�rn�ho �old�ka</td>
         <td>750 zl.</td>
         <td>��d Tatalie</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Avleesk� gymn�zium</td>
         <td>1000 zl.</td>
         <td>U Zpumprl�ka</td>
         <td>750 zl.</td>
         <td>Chr�m klidu</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Deyja</td>
         <td colspan="2">-</td>
         <td>U snobsk�ho goblina</td>
         <td>500 zl.</td>
         <td>Chr�m Temnoty</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Nighon</td>
         <td>U�ite�n� instrukce</td>
         <td>1250 zl.</td>
         <td>U ��astn�ho blbce</td>
         <td>1000 zl.</td>
         <td>Sb�rky a dary</td>
         <td>1250 zl.</td>
      </tr>
      <tr>
         <td>Mohylov� �dol�</td>
         <td colspan="2">-</td>
         <td>Pouze pro zlatokopy</td>
         <td>500 zl.</td>
         <td colspan="2">-</td>
      </tr>
      <tr>
         <td>Evenmorsk� ostrovy</td>
         <td colspan="2">-</td>
         <td>Sm�j�c� se mnich</td>
         <td>500 zl.</td>
         <td colspan="2">-</td>
      </tr>
      <tr>
         <td>Obla�n� m�sto</td>
         <td>Zkou�ka sl�vy</td>
         <td>750 zl.</td>
         <td>U Bo�sk�ho nektaru</td>
         <td>750 zl.</td>
         <td>Chr�m Sv�tla</td>
         <td>1000 zl.</td>
      </tr>
      <tr>
         <td>J�ma</td>
         <td>Plamen zatracen�</td>
         <td>750 zl.</td>
         <td>Up��� sal�nek</td>
         <td>750 zl.</td>
         <td>Chr�m Temnoty</td>
         <td>1000 zl.</td>
      </tr>
   </table>
   </div>
   
   <p>&nbsp;</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="550px" style="margin: auto;" border="0">
      <tr>
         <td style="width: 100px;"></td>
         <td colspan="2" style="width: 225px;">Alchymistick� obchody</td>
         <td colspan="2" style="width: 225px;">Magick� obchody</td>
      </tr>
      <tr class="hlavicka_tabulky">
         <td style="width: px;">Oblast</td>
         <td style="width: px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>Modr� l�hev</td>
         <td>500 zl.</td>
         <td>Smaragdov� o�arov�n�</td>
         <td>500 zl.</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>N�poje a elix�ry l�sky</td>
         <td>500 zl.</td>
         <td>Ottovy zvl�tnosti</td>
         <td>500 zl.</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Bublaj�c� kotel</td>
         <td>500 zl.</td>
         <td>P��rodn� magie</td>
         <td>500 zl.</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Cesta prom�ny</td>
         <td>500 zl.</td>
         <td>Magie jej�ho veli�enstva</td>
         <td>500 zl.</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td>Edmondovy ampule</td>
         <td>750 zl.</td>
         <td>Artefakty a staro�itnosti</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td colspan="2">-</td>
         <td colspan="2">-</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td colspan="2">-</td>
         <td colspan="2">-</td>
      </tr>
      <tr>
         <td>Deyja</td>
         <td>Za�ouzen� ampule</td>
         <td>750 zl.</td>
         <td>Dve�e smrti</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Nighon</td>
         <td colspan="2">-</td>
         <td>Tajemn� p�edm�ty</td>
         <td>750 zl.</td>
      </tr>
      <tr>
         <td>Mohylov� �dol�</td>
         <td colspan="2">-</td>
         <td colspan="2">-</td>
      </tr>
      <tr>
         <td>Evenmorsk� ostrovy</td>
         <td colspan="2">-</td>
         <td colspan="2">-</td>
      </tr>
      <tr>
         <td>Obla�n� m�sto</td>
         <td>Ampulky v�ry</td>
         <td>1000 zl.</td>
         <td>Tajemn� po�itky</td>
         <td>1000 zl.</td>
      </tr>
      <tr>
         <td>J�ma</td>
         <td>Pekeln� sv�d�n�</td>
         <td>1000 zl.</td>
         <td>Tajemn� ��inky</td>
         <td>1000 zl.</td>
      </tr>
   </table>
   </div>
   
   
   <p>Cechy nab�zej�c� bojov� a obrann� dovednosti se ji� mohou svou nab�dkou mezi sebou li�it. Kov�� v Harmondale v�s ji� nenau�� v�emu, jako kov�� v Obla�n�m m�st�. Nab�dky p��slu�n�ch dovednost� jsou shrnuty v n�sleduj�c�ch dvou tabulk�ch, prvn� je pro bojov� dovednosti, druh� je pro obrann� dovednosti.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="500px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td colspan="4">Kov��sk� cechy</td>
      </tr>
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Oblast</td>
         <td style="width: 120px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: 230px;">V�uka</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>Ryt��ova �epel</td>
         <td>500 zl.</td>
         <td>me�, luk, sekyra, h�l</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Kalen� ocel</td>
         <td>500 zl.</td>
         <td>me�, d�ka, palc�t</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Kr�lovnina v�he�</td>
         <td>500 zl.</td>
         <td>me�, d�ka, sekyra</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Lovcova chata</td>
         <td>500 zl.</td>
         <td>luk, kop�</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Zlomen� luk</td>
         <td>750 zl.</td>
         <td>luk, kop�</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Vanderovy �epele a luky</td>
         <td colspan="2">neposkytuje v�uku</td>
      </tr>
      <tr>
         <td>Nighon</td>
         <td>Zkrvaven� d�ka</td>
         <td>750 zl.</td>
         <td>h�l, d�ka</td>
      </tr>
      <tr>
         <td>Kamenn� m�sto</td>
         <td>Vyv�en� sekyra</td>
         <td>500 zl.</td>
         <td>palc�t, sekyra</td>
      </tr>
      <tr>
         <td>Obla�n� m�sto</td>
         <td>Posv�tn� me�</td>
         <td>1000 zl.</td>
         <td>d�ka, h�l, sekyra, luk, me�</td>
      </tr>
      <tr>
         <td>J�ma</td>
         <td>Spitovy �epele</td>
         <td>1000 zl.</td>
         <td>d�ka, h�l, sekyra, luk, me�</td>
      </tr>
   </table>
   </div>
   
   <p>&nbsp;</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="500px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td colspan="4">Zbroj��sk� cechy</td>
      </tr>
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Oblast</td>
         <td style="width: 120px;">N�zev cechu</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: 230px;">V�uka</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>Erikova zbroj�rna</td>
         <td>500 zl.</td>
         <td>ko�en� zbroj, �t�t</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Venkovsk� kov�rna</td>
         <td>500 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj, �t�t</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Kov�rna Kr�lovny Catherine</td>
         <td>500 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj, pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Ko�en� zbroje</td>
         <td>500 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Avleesk� pos�dka</td>
         <td>750 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj, pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Chyb�j�c� �l�nek</td>
         <td>750 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj, �t�t</td>
      </tr>
      <tr>
         <td>Nighon</td>
         <td>Ko�elu�na</td>
         <td>750 zl.</td>
         <td>ko�en� zbroj</td>
      </tr>
      <tr>
         <td>Kamenn� m�sto</td>
         <td>Le�t�n� zbroj</td>
         <td>500 zl.</td>
         <td>krou�kov� zbroj, pl�tov� zbroj, �t�t</td>
      </tr>
      <tr>
         <td>Obla�n� m�sto</td>
         <td>Proslaven� zbroj</td>
         <td>1000 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj, pl�tov� zbroj, �t�t</td>
      </tr>
      <tr>
         <td>J�ma</td>
         <td>Malicovy �t�ty</td>
         <td>1000 zl.</td>
         <td>ko�en� zbroj, krou�kov� zbroj, pl�tov� zbroj, �t�t</td>
      </tr>
   </table>
   </div>
   
   <p>Pro �plnost je t�eba uv�st, �e cechy v Deyje, Nighonu a J�m� maj� obvykle otev�eno od 6 hodin odpoledne do 6 hodin dopoledne. Vyjma magick�ch cech� neni t�eba platit ��dn� vstupn� poplatky; poplatek magick�m cech�m pak �in� jednotn� 50 zl.</p>
   <p>Magick� cechy se nav�c d�le d�l� podle �rovn� kouzel. Vzhledem k v�t��mu po�tu �rovn� magick�ch dovednost� a zm�n� syst�mu u�en� kouzel je pak znalost um�st�n� cech� d�le�it�. Cena za nau�en� dovednosti je u cechu pro za��te�n�ky 1000 zl., u cechu pro adepty 1500 zl., u cechu pro mistry 2000 zl. a u cechu pro velmistry 2500 zl. N�sleduj�c� tabulka uv�d� p�ehled um�st�n� jednotliv�ch cech�.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="600px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 75px;">Cech/pro</td>
         <td style="width: 75px;">zem�</td>
         <td style="width: 75px;">vody</td>
         <td style="width: 75px;">vzduchu</td>
         <td style="width: 75px;">ohn�</td>
         <td style="width: 75px;">ducha</td>
         <td style="width: 75px;">t�la</td>
         <td style="width: 75px;">mysli</td>
      </tr>
      <tr>
         <td>za��te�n�ky</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Smaragdov� ostrov</td>
         <td>Smaragdov� ostrov</td>
         <td>Smaragdov� ostrov</td>
         <td>Smaragdov� ostrov</td>
         <td>Harmondale</td>
      </tr>
      <tr>
         <td>adepty</td>
         <td>Tulareansk� les</td>
         <td>Tulareansk� les</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Harmondale</td>
         <td>Erathie</td>
      </tr>
      <tr>
         <td>mistry</td>
         <td>Kamenn� m�sto</td>
         <td>Brakadsk� pou��</td>
         <td>Tulareansk� les</td>
         <td>Tulareansk� les</td>
         <td>Deyja</td>
         <td>Erathie</td>
         <td>Tatalie</td>
      </tr>
      <tr>
         <td>velmistry</td>
         <td>J�ma</td>
         <td>Evenmorsk� ostrovy</td>
         <td>Obla�n� m�sto</td>
         <td>Nighon</td>
         <td>Erathie</td>
         <td>Avlee</td>
         <td>Avlee</td>
      </tr>
   </table>
   </div>
   
   <p>V tabulce jsem neuvedl cechy sv�tla a temnoty, proto�e k jejich kouzl�m neni p��stup ihned od po��tku hry, ale budete se je moci nau�it a� pozd�ji. Nav�c v z�vislosti na volb� cesty se budete moci nau�it jen jedno odv�tv� t�to magie. Pro ka�dou z uveden�ch �kol jsou pouze dv� �rovn� cech�. Pro magii temnoty je to Cech noci (adepti) v Deyje a Cech soumraku (velmist�i) v J�m�. Pro magii sv�tla je to Cech z��e (adepti) v Brakadsk� pou�ti a Cech osv�cen� (velmist�i) v Obla�n�m m�st�. Nakupovat kouzla v nich budete moci a� ve chv�li, kdy si p�i volb� soudce zvol�te p��slu�nou stranu a spln�te vstupn� �kol (proj�t L�hn� nebo Ml�n�mi st�nami), ��m� se stanete �leny p��slu�n�ho cechu a budete se moci nau�it i p��slu�nou dovednost magie (m�jte v�ak na pam�ti, �e magii sv�tla nebo temnoty se sm� klerik a �arod�j nau�it teprve po druh�m pov��en� v povol�n�).</p>
   <p>�rove� cechu magie z�rove� ur�uje �rove� kouzel, kter� v n�m m��ete zakoupit. V Cechu za��te�n�k� koup�te jen kouzla norm�ln� �rovn�, v cechu adept� pak koup�te kouzla expertn� i norm�ln� �rovn�. Ka�d� vy��� cech m� tedy k dispozici i kouzla ni���ch �rovn� apod. Cechy magie t�la, mysli a ducha nav�c poskytuj� dovednost meditace, cechy magie ohn�, zem�, vzduchu a vody pak dovednost vzd�l�v�n�.</p>
   <p>Cena za u�en� dovednost� neni konstatntn� a je z�visl� na reputaci dru�iny. ��m vy��� reputace bude, t�m ni��� cenu v�m u�itel� nab�dnou. Reputaci si m��ete v oblastech zvy�ovat pln�n�m �kol� a poskytnut�m milodaru chr�mu.</p>
   <p>V sedm�m d�le existuje je�t� jedna zvl�tnost spojen� s vlastnictv�m hradu Harmondale. Pot�, co se spoj�te s �arod�ji z Bracady nebo s nekromanty z Deyje, dojde k druh� p�estavb� hradu a v s�le se objev� �ty�i obchody. Kov�� - Spole�nost s me�i, zbroj�� - Thelovy zbroje a �t�ty, alchymista - K�dinky a lahvi�ky a chr�m - Svatost�nek. Alchymista a chr�m nab�z� shodn� dovednosti jako ostan� alchymist� a chr�my, kov�� vyu�uje m�� a d�ku, zbroj�� pak ko�enou a krou�kovou zbroj. Cena za v�uku je stanovena jednotn� na 500 zl.</p>
   
   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
