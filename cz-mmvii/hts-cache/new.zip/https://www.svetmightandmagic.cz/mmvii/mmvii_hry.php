<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Hry o vlastnosti</h2>
   <p>&nbsp;</p>
   
   <p>V r�zn�ch oblastech pevniny m��ete nal�zt mramorov� podstavce s ob�tn� n�dobou, ve kter� ho�� ohe� ur�it� barvy. Obecn� se ozna�uj� jako hry, pop�. hry o vlastnosti. Podle barvy ohn� se pak rozd�luj� do �ty� skupin podle �rovn� - modr� se ozna�uje jako Hra, oran�ov� jako Sout�, �erven� jako Test a b�l� jako V�zva. Ka�d� ozna�en� pak nese je�t� p��vlastek podle jedn� ze z�kladn�ch vlastnost�, nap�. Hra s�ly, Test odolnosti apod. V�b�r vlastnosti je n�hodn� a m�n� se s ka�dou rozehranou hrou, shodn� je v�dy jen �rove� hry v oblasti. V�znam her je n�sleduj�c�. Pokud se postava pokus� ve h�e sout�it, bere se nejprve v �vahu velikost p��slu�n� vlastnosti, kter� hra odpov�d� (nap�. pro hru S�ly je to s�la apod.). Je-li hodnota vlastnosti ni��� ne� �rove� hry, pak postava prohraje. Je-li v�ak rovna anebo vy��� ne� �rove� hry, pak postava k dan� vlastnosti z�sk� dal�� body. Za v�hru ve H�e jsou to 3 body, za v�hru v Sout�i je to 5 bod�, za v�hru v Testu je to 7 bod� a za v�hru ve V�zv� je to 10 bod�.</p>
   
   <div style="text-align: center;">
   
   <table cellspacing="0" cellpadding="0px" width="256px" style="margin: auto; border: none;">
      <tr>
         <td style="border: none;"><img src="obrazky/vyzvy.png" width="256px" height="128px" alt="" /></td>
      </tr>
      <tr>
         <td style="border: none;">&nbsp;</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2px" width="500px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">Oblast</td>
         <td style="width: 100px;">N�zev hry</td>
         <td style="width: 125px;">Po�adovan� �rove� vlastnosti</td>
         <td style="width: 125px;">Bonus k vlastnosti po v�h�e</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>Hra</td>
         <td>25</td>
         <td>+3</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Test</td>
         <td>100</td>
         <td>+7</td>
      </tr>
      <tr>
         <td>Deyja</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Mohylov� �dol�</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Brakadsk� pou��</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Sout�</td>
         <td>50</td>
         <td>+5</td>
      </tr>
      <tr>
         <td>Evenmorsk� ostrovy</td>
         <td>Test</td>
         <td>100</td>
         <td>+7</td>
      </tr>
      <tr>
         <td>Nighon</td>
         <td>V�zva</td>
         <td>200</td>
         <td>+10</td>
      </tr>
      <tr>
         <td>Eofol</td>
         <td>V�zva</td>
         <td>200</td>
         <td>+10</td>
      </tr>
   </table>
   </div>
   
   <p>Pokud postava v ur�it� h�e vyhraje, pak nebude moci vyhr�t v dal�� h�e o stejnou vlastnost v jin� oblasti. Hry v�ak podl�haj� stejn� jako sudy s magick�mi tekutinami respawnu, tak�e po jeho ub�hnut� je mo�no op�t sout�it.</p>
   <p>V souvislosti s existenc� t�chto her jsem p�i�el na jeden zaj�mav� tip. Proto�e se p�i h�e bere v �vahu celkov� velikost vlastnosti a to i v�etn� bonus� z p�edm�t� a do�asn�ch bonus� (font�ny, studny, kouzla, b�l� lektvary apod.), tak toho lze pat�i�n� vyu��t. Jednotliv� bonusy (i ty do�asn�) se toti� vz�jemn� s��taj�, tak�e kdy� se nap�. napijete z font�ny p�id�vaj�c� bonus +50 k p��slu�n� vlastnosti a pot� je�t� zakouzl�te Den Boh� (nebo najdete p��slu�n� piedestal), bude v�sledn� velikost vlastnosti sou�tem obou bonus�. D�ky tomu pak m��ete hr�t i vy��� �rovn� her. Jsou to v podstat� snadno z�skan� dovednostn� body.</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
