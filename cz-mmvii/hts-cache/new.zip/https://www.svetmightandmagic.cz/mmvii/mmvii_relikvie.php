<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 15px;}
      td {text-align: left; border: none; text-indent: 5px;}
      .popis {text-align: justify;}
      .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Relikvie</h2>
   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/01.png" width="70px" height="166px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Amok</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(S�la +100, odolnost +100, T��da zbroje -15) A�koliv bylo jm�no Amoky v pr�b�hu v�k� ztraceno, zbra� si p�esto uchovala svou magicky ostrou �epel a v�e ze sv� p�vodn� s�ly. Neuv��iteln� s�la a vitalita, kterou dr�itel zbran� z�sk�, je vykoupena odpov�daj�c�m pocitem strachu. Majitel� Amoku se v bitv� p��li� nestaraj� o uh�b�n� se ran�m.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/02.png" width="71px" height="128px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ania Selving</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>+9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(P�esnost +150, luk +5, T��da zbroje -25) Mistr zbroj�� Ivan Selving pojmenoval tuto ku�i po sv� jedin� dce�i Anii a ozna�il ji za sv�j druh� nejlep�� v�tvor. St�elci pou��vaj�c� tuto ku�i jen z��dkakdy minou sv� c�l, ale jejich hlubok� soust�ed�n� a pomal� opatrn� pohyby z nich na opl�tku d�laj� snadn� ter�e.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/03.png" width="23px" height="138px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Drti�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+15</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3+15</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(S�la +150, inteligence -40, osobnost -40, rychlost -40) ��k� se, �e Drti� se stal vysly�en�m modlitby Prvn�ho zlobra k boh�m, aby mu seslali zbra� siln�j�� ne� cokoliv jin�ho. Rozmrzel� bohov� to Prvn�mu zlobrovi oplatili kletbou, kter� od t� doby n�sleduje v�echny jeho potomky - jsou siln�, ale tup� a hloup�. V ka�d�m p��pad� - nyn� je Drti� tv�j.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/04.png" width="52px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ethrikova h�l</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie temnoty, meditace +15, postupn� ub�r� zdrav�, Zlo) Sp��e n�stroj ne�-li zbra�, byla Ethrikova h�l vytvo�ena prvn�m lichem na sv�t�, Ethrikem ��len�m. H�l posiluje schopnosti magie temnoty za cenu �ivotn� s�ly, kteou vys�v� dr�iteli. Vzhledem k tomu, �e Ethrikova �ivotn� s�la byla um�le udr�ov�na, nebyl to pro n�ho ��dn� probl�m. Smrteln�c� ale poci�uj�, jak se jim po dobu dr�en� hole pomalu vytr�c� �ivotn� energie.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/05.png" width="54px" height="55px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Finaxijsk� koruna</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie ohn�, odolnost proti vod� +50, osobnost +30, T��da zbroje -20) Toto je ztracen� (BYLA ztracen�) koruna Fynaxiansk�ho c�sa�stv�, jeho� existence netrvala dlouho. P�i jej�m no�en� na hlav� eliminuj� kameny koruny auru nev�razn� magie ohn� a tv�� nositelovu zahal� �ervenav�m sv�tlem. Koruna zesiluje dovednost magie ohn� a v�znamn� posiluje odolnost proti �tok�m magie vody.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/06.png" width="130px" height="108px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hareckova ko�en� zbroj</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+30</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Kraden� +5, odstran�n� past� +5, Ch�ze po vod�, �t�st� +50, v�echny odolnosti -10) Tato ko�en� zbroj byla vyrobena v regnansk�ch kr�lovsk�ch zbroj��stv�ch speci�ln� pro Harecka I., p�na na Regn� a c�sa�e Nekone�n�ho oce�nu. Zbroj poskytovala v�e, po �em mohl slavn� pir�t jako Hareck tou�it, krom� ochrany proti jedu. Mocn� c�sa� skonal od�n v t�to zbroji po ve�e�i, otr�ven svou �enou.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/07.png" width="93px" height="92px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kelebrim</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+20</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Imunita proti zkamen�n�, polovi�n� zran�n� st�eln�mi �toky, odolnost +50, odolnost proti zemi -30) Jeden z prvn�ch �t�t� vyroben�ch v Kelebrimsk� v�hni, tento zna�en� prost�m n�pisem "Kelebrim" uvnit� nad popruhem. �t�t je velmi siln� okouzlen proti pohledu med�z, ale stejn� jako v p��pad� jin�ch mocn�ch za��kadel, i on sebou nese negativn� vlastnosti. Kelebrim oslabuje odolnost nositele v��i magii zem�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/08.png" width="53px" height="128px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mekorigovo kladivo</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+13</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5+13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie ducha, s�la +75, odolnost proti vzduchu -50) Toto je kladivo, kter� velk� Mekorig Slep� pou�il pro v�robu nejskv�lej�� magick� v�zbroje b�hem sv�ho mistrovsk�ho p�soben� v Mekorigsk� v�hni. Propojen� kladiva se z�kladn�mi elementy vystavuje jeho majitele nebezpe�� zran�n� ze strany element�rn� magie, ale to je jen nepatrn� cena za zv��en� vlastn�ch schopnost� a s�ly, kter� kladivo zaru�uje.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/09.png" width="34px" height="100px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Satan�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Odstran�n� past� +5, 8 bod� zran�n� jedem, Zhouba elf�, Zlo) Po stalet� tajn� p�ed�van� z rukou jednoho vraha do rukou jin�ho, zmizel Satan� pro historii p�ed 200 lety v dob� Bitvy nad r�nem - spojen�ho �toku lid� a elf� proti cechu n�jemn�ch vrah�. ��k� se, �e Satan� zabil v�ce lid� ne� mor. Te�, kdy� jsi tuto zbra� nalezl, ji hodl� zahodit ... �e?</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/10.png" width="64px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Soumrak</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+13</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Rychlost +50, �t�st� +50, v�echny odolnosti -15, Zlo) Zlov�stn� plṻ Soumrak byl po stalet� u��v�n vyzv�da�i a n�jemn�mi vrahy. Charakter jeho okouzlen� je pro tato povol�n� tak v�hodn�, �e ztr�tu magick�ch odolnost� lze snadno o�elet.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/11.png" width="56px" height="137px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Spravedlnost</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+14</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+14</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Zhouba nemrv�ch, magie mysli, magie t�la, rychlost -40, Dobro) Ukov�na v bla�en�ch dnech zrodu Chr�mu Slunce stala se Spravedlnost mocnou zbran� Dobra. I za cenu rychlosti se stala jednou z nejmocn�j��ch relikvi�, jakou paladin �i klerik mohli na cest� Sv�tla t��mat.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/12.png" width="131px" height="125px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�t�t sl�vy</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+24</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie ducha, �t�t +5, odolnost proti t�lu -10, odolnost proti mysli -1) Jeden z p�ti zn�m�ch �t�t� tohoto druhu; �t�t sl�vy byl vyroben b�hem �as� z�zrak�. Jeho p�vodn�m smyslem bylo pos�lit magii ducha sv�ho majitele, ale ze stejn�ho d�vodu byl nositel �t�tu �tok�m magie ducha a t�la pon�kud vystaven.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/13.png" width="50px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Taledonova helma</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+14</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie sv�tla, osobnost +15, s�la +15, �t�st� -40, Dobro) Tato mocn� helma pat�ila od roku 870 A.S. Nejvy��mu nebesk�mu kn�zi a Nejvy��mu svat�mu v�dci Chr�mu Slunce Taledonovi a pravd�podobn� p�isp�la k jeho p�ed�asn� smrti v roce 881. ��k� se, �e ka�d� p�edm�t je schopen absorbovat jen omezenou m�ru okouzlen�; pokud je do n�ho vpraveno v�ce magie, prosad� se p�itom cosi negativn�ho. V tomto p��pad� se nositeli helmy v�razn� sn��ilo jeho �t�st�. Taledon, bezesporu nejmocn�j�� �lov�k sv� doby, zku�en� diplomat, voj�k a kn�z byl rozdrcen koly proj��d�j�c�ho selsk�ho vozu, kdy� p�ech�zel steadwickou ulici.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/14.png" width="63px" height="33px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tit�nsk� opasek</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(S�la +75, rychlost -40) Jako mnoho podobn�ch p�edm�t� i Tit�nsk� opasek zvy�uje s�lu za cenu rychlosti. Jedin� rozd�l v p��pad� t�to relikvie tvo�� v�znamnost t�to v�m�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/15.png" width="56px" height="53px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">U�encova �apka</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+2</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Vzd�l�v�n� +15, odolnost -50) U�encova �apka v�znamn� zvy�uje schopnost ducha p�ij�mat a uchov�vat zku�enosti. ��inek je tak mocn�, �e se nositel� �epice �asto p�i plavb� oce�nem sv�ch my�lenek zapomenou starat o sv� t�la.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
