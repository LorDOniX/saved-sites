<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 15px;}
      td {text-align: left; border: none; text-indent: 5px;}
      .popis {text-align: justify;}
      .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Artefakty</h2>
   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/16.png" width="52px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dareba</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+14</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+14</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Rychlost +40, rychlosti) Prastar� a zt�e�t�n� okouzlen� p�edur�uj� Darebu k tanci po nep��telsk�ch hrdlech. Nikdo nev�, kdy nebo kde byl Dareba ukov�n, ale jeho v�l� p�vod je nep�ehl�dnuteln�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/17.png" width="103px" height="159px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Guvern�rova zbroj</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+36</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Polovi�n� zran�n� st�eleck�mi �toky, +10 do v�ech statistik) Tato fantastick� zbroj, p�vodn� pat��c� koloni�ln�mu guvern�rovi Padishovi v dob� Ticha, se b�hem v�k� n�kolikr�t objevila mezi t�mi nejskv�lej��mi poklady. Jako jin� v�robky Nebesk� v�hn� i tato zbroj je t�m�� nezni�iteln�. Jej� v�robu by z�ejm� ji� nezvl�dla ��dn� d�lna kdekoliv na zemi.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/18.png" width="50px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Charele</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+18</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d9+18</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ukov�n z rozkazu Harecka I. b�hem utv��en� regnansk�ho "c�sa�stv�", byl Charele pojmenov�n podle kr�lovy man�elky - kr�lovny Charele. Po Hareckov� smrti jedem v roce 590 A.S. byl Charele ponech�n v jedn� regnansk� pevnosti v Erathii.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/19.png" width="34px" height="280px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Katan</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Zhouba nemrtv�ch, drak� a d�mon�) Up��mn� �e�eno, pon�kud rozmarn� zbra�. Katan byl ukov�n Mekorigem Slep�m s c�lem ukon�it V�k monster a zah�jit v�k �lov�ka. Vzne�en� my�lenka, ale ne zcela napln�n�. Katan se mnohokr�t na mnoho let ztratil, jen aby byl nalezen n�kter�m dobrodruhem v n�jak�m dra��m pokladu. S�la zbran� nejednou popoh�n�la dobrodruhy, aby se s Katanem vydali k dal��mu dra��mu pokladu, kde se op�t zbra� na roky ztratila.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/20.png" width="40px" height="150px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Korz�r</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+13</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Kraden� +5, odstran�n� past� +5, �t�st� +40) Korz�r je jednou z nejskv�lej��ch zbran�, jak� se kdy dostali z regnansk�ch zbrojnic. Jak odpov�dalo m�stn�m zvyklostem, regnan�t� kov��i ukovali tuto zbra� tak, aby vyhovovala snah�m c�sa�sk�ch "v�b�r��ch dan�", a� ji� p�sobili na otev�en�m mo�i, nebo v p��mo�sk�ch m�stech. Do de�n�ch dn� Regna nevyrobila jedinou zbra�, kter� by nevyjad�ovala sm�rov�n� za egoistick�mi c�li na �kor c�l� druh�ch.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/21.png" width="48px" height="239px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Odysseus</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(P�esnost +50, 9-12 bod� zran�n� vodou) Sen lukost�elc�. Odysseus nepot�ebuje ��dn� ��py, nebo� st��l� ledov� st�ely, vytv��en� p�i nata�en� t�tivy. Jeho p�vod je nezn�m�, ale zpracov�n� je elfsk�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/22.png" width="50px" height="120px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">P�li�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Explozivn� dopad, odolnost proti ohni +50) P�esto�e jde o mocnou zbra�, nebyl P�li� nikdy nik�m vlastn�n p��li� dlouho. �epel p�i z�sahu vyvol� mohutn� ohniv� �der, mocn� magick� ochrana proti ohni je tak siln�, �e dr�itele zbran� �sp�n� p�ed ��inkem tohoto �deru za�t�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/23.png" width="35px" height="61px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ruce mistra</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Beze zbran� +10, uh�b�n� +10) Ruce mistra byly zam��leny pro mnichy, ale skv�le je vyu�ilo i n�kolik zlod�j�. Mnoho jejich majitel� dos�hlo �t�st� a sl�vy, ale tomu posledn�mu se to zjevn� nezda�ilo.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/24.png" width="87px" height="96px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Sedmim�lov� boty</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+15</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Rychlost +40, magie vody) Jsou pojmenov�ny podle sv� schopnosti zvy�ovat nositelovy reflexy a prodlu�ovat krok. Jejich skute�nou funkc� je zesilovat znalost vodn� magie a t�m zvy�ovat rychlost ch�ze. Kdokoliv u��v� t�chto bot, je p�edur�en k velikosti, ale ne nutn� ke sl�v�. Jejich p�edchoz�m vlastn�k� lze p�i��st nejednu lotrovinu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/25.png" width="29px" height="28px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vl�dc�v prsten</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(magie mysli, magie temnoty) Vl�dc�v prsten byl vyroben v roce 744 A.S. Joshuou Stomem, p�edstaven�m alchymist� u nighonsk�ch �arod�jnic. A�koliv nejde zcela o artefakt zla, prsten byl vyroben pro ovl�d�n� a dob�v�n� a k ni�emu jin�mu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/26.png" width="40px" height="150px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Wallace</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Mistr zbran� +10, osobnost +40) Wallace si po stalet� jaksi nal�zal cestu do rukou vzbou�enc� a zbojn�k�. Zbra� zvy�uje schopnosti i p�esv�d�ivost sv�ho vlastn�ka a vede ho tak do riskantn�ch akc�, kter�m by se jinak vyhnul. A�koliv ale ��dn� z t�chto nad�j� majitele me�e nebyla napln�na, p�esto nikdy nikdo tento me� neodm�tl, jak jednou zaslech jeho m�mivou p�se�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/27.png" width="118px" height="112px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Yoruba</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+60</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Imunita v��i nemoci, ��lenstv�, ochromen�, otrav�, usnut� a zkamen�n�, odolnost +25) Yoruba, mimo��dn� pevn� a magicky odoln� pl�tov� brn�n�, je pojmenovan� po sv�m v�robci a majiteli. Vzhledem ke sv� vysok� cen� byla Yoruba stav�na po ��stech, co� je na n� vid�t. Rozd�ln� d�ly jsou vyrobeny z rozd�ln�ch materi�l�, z nich� nejdra���ch bylo pou�ito pro ukov�n� krun��e. Na kyrysu jsou dosud dva prora�en� otvory, kter� p�vodn� majitel nikdy nezacelil, z�ejm� ze sentiment�ln�ch d�vod�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/28.png" width="88px" height="274px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zhouba gh�l�</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+15</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+15</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(Zhouba nemrtv�ch, imunita proti ochromen�, 3-18 bod� zran�n� ohn�m) Zhouba gh�l� byla vytvo�ena p�ed v�ce ne� 150 lety Chr�mem Slunce jako prost�edek �sil� pot��t rostouc� populaci nemrtv�ch, stvo�en�ch Chr�mem M�s�ce. Bez ohledu na to, jak je siln�, je to jedin� zbra� a nemrtv�ch jsou z�stupy. Chr�m Slunce padl v roce 1083 A.S.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/29.png" width="36px" height="189px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�elezn� brk</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">(S�la +40, 6-15 bod� zran�n� vzduchem) Neskute�n� lehk� obouru�n� me� zvy�uje s�lu vlastn�ka, ��m� mu usnad�uje boj t�kou zbran�. D�ky tomu by bylo t�m�� mo�n� jej pou��vat jednou rukou, ale velk� d�lka me�e to znemo��uje.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
