<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Tr�nink postav</h2>
   <p>&nbsp;</p>
   <p>Postavy pln�n�m zadan�ch �kol� a bojem z�sk�vaj� zku�enosti, kter� je mo�n� p�i dosa�en� ur�it� hodnoty prom�nit tr�ninkem na dovenostn� body. Postava p�i tom postupuje o �rove� (level) v��e a krom dovednostn�ch bod� se j� zvy�uje mno�stv� zdrav� a many (viz tabulky v ��sti <a href="mmvii_vlastnosti.php">vlastnosti postav</a>). Jedn� se o z�kladn� tr�nink, kter� je za poplatek prov�d�n v tren�rsk�ch hal�ch (cvi��rn�ch). Tren��i se li�� nejenom �rovn�, do kter� mohou postavy vytr�novat, ale tak� cenou. Cenu tr�nink� v�ak m��ete sn��it t�m, �e postavy nau��te dovednost Obchodov�n�. Rozm�st�n� cvi��ren (tr�ninkov�ch hal) uv�d� n�sleduj�c� tabulka:</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" border="1" width="540px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 120px;">Um�st�n�</td>
         <td style="width: 220px;">N�zev</td>
         <td style="width: 100px;">Z�kladn� cena tr�ninku *)</td>
         <td style="width: 100px;">Maxim�ln� level</td>
      </tr>
      <tr>
         <td>Smaragdov� ostrov</td>
         <td>Ostrovn� cvi�i�t�</td>
         <td>10</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Harmondale</td>
         <td>Z�kladn� principy</td>
         <td>20</td>
         <td>15</td>
      </tr>
      <tr>
         <td>Erathie</td>
         <td>Ve slu�b�ch Jej�ho Veli�enstva</td>
         <td>25</td>
         <td>25</td>
      </tr>
      <tr>
         <td>Tulareansk� les</td>
         <td>Cvi�i�t�</td>
         <td>25</td>
         <td>25</td>
      </tr>
      <tr>
         <td>Avlee</td>
         <td>Avleesk� gymn�zium</td>
         <td>80</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Tatalie</td>
         <td>Z�klady tr�ninku</td>
         <td>40</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Kamenn� m�sto (Mohylov� �dol�)</td>
         <td>V�le�n� univerzita</td>
         <td>40</td>
         <td>100</td>
      </tr>
      <tr>
         <td>J�ma</td>
         <td>Plamen zatracen�</td>
         <td>30</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Obla�n� m�sto</td>
         <td>Zkou�ka sl�vy</td>
         <td>30</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Nighon</td>
         <td>U�ite�n� instrukce</td>
         <td>50</td>
         <td>nad 200</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td colspan="4">*) vysv�tlen� d�le v textu</td>
      </tr>
   </table>
   </div>
   
   <p>Cvi��rna v Harmondale a okoln� cvi��rny v Erathii a Tulareansk�m lese pat�� mezi velmi levn� a v po��tku hry v�m bohat� posta��, proto�e jsou limitov�ni a� levelem 25 (Harmondale max. 15). Ka�dop�dn� se vyh�bejte cvi��rn� v Avlee, v�cvik v n� je velmi p�edra�en�. Jakmile si vyberete cestu sv�tla nebo temnoty, otev�ou se v�m levn� cvi��rny spojenc�.</p>
   <p>Konkr�tn� cenu tr�ninku si m��ete i snadno vypo��tat. Pou��v� se k tomu hodnota z�kladn� ceny tr�ninku, kter� je odvozena z ceny za tr�nink z prvn�ho na druh� level. Cena tr�ninku p�i p�echodu na dal�� level se pak po��t� prost�m n�soben�m <span class="tucne">z�kladn� cena x aktu�ln� level x hodnost</span>, kde hodnost odr�� �rove� pov��en�. Z�kladn� povol�n� m� hodnost rovnu 1, prvn� pov��en� pak 2 a druh� pov��en� m� hodnotu 3. Pokud n�s tedy nap�. zaj�m� cena za tr�nink Kn�ze Sv�tla (hodnost je tedy 3) z 14 levelu na 15 level ve cvi��rn� v Harmondale, pak je to 20 x 14 x 3 = 840 zlat�ch. Na cenu tr�ninku m� vliv i reputace dru�iny, tak�e postava s kladnou reputac� dostane drobn� slevy, ��dov� v jednotk�ch zlat�ch. V�po�et se pak m��e m�rn� li�it od skute�nosti.</p>
   <p>Proto�e ka�d� tr�nink v�s krom pen�z stoj� i str�ven� �as, budete po tr�ninku opou�t�t cvi��rny v�dy s �asovou ztr�tou. Doba tr�ninku je toti� v ka�d� z erathijsk�ch cvi��ren stanovena na rovn�ch 8 dn� za ka�d� level v��e. Oproti p�edchoz�mu d�lu to znamen�, �e pokud budete u postavy cvi�it v�ce level� najednou, uplyne p�esn� tolik t�dn�, o kolik level� se vycvi��te. V praxi to pak tak� znamen�, �e i p�i tr�ninku v�ce postav najednou se pro v�po�et bere v �vahu jen ta, kter� postoupila o nejv�t�� po�et level� a podle toho se posune datum. V principu je pak tak� jedno, jestli cvi��te po jednotliv�ch levelech nebo ne. Za ka�d� hern� rok se ka�d� postava m��e vycvi�it max. o 43 level� v��e. �asov� zdr�en� je t�eba m�t na pam�ti zejm�na p�i pln�n� �asov�ch �kol�.</p>
   <p>Pro postup na dal�� level v z�kladn�m tr�ninku plat� jednoduch� pravidlo. V�dy pot�ebujete o 1000 zku�enost� v�ce, ne� bylo t�eba p�i postupu na p�edchoz� level. Nap�. pro postup z 1 levelu na 2 level pot�ebujete z�skat 1000 zku�enost�, ze 2 na 3 u� je to 2000 zku�enost�, ze 3 na 4 level 3000 zku�enost� atd., tedy plat� rovnice: pot�ebn� zku�enosti = (level - 1) * 1000. S v�hodou je mo�n� vyu��t n�sleduj�c�ho vzorce, kter� je �pravou vzorce uveden�ho na str�nk�ch <a href="http://mm-world.gamesurf.tiscali.de/">mm-world.gamesurf.tiscali.de</a> (p�vodn� vzorec po��tal skok mezi levely, nam�sto level - 1 je tam level + 1): 
   <p class="tucne">dosa�en� zku�enosti = 1000 * [ level * (level - 1) / 2 ]</p>
   <p>Pro n�zornost uvedu p��klad: na 6 levelu bude m�t postava celkem 1000*[6*(6-1)/2] = 15 000 zku�enost� anebo jinak tak� �e�eno, p�i dosa�en� 15 000 zku�enost� bude moci postava postoupit na 6 level.</p>
   
   <p>&nbsp;</p>
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" border="1" width="450px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">level postavy</td>
         <td style="width: 150px;">pro dosa�en� n�sleduj�c�ho levelu je t�eba zku�enost�</td>
         <td style="width: 150px;">celkov� po�et z�skan�ch zku�enost�</td>
      </tr>
      <tr>
         <td>1</td>
         <td>1000</td>
         <td>0</td>
      </tr>
      <tr>
         <td>2</td>
         <td>2000</td>
         <td>1000</td>
      </tr>
      <tr>
         <td>3</td>
         <td>3000</td>
         <td>3000</td>
      </tr>
      <tr>
         <td>4</td>
         <td>4000</td>
         <td>6000</td>
      </tr>
      <tr>
         <td>5</td>
         <td>5000</td>
         <td>10000</td>
      </tr>
      <tr>
         <td>6</td>
         <td>6000</td>
         <td>15000</td>
      </tr>
      <tr>
         <td>7</td>
         <td>7000</td>
         <td>21000</td>
      </tr>
      <tr>
         <td>8</td>
         <td>8000</td>
         <td>28000</td>
      </tr>
      <tr>
         <td>9</td>
         <td>9000</td>
         <td>36000</td>
      </tr>
      <tr>
         <td>10</td>
         <td>10000</td>
         <td>45000</td>
      </tr>
   </table>
   </div>
   <p>&nbsp;</p>
   
   <p>Po�et z�sk�van�ch zku�enost� lze ovlivnit dovednost� vzd�l�v�n� (viz. <a href="mmvii_dovednosti.php">Dovednosti</a>). Postava s touto dovednost� z�sk�v� bonus k dosa�en�m zku�enostem a velikost tohoto bonusu je �m�rn� po�tu investovan�ch bod� do dovednosti a �rovni dovednosti. Krom toho je mo�n� si ve h�e najmout do party NPC, kter� poskytuj� bonus k z�skan�m zku�enostem.</p>
   <p>Mno�stv� dovednostn�ch bod�, kter� postava postupen o �rove� z�sk�v� neni konstantn�. Do levelu 9 z�sk�v� postava za ka�d� postup 5 dovednostn�ch bod�, do levelu 19 je to 6 bod� atd., v�dy za ka�dou dal�� des�tku je to o 1 dovednostn� bod nav�c. Bl��e viz n�sleduj�c� tabulka.</p>
   
   <p>&nbsp;</p>
   <div>
   <table cellspacing="0" cellpadding="0" border="1" width="450px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">level</td>
         <td style="width: 150px;">po�et dovednostn�ch bod� z�skan� za ka�d� postup</td>
      </tr>
      <tr>
         <td>1-9</td>
         <td>5</td>
      </tr>
      <tr>
         <td>10-19</td>
         <td>6</td>
      </tr>
      <tr>
         <td>20-29</td>
         <td>7</td>
      </tr>
      <tr>
         <td>30-39</td>
         <td>8</td>
      </tr>
      <tr>
         <td>40-49</td>
         <td>9</td>
      </tr>
      <tr>
         <td>50-59</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2">a d�le v�dy o 1 bod nav�c</td>
      </tr>
   </table>
   </div>
   <p>&nbsp;</p>

   <p>Z�skan� dovednostn� body pak m��ete investovat p�i sekund�rn�m tr�ninku, co� je tr�nink jednotliv�ch dovednost� postavy. Tento v�cvik prov�d�j� u�itel� dovednost� a jejich seznam a rozm�st�n� naleznete <a href="mmvii_ucitele.php">zde</a>. Na �rove� experta je t�eba m�t v dovednosti 4 body, na mistra 7 bod� a na velmistra 10 bod�. Ke zv��en� hodnoty dovednosti o jedna pot�ebujete stejn� po�et dovednostn�ch bod�, jako je velikost vy��� hodnoty. Nap�. m�me v dovednosti obchodov�n� 1 bod, pokud chceme dovednost zv��it na 2 body, mus�me do n� investovat 2 dovednostn� body. Ze 2 bod� na 3 to budou 3 dovednostn� body atd. Syst�m je tedy stejn� jako u p�edchoz�ch d�l�. Pro n�zornost uv�d�m n�sleduj�c� tabulku, do hodnoty dovednosti 10:</p>
   
   <p>&nbsp;</p>
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" border="1" width="450px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">hodnota dovednosti</td>
         <td style="width: 150px;">ke zv��en� na n�sleduj�c� hodnotu je t�eba investovat dovednostn�ch bod�</td>
         <td style="width: 150px;">celkov� po�et investovan�ch dovednostn�ch bod�</td>
      </tr>
      <tr>
         <td>1</td>
         <td>2</td>
         <td>0</td>
      </tr>
      <tr>
         <td>2</td>
         <td>3</td>
         <td>2</td>
      </tr>
      <tr>
         <td>3</td>
         <td>4</td>
         <td>5</td>
      </tr>
      <tr>
         <td>4</td>
         <td>5</td>
         <td>9</td>
      </tr>
      <tr>
         <td>5</td>
         <td>6</td>
         <td>14</td>
      </tr>
      <tr>
         <td>6</td>
         <td>7</td>
         <td>20</td>
      </tr>
      <tr>
         <td>7</td>
         <td>8</td>
         <td>27</td>
      </tr>
      <tr>
         <td>8</td>
         <td>9</td>
         <td>35</td>
      </tr>
      <tr>
         <td>9</td>
         <td>10</td>
         <td>44</td>
      </tr>
      <tr>
         <td>10</td>
         <td>11</td>
         <td>54</td>
      </tr>
   </table>
   </div>
   <p>&nbsp;</p>
   
   <p>Jak je patrn�, tr�nink dovednost� (skill�) je na vy���ch �rovn�ch n�ro�n� na mno�stv� dovednostn�ch bod�. Je proto dobr� se p�i v�voji postavy orientovat sp��e jen na podstatn� skilly pro dan� povol�n� a nesna�it se o univerz�lnost. Ke v�emu je to st��en� i t�m, �e ne v�echna povol�n� mohou dos�hnout vysok�ch �rovn� dovednosti, tak�e byste do nich mohli investovat body zbyte�n� a pak by v�m chyb�ly.</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
