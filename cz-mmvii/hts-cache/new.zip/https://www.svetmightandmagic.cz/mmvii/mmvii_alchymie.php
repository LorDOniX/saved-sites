<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 20px; border: 1px solid maroon;}
      td {text-align: left; border: none; text-indent: 0px; padding: 4px;}
     .popis {text-align: justify;}
     .popis_2 {text-align: justify; border: 1px solid maroon;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Alchymie</h2>
   <p>&nbsp;</p>

   <p>Alchymie pat�� ve sv�t� Might and Magic mezi mocn� <a href="mmvii_dovednosti.php">dovednosti</a>. Na velmistrovsk�ch �rovn�ch se ji dok�ou nau�it jen <a href="mmvii_povolani.php">povol�n�</a> odvozen� od druida, ale u�itek z n� maj� v�ichni. Nejsiln�j�� lektvary dok�� postav� trvale zv��it z�kladn� atributy a v�roba lektvar� z ingredienc� m��e b�t tak� celkem v�nosn�m artiklem. Levn� suroviny lze d�ky n� snadno z�ro�it p�i v�rob� slo�it�j��ch sm�s�. Nap�. ze surovin za 8 zl. lze ve fin�le vyrobit a� elix�r za 2000 zl. Ale tak� naopak, z obchodn�ch d�vod� nem� smysl m�chat jednoduch� lektvary z drah�ch ingredienc�, cena ka�d�ho druhu lektvaru je toti� pevn� dan� bez ohledu na jeho dal�� parametry. Z tohoto pohledu by to bylo zbyte�n� mrh�n� zdroji. Lep�� suroviny je dobr� si schov�vat pro siln�j�� lektvary (viz n��e).</p>
   <p>Ka�d� z ingredienc� je charakterizov�na parametrem s�ly, kter� ur�uje jak siln� bude lektvar, kter� z n� p�iprav�me. V p��pad� kombinac� slo�it�j��ch lektvar� je v�sledn� s�la rovna pr�m�ru obou pou�it�ch lektvar�. Do s�ly lektvaru se prom�taj� i investovan� body v dovednosti alchymie. Tak�e nap�. p�i p��prav� Magick�ho n�poje z ko�en� phirny bude v�sledn� s�la lektvaru v z�kladu 1 bod, kdy� ho bude m�chat postava s 5-ti body v alchymii, bude v�sledn� s�la u� 1 + 5 = 6 bod�.</p>
   <p>Lektvary se p�ipravuj� m�ch�n�m ingredienc� v pr�zdn�ch lahv�ch (pomoc� prav�ho tla��tka my�i) nebo m�ch�n�m lektvar� vz�jemn� mezi sebou (p�i m��en� lektvar� mezi sebou se obsah v�dy slije do jedn� lahvi�ky a druh� se vypr�zdn�).</p>
   <p>�ed� lektvary, tzv. katalyz�tory, jsou speci�ln�m druhem lektvar�, kter� samy o sob� nemaj� ��dn� ��inky, ale mohou b�t vyu�ity pro zv�t�en� (bohu�el p�i nevhodn�m pou�it� i pro sn��en�) s�ly jin�ch lektvar� - lektvar toti� p�eb�r� s�lu aplikovan�ho katalyz�toru. P�i experimentech s nimi je proto t�eba d�vat dobr� pozor. Z uveden�ho tak� plyne, �e efekt katalyz�tor� se nes��t�. Nem� proto smysl m�chat jich do lektvaru v�ce. Jen pro zaj�mavost, jeliko� katalyz�tory lze m�chat i mezi sebou, je mo�n� degradovat ��inek siln�j��ho slab��m - nap�. katalyz�tor s�la 5 nam�chan� do katalyz�toru s�la 60 = katalyz�tor s�la 5!</p>
   <p>V n�sleduj�c�ch tabulk�ch naleznete soupis ve�ker�ch ingredienc�, kter� m��ete ve h�e nal�zt.</p>

   <h5>Ingredience pro �erven� lektvary</h5>

   <table cellspacing="0" cellpadding="5px" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item141.png" width="29px" height="30px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Bobule komin��ku</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Bobule komin��ku mohou b�t pou�ity pro nam�chan� �erven�ho lektvaru. (Pou�ije� je tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item144.png" width="26px" height="30px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Drcen� r��ov� l�stky</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Drcen� r��ov� l�stky mohou b�t pou�ity pro nam�chan� �erven�ho lektvaru. (Pou�ije� je tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item145.png" width="28px" height="66px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Ampule trol� krve</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Ampule trol� krve m��e b�t pou�ita pro nam�chan� �erven�ho lektvaru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item200.png" width="32px" height="19px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Rub�n</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>20</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Rub�n m��e b�t pou�it pro nam�chan� �erven�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item147.png" width="29px" height="32px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Dra�� oko</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>50</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Dra�� oko m��e b�t pou�ito pro nam�chan� �erven�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h5>Ingredience pro modr� lektvary</h5>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item140.png" width="32px" height="32px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Ko�en z phimy</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Ko�en z phimy m��e b�t pou�it pro nam�chan� modr�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item148.png" width="40px" height="30px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">�lomek meteoritu</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. �lomek meteoritu m��e b�t pou�it pro nam�chan� modr�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item149.png" width="19px" height="70px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Pero harpyje</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Pero harpyje m��e b�t pou�ito pro nam�chan� modr�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item150.png" width="32px" height="34px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">M�s��n� k�men</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>20</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. M�s��n� k�men m��e b�t pou�it pro nam�chan� modr�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item151.png" width="38px" height="33px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Elf� muchom�rka</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>50</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Elf� muchom�rka m��e b�t pou�ita pro nam�chan� modr�ho lektvaru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h5>Ingredience pro �lut� lektvary</h5>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item143.png" width="31px" height="30px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">�lut� kv�ty m�ku</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. �lut� kv�ty m�ku mohou b�t pou�ity pro nam�chan� �lut�ho lektvaru. (Pou�ije� je tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item152.png" width="32px" height="59px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Prach z Fae</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Prach z Fae m��e b�t pou�it pro nam�chan� �lut�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item153.png" width="35px" height="33px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">S�ra</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. S�ra m��e b�t pou�ita pro nam�chan� �lut�ho lektvaru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item201.png" width="32px" height="19px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Gran�t</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>20</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Gran�t m��e b�t pou�it pro nam�chan� �lut�ho lektvaru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item155.png" width="33px" height="64px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Ampule ��blovy krve</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>50</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Ampule ��blovy krve m��e b�t pou�ita pro nam�chan� �lut�ho lektvaru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h5>Ingredience pro katalyz�tory</h5>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item142.png" width="26px" height="30px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Houba</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Houba m��e b�t pou�ita pro nam�chan� katalyz�toru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item156.png" width="40px" height="33px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Obsidi�n</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Obsidi�n m��e b�t pou�it pro nam�chan� katalyz�toru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item157.png" width="32px" height="59px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Ampule endoplazmy</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Ampule endoplazmy m��e b�t pou�ita pro nam�chan� katalyz�toru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item158.png" width="30px" height="66px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Rtu�</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>20</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. Rtu� m��e b�t pou�ita pro nam�chan� katalyz�toru. (Pou�ije� ji tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 20px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item159.png" width="34px" height="34px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">K�men mudrc�</td>
      </tr>
      <tr>
         <td>S�la:</td>
         <td>75</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� p��sada neobvykl�ch vlastnost�. K�men mudrc� m��e b�t pou�it pro nam�chan� katalyz�toru. (Pou�ije� ho tak, �e p��sadou klikne� prav�m tla��tkem na pr�zdnou l�hev.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <p>Podle �rovn� dovednosti alchymie rozli�ujeme 5 kategori� lektvar�:
   
   <ol>
      <li style="padding: 5px;"><span class="tucne">jednoduch� lektvary</span> (�ed�, modr�, �erven� a �lut� lektvary), sm� je m�chat i postavy bez znalosti alchymie</li>
      <li style="padding: 5px;"><span class="tucne">jednoduch� sm�si</span> (zelen�, oran�ov� a fialov� lektvary), vznikaj� sm�ch�n�m jednoduch�ch lektvar�, k jejich m�sen� je t�eba alespo� norm�ln� �rovn� dovednosti alchymie</li>
      <li style="padding: 5px;"><span class="tucne">vrstven� lektvary</span> (lektvar se skl�d� z vrstev barvy obou p�vodn�ch lektvar�), jsou obvykle sm�s� z�kladn�ho lektvaru a jednoduch� sm�si, k jejich m�sen� je t�eba alespo� expertn� �rovn� dovednosti alchymie</li>
      <li style="padding: 5px;"><span class="tucne">b�l� lektvary</span> (obvykle kombinace vrstven�ch lektvar�), k jejich m�sen� je t�eba alespo� mistrovsk� �rovn� dovednosti alchymie</li>
      <li style="padding: 5px;"><span class="tucne">�ern� lektvary</span>, sm� m�sit pouze velmist�i alchymie</li>
   </ol>
   
   <p>�rove� dovednosti alchymie m� tedy vliv pouze na schopnost m�chat lektvary vy���ch kategori�, nijak se neprojevuje v jejich s�le. Velmistr opravdu nam�ch� stejn� siln� lektvar Hojen� ran jako u�edn�k se shodn�m po�tem bod� v norm�ln� �rovni alchymie. Pokud postava nedosahuje pot�ebn� �rovn� v dovednosti alchymie, bude pokus o nam�ch�n� vy���ho lektvaru ne�sp�n� a obvykle dojde k v�buchu.</p>
   
   <p>�ern� lektvary d�vaj� bez ohledu na parametr s�ly konstantn� efekt. V p��pad� elix�r� zvy�uj�c�ch z�kladn� atributy postavy m��e ka�d� postava "�sp�n�" vyp�t jen jeden lektvar ka�d�ho druhu. Jak�koliv dal�� konzumace dan�ho lektvaru u� ke zv��en� p��slu�n�ho atributu nepovede. Je tedy mo�no si pomoc� elix�ru zv��it jen 50 bod� ka�d�ho atributu.</p>
   
   <p>Ani u b�l�ch lektvar� stejn�ho typu neni efekt kumulativn� (nes��t� se), v�dy se projev� jen nejsiln�j�� pou�it� lektvar, kter� p�ebije ��inek toho slab��ho. Naopak slab�� lektvar v ��dn�m p��pad� nesn��� ��inky siln�j��ho.</p>
   
   <p>U vrstven�ch lektvar� p�id�vaj�c�ch bonus k ur�it� vlastnosti (lektvary s efekty kouzel Po�ehn�n�, Kamenn� k��e a Hrdinstv�) je pak efekt u� zcela konstantn� a �in� +5 k dan� vlastnosti. S�la lektvaru m� vliv jen na d�lku trv�n�, tak�e siln�j�� lektvar zm�n� jen jej� dobu. V�sledek je celkov� slab��, ne� p�i pou�it� odpov�daj�c�ho kouzeln�ho svitku, ov�em pr�v� d�lka trv�n� kouzla je u� v z�kladu o n�co del�� (p�i vy��� s�le lektvaru pak roste dokonce v�razn� rychleji, ne� u p��slu�n�ch magick�ch dovednost�).</p>

   <p>Z toho v�eho plyne n�kolik d�le�it�ch pou�ek:
   
   <ul>
      <li style="padding: 5px;">�ern� lektvary sta�� m�chat z levn�j��ch surovin (efekt bude stejn�).</li>
      <li style="padding: 5px;">U vrstven�ch lektvar� ovliv�uje s�la lektvaru pouze d�lku trv�n� efektu.</li>
      <li style="padding: 5px;">Je zbyte�n� v jednu chv�li konzumovat v�ce lektvar� stejn�ho typu (by� nap�. odli�n� s�ly) - ��inky se nes��taj�.</li>
      <li style="padding: 5px;">Naopak, siln�j�� lektvar stejn�ho typu m��e p�eb�t ��inky jeho slab�� verze.</li>
      <li style="padding: 5px;">Lep�� ingredience je dobr� si schov�vat a� pro b�l� lektvary.</li>
   </ul>
   
   <p>Ke v�emu lektvar narozd�l od kouzla nem��e selhat, ��inkuje v�dy. Lektvary jako jsou Odstran�n� proklet�, Odstran�n� ��lenstv� nebo Sejmi strach obch�zej� nutnost ovl�dat magii mysli nebo ducha na vy���ch �rovn�ch, co� se v po��tc�ch nebo u dru�iny bez klerika / druida m��e hodit. Je�t� v�razn�j�� rozd�l p�in�ej� t�eba b�l� lektvary s bonusem k odolnostem - i slab�� verze se pomalu dotahuj� na ��inek odpov�daj�c�ch kouzel. Kup��kladu m�g s velmistrovskou �rovn� magie vzduchu (10 bod�), dok�e seslat Ochranu proti vzduchu s bonusem +40 bod� k odolnosti proti vzduchu a trv�n� 10 hodin. Velmistr alchymie (10 bod�) um� z nejb�n�j��ch ingredienc� vyrobit lektvar Odolnosti proti vzduchu o s�le 11 bod�. Tedy bonus +33 bod� k odolnosti proti vzduchu a trv�n� 5 hodin 30 minut. Ov�em aplikac� katalyz�toru z kamene mudruc� dok�e vyrobit lektvar o s�le 85 bod�. V tu chv�li je bonus k odolnosti +255 bod� a d�lka trv�n� 1 den 18 hodin 30 minut. To je prakticky u� mimo schopnosti element�rn� magie.</p>
   
   <p>I p�i maxim�ln�m investovan�m mno�stv� 60 bod� do magie vzduchu by to bylo "jen" +240 bod� k odolnosti. P�itom ve h�e by z�skat tak vysokou �rove� obn�elo nutnost investice 1829 zku�enostn�ch bod�, �emu� odpov�d� level 152 prakticky p�i �ist� specializaci na tuto jednu dovednost + cca 3,5 roku hern�ho �asu samotn�ho tr�ninku. Konkurovat by tomu mohla jen specializace na magii sv�tla, kdy kombinace velmistrovsk� �rovn� (60 bod�) a kouzla Den ochrany, lze dos�hnout bonusu +300 bod� k odolnosti. Ov�em investic� 25 bod� do alchymie to lze snadno vyrovnat. V tomto se pr�v� ukr�v� s�la alchymie, kdy lze s nepom�rn� men��m �sil�m dos�hnout v�born�ch v�sledk�.</p>
   
   <p>Jednotliv� ingredience nelze p�id�vat p��mo, v�dy je t�eba z nich nejprve vytvo�it lektvar a teprve ten pou��t k m�sen�. Kdy� se postav� poda�� vytvo�it nov� lektvar, bude pot�ebn� kombinace ingredienc� automaticky zaps�na do pozn�mek. Neni v�ak t�eba lektvary tvo�it zkusmo, ale m��eme si v alchymistick�m obchod� zakoupit ji� hotov� recept, podle kter�ho p��slu�n� lektvar vyrob�me. M� to v�ak tu nev�hodu, �e lze zakoupit jen recepty na elix�ry a b�l� lektvary - pro lektvary ni���ch �rovn� recepty nejsou. Recept pro elix�r stoj� 500 zl, pro b�l� lektvar pak 150 zl. Jejich p�ehled naleznete v n�sleduj�c� tabulce.</p>

   <table cellspacing="0" cellpadding="3px" width="550px" border="1" style="margin-left: 20px;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev lektvaru</td>
         <td style="width: 100px;">Typ lektvaru</td>
         <td style="width: 300px;">Recept</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r ml�d�</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r ml�d� m��e odstranit ne��douc� ��inky um�l�ho zest�rnut�. Pro jeho nam�ch�n� pot�ebuje� naj�t spr�vnou kombinaci t�� ze z�kladn�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r s�ly</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r s�ly je snem ka�d�ho dobrodruha. Trvale p�id� komukoliv s�lu a zm�n� ho tak v bojov� stroj. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci �ty� n�jak�ch �erven�ch p��sad plus dva n�kter� druhy modr�ch p��sad a jedn� �lut� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r p�esnosti</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r p�esnosti je snem ka�d�ho lukost�elce. Trvale zv��� komukoliv p�esnost a zm�n� ho tak v bojov� stroj. Pro jeho nam�ch�n� pot�ebuje� naj�t spr�vnou kombinaci �ty� druh� �lut�ch p��sad plus n�kter�ch dvou druh� �erven�ch p��sad a jedn� modr� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r osobnosti</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r osobnosti trvale zv��� osobnost a t�m i mno�stv� many, kter� od osobnosti z�vis�. Pro jeho nam�ch�n� pot�ebuje� naj�t spr�vnou kombinaci jedn� z �erven�ch p��sad plus �ty� druh� modr�ch p��sad a dvou druh� �lut�ch.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r odolnosti</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r odolnosti je snem ka�d�ho dobrodruha. Trvale zv��� odolnost kter�koliv postav� a zm�n� ji tak v bojov� stroj. V�razn� zv��� jej� zdrav� vysoko nad jej� norm�l. Pro jeho nam�ch�n� pot�ebuje� naj�t spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad plus �ty� druh� modr�ch p��sad a jedn� �lut� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r inteligence</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r inteligence trvale zv��� postav� inteligenci, zv��� celkov� mno�stv� many, kter� od inteligence z�vis�. Pro jeho nam�ch�n� pot�ebuje� naj�t spr�vnou kombinaci jedn� z �erven�ch p��sad plus dvou druh� modr�ch p��sad a �ty� �lut�ch.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r rychlosti</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r rychlosti se hod� hlavn� v p��pad�, pokud dru�ina bojuje s rychl�mi nestv�rami. Elix�r trvale zv��i rychlost, ��m� se postava dostane na tah d��ve ne� nestv�ra. Rychlosti nikdy nen� dost. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci �ty� n�jak�ch �erven�ch p��sad plus dva n�kter� druhy modr�ch p��sad a jedn� �lut� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">Elix�r �t�st�</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Elix�r �t�st� m��e b�t �e�en�m pro dru�inu, kter� nem� dovednost odstra�ov�n� past�. Trval� zv��en� �t�st� je zrovna to, co pot�ebuje�, aby ses vyhnul nastra�en�m past�m. �t�st� nen� nikdy dost. Pro jeho nam�ch�n� pot�ebuje� naj�t spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad plus t�� druh� modr�ch p��sad a t�� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Drakobijn� n�t�r</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Drakobijn� n�t�r p�id� nemagick� zbrani schopnost Zhouba drak�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci �ty� n�jak�ch �erven�ch p��sad plus t�� druh� modr�ch p��sad a dvou druh� �lut�ch.</td>
      </tr>
      <tr>
         <td class="popis_2">Odkamen�n�</td>
         <td class="popis_2">�ern� lektvar</td>
         <td class="popis_2">Odkamen�n� ti umo�n� odstranit zkamen�n�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch �erven�ch p��sad plus n�kter� dva druhy modr�ch p��sad a t�� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� s�ly</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� s�ly do�asn� zv��� s�lu postavy tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch �erven�ch p��sad a n�kter�ch dvou modr�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� intelektu</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� intelektu do�asn� zv��� tvou inteligenci tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou modr�ch druh� p��sad a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� osobnosti</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� osobnosti do�asn� zv��� tvou osobnost tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� modr�ch druh� p��sad a dvou druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� odolnosti</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� odolnosti do�asn� zv��� tvou odolnost tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad a t�� druh� modr�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� rychlosti</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� rychlosti do�asn� zv��� tvou rychlost tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch �erven�ch p��sad a dvou druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� p�esnosti</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� p�esnosti do�asn� zv��� tvou p�esnost tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Plamenn� n�t�r</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Plamenn� n�t�r p�id� oby�ejn� zbrani schopnost ...ohn�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad plus jedn� modr� p��sady a dvou druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Mraziv� n�t�r</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Mraziv� n�t�r p�id� oby�ejn� zbrani schopnost ...mrazu. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad plus dvou modr�ch druh� p��sad a jedn� �lut�.</td>
      </tr>
      <tr>
         <td class="popis_2">Zhoubn� n�t�r</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zhoubn� n�t�r p�id� oby�ejn� zbrani schopnost ...jedu. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci n�kter� �erven� p��sady plus dvou modr�ch druh� p��sad a dvou druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Jiskrn� n�t�r</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Jiskrn� n�t�r p�id� oby�ejn� zbrani schopnost ...jisker. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch �erven�ch p��sad plus jedn� modr� p��sady a jedn� �lut� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">Svi�tiv� n�t�r</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Svi�tiv� n�t�r p�id� oby�ejn� zbrani schopnost ...rychlosti. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci n�kter� �erven� p��sady plus t�� modr�ch druh� p��sad a jedn� �lut� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">L�k na ochromen�</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">L�k na ochromen� vyl��� tv� postav� ochromen�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci n�kter� �erven� p��sady plus jedn� modr� p��sady a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Bo�sk� uzdraven�</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Bo�sk�ho uzdraven� odstra�uje v�echny negativn� stavy krom� zkamen�n�, smrti a zahuben�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci n�kter� �erven� p��sady plus jedn� modr� p��sady a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Bo�sk� l�k</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Bo�sk� l�k je mnohem siln�j�� ne� lektvar Hojen� ran. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch �erven�ch p��sad a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Bo�sk� s�la</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Bo�sk� s�ly je mnohem siln�j�� ne� lektvar Magick� n�poj. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch modr�ch p��sad a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Zv��en� �t�st�</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Zv��en� �t�st� do�asn� zv��� tv� �t�st� tehdy, kdy to bude� pot�ebovat. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� n�jak�ch �erven�ch p��sad a t�� druh� modr�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Odolnost proti ohni</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Odolnosti proti ohni do�asn� zv��� tvoji odolnost proti �kod�m zp�soben�m magii ohn�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou n�jak�ch �erven�ch p��sad plus jedn� modr� p��sady a t�� druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Odolnost proti vzduchu</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Odolnosti proti vzduchu do�asn� zv��� tvoji odolnost proti �kod�m zp�soben�m magii vzduchu. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci t�� druh� �erven�ch p��sad plus dvou druh� modr�ch p��sad a jedn� �lut�.</td>
      </tr>
      <tr>
         <td class="popis_2">Odolnost proti vod�</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Odolnosti proti vod� do�asn� zv��� tvoji odolnost proti �kod�m zp�soben�m magii vody. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci jedn� z �erven�ch p��sad plus t�� modr�ch druh� p��sad a dvou druh� �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Odolnost proti zemi</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Odolnosti proti zemi do�asn� zv��� tvoji odolnost proti �kod�m zp�soben�m magii zem�. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci n�kter�ch t�� druh� �erven�ch p��sad plus jedn� z modr�ch druh� p��sad a dvou �lut�ch p��sad.</td>
      </tr>
      <tr>
         <td class="popis_2">Odolnost proti mysli</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Odolnosti proti mysli do�asn� zv��� tvoji odolnost proti �kod�m zp�soben�m magii mysli. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci dvou n�kter�ch druh� �erven�ch p��sad plus t�� n�jak�ch modr�ch p��sad a jedn� �lut� p��sady.</td>
      </tr>
      <tr>
         <td class="popis_2">Odolnost proti t�lu</td>
         <td class="popis_2">B�l� lektvar</td>
         <td class="popis_2">Odolnosti proti t�lu do�asn� zv��� tvoji odolnost proti �kod�m zp�soben�m magii t�la. Pro jeho nam�ch�n� pot�ebuje� spr�vnou kombinaci jedn� z �erven�ch p��sad plus dvou n�jak�ch modr�ch p��sad a t�� �lut�ch p��sad.</td>
      </tr>
   </table>

   <p>Pokud si st�le nev�te s n�kter�mi lektvary rady nebo nechcete pokusni�it, tak v n�sleduj�c�m p�ehledu naleznete konkr�tn� n�vody na jednotliv� lektvary.</p>

   <h3>Norm�ln� �rove�</h3>
   
   <h5>Katalyz�tor (�ed� lektvar)</h5>
	 <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item164.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Katalyz�tor se pou��v� pro zv��en� s�ly lektvaru. Slab�� lektvar p�evezme s�lu po siln�j��m katalyz�toru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Ze �ed�ch ingredienc�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>
   
   <h5>Magick� n�poj (modr� lektvar)</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item160.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Obnov� (10 + s�la lektvaru) bod� many.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Z modr�ch ingredienc�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>5</td>
      </tr>
   </table>
   
   <h5>Hojen� ran (�erven� lektvar)</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item166.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Hoj� (10 + s�la lektvaru) bod� zdrav�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Z �erven�ch ingredienc�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>5</td>
      </tr>
   </table>
   
   <h5>Posilovac� n�poj (�lut� lektvar)</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item162.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">L��� �navu.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Ze �lut�ch ingredienc�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>5</td>
      </tr>
   </table>
   
   <h5>Probuzen� (zelen� lektvar)</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item167.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstran� sp�nek.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Modr� + �lut� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>L��en� nemoc� (oran�ov� lektvar)</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item168.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">L��� nemoc.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�erven� + �lut� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Protijed (fialov� lektvar)</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item161.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">L��� otravu.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Modr� + �erven� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h3>Expertn� �rove�</h3>

   <h5>Po�ehn�n�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item171.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo po�ehn�n� a trv� 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�erven� + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Odstran�n� ��lenstv�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item180.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstra�uje ��lenstv�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Oran�ov� + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Zpevn�n� p�edm�tu</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item177.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Zpevn� p�edm�t a t�m jej u�in� odoln�j��m v��i zni�en�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�lut� + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Zrychlen�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item169.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo zrychlen� a trv� 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�erven� + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Hrdinstv�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item170.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo Hrdinstv� a trv� 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�erven� + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Ochrana</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item172.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo Ochrana a trv� 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Modr� + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Nabit� p�edm�tu</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item174.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo Nabit� p�edm�tu. P�edm�t trvale ztr�c� (70% - s�la lektvaru) sv�ch n�pln�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Modr� + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Odstran�n� proklet�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item179.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstra�uje proklet�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Fialov� + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Sejmi strach</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item178.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstra�uje strach.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Oran�ov� + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>�t�t</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item173.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo �t�t a trv� 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Modr� + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>Kamenn� k��e</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item175.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Funguje jako kouzlo Kamenn� k��e a trv� 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�lut� + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h5>D�ch�n� pod vodou</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item176.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstra�uje nebezpe�� utonut�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�lut� + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <h3>Mistrovsk� �rove�</h3>

   <h5>Zv��en� p�esnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� p�esnost postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Kamenn� k��e + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zv��en� odolnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�t�t + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zv��en� intelektu</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� inteligenci postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zpevn�n� p�edm�tu + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zv��en� �t�st�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� �t�st� postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�t�t + Hrdinstv�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zv��en� s�ly</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� s�lu postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hrdinstv� + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zv��en� osobnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� osobnost postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Nabit� p�edm�tu + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zv��en� rychlosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� rychlost postavy o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zrychlen� + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Odolnost proti vzduchu</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost proti vzduchu o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�t�t + Zrychlen�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Odolnost proti t�lu</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost proti t�lu o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Nabit� p�edm�tu + Kamenn� k��e</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Odolnost proti zemi</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost proti zemi o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hrdinstv� + Kamenn� k��e</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Odolnost proti ohni</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost proti ohni o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zpevn�n� p�edm�tu + Zrychlen�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Odolnost proti mysli</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost proti mysli o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Nabit� p�edm�tu + Hrdinstv�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Odolnost proti vod�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Do�asn� zv��� odolnost proti vod� o 3x s�la lektvaru na 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zpevn�n� p�edm�tu + �t�t</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>L�k na ochromen�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstra�uje ochromen�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Kamenn� k��e + zelen� lektvar, nebo Zpevn�n� p�edm�tu + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Bo�sk� l�k</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Vyl��� 5x s�la lektvaru bod� zdrav�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zrychlen� + Kamenn� k��e</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Bo�sk� uzdraven�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstra�uje v�echny negativn� stavy krom� smrti, zkamen�n� a zahuben�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Nabit� p�edm�tu + Zrychlen�, nebo Zpevn�n� p�edm�tu + Hrdinstv�, nebo �t�t + Kamenn� k��e</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Bo�sk� s�la</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Obnov� 5x s�la lektvaru bod� many.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zpevn�n� + Nabit� p�edm�tu</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Plamenn� n�t�r</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Nemagick� zbrani dod� vlastnost "... ohn�" na dobu 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zrychlen� + zelen� lektvar nebo Kamenn� k��e + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Mraziv� n�t�r</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Nemagick� zbrani dod� vlastnost "... mrazu" na dobu 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hrdinstv� + zelen� lektvar nebo �t�t + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Zhoubn� n�t�r</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Nemagick� zbrani dod� vlastnost "... jedu" na dobu 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zpevn�n� p�edm�tu + fialov� lektvar nebo Nabit� p�edm�tu + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Jiskrn� n�t�r</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Nemagick� zbrani dod� vlastnost "... jisker" na dobu 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hrdinstv� + oran�ov� lektvar nebo Zrychlen� + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h5>Svi�tiv� n�t�r</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item163.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Nemagick� zbrani dod� vlastnost "... rychlosti" na dobu 30 minut za bod s�ly lektvaru.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Nabit� p�edm�tu + fialov� lektvar nebo �t�t + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h3>Velmistrovsk� �rove�</h3>

   <h5>Elix�r p�esnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do p�esnosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zv��en� p�esnosti + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r inteligence</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do inteligence.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zv��en�  + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r osobnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do osobnosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zv��en� osobnosti + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r �t�st�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do �t�st�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Kamenn� k��e + Svi�tiv� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r odolnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do odolnosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zv��en� odolnosti + zelen� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r s�ly</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do s�ly.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zv��en� s�ly + oran�ov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r rychlosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�id� postav� trvale 50 bod� do rychlosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Zv��en� rychlosti + fialov� lektvar</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Elix�r ml�d�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstran� ve�ker� nep�irozen� st�rnut�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Posv�cen� + Bo�sk� uzdraven�, nebo Ochrana + Bo�sk� uzdraven�, nebo D�ch�n� pod vodou + Bo�sk� uzdraven�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Drakobijn� n�t�r</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Nemagick� zbrani dod� vlastnost "Zhouba drak�".</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>�t�t + Plamenn� n�t�r</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h5>Odkamen�n�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/item165.png" width="28px" height="58px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstran� zkamen�n�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hrdinstv� + Odstra� ochromen�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
