<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>�ifra</h2>
   <p>&nbsp;</p>
   
   <p>Za cestu temnoty dostanete p�ed pov��en�m zasv�cence na ninju �kol rozlu�tit k�d ze svitku s �ifrou, kter� v�m d� Stephan Sand v J�m�. Jeho obsah v�m pom��e naj�t hrobku Ashwara Nog�Nogotha v Erathii, resp. uk�e v�m zp�sob, jak do n� vstoupit. Porad� v�m, �e k tomu budete pot�ebovat svitek vln ze �koly kouzelnictv� v Brakad� a z�rove� v�s nasm��uje do ji�n� Erathie, kde by se hrobka m�la nach�zet. Tuto informaci si budete moci potvrdit pomoc� V�pisu z den�ku, kter� se nach�z� v jedn� z cel hradu Harmondale. Kombinaci u vstupu hrobky rozlu�t�te i bez svitku, ale pro zaj�mavost zde uvedu, jak by se to b�valo �e�ilo.</p>
   
   <p>I kdy� z�sk�te svitek vln, nebudete o nic moud�ej��, proto�e jeho obsah je vcelku nic ne��kaj�c�. Stephan v�m v�ak poradil, �e k rozk�dov�n� �ifry m�te pou��t t�et� slovo ze svitku vln. Je tedy z�ejm�, �e mus� existovat zp�sob/metoda, jak podle tohoto slova v dek�dov�n� postupovat. Therese Umberpool z domku hned vedle Stephana v�m pov� o svitku se z�klady �ifrov�n�. Nach�z� se pr� v hradn� knihovn�. U� v�m v�ak ne�ekne o jak� hrad se jedn�. V hradu Gloaming knihovna neni, ov�em po zkou�ce s L�hn� v�m Archibald za��d� dal�� rekonstrukci hradu Harmondale a kupodivu v�m v n�m p�ibude i knihovna. Za jednou z polic naleznete svitek se Z�klady �ifrov�n�. Te� u� v�m nic nebr�n� v rozlu�t�n� �ifry.</p>
   
   <p>Z�klady �ifrov�n� obsahuj� zna�n� podrobn� popis postupu, kter� pou�ijeme. Nejprve bude t�eba si vytvo�it �adu 26 znak� z abecedy bez diakritiky a s vynech�n�m p�smene ch. Pak si p�smena ozna��me ��sly od 1 do 26 (1 = a, 26 = z).</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="468px" style="margin: auto;" border="0">
      <tr>
         <td style="width: 18px;">a</td>
         <td style="width: 18px;">b</td>
         <td style="width: 18px;">c</td>
         <td style="width: 18px;">d</td>
         <td style="width: 18px;">e</td>
         <td style="width: 18px;">f</td>
         <td style="width: 18px;">g</td>
         <td style="width: 18px;">h</td>
         <td style="width: 18px;">i</td>
         <td style="width: 18px;">j</td>
         <td style="width: 18px;">k</td>
         <td style="width: 18px;">l</td>
         <td style="width: 18px;">m</td>
         <td style="width: 18px;">n</td>
         <td style="width: 18px;">o</td>
         <td style="width: 18px;">p</td>
         <td style="width: 18px;">q</td>
         <td style="width: 18px;">r</td>
         <td style="width: 18px;">s</td>
         <td style="width: 18px;">t</td>
         <td style="width: 18px;">u</td>
         <td style="width: 18px;">v</td>
         <td style="width: 18px;">w</td>
         <td style="width: 18px;">x</td>
         <td style="width: 18px;">y</td>
         <td style="width: 18px;">z</td>
      </tr>
      <tr>
         <td>1</td>
         <td>2</td>
         <td>3</td>
         <td>4</td>
         <td>5</td>
         <td>6</td>
         <td>7</td>
         <td>8</td>
         <td>9</td>
         <td>10</td>
         <td>11</td>
         <td>12</td>
         <td>13</td>
         <td>14</td>
         <td>15</td>
         <td>16</td>
         <td>17</td>
         <td>18</td>
         <td>19</td>
         <td>20</td>
         <td>21</td>
         <td>22</td>
         <td>23</td>
         <td>24</td>
         <td>25</td>
         <td>26</td>
      </tr>
   </table>
   </div>
   
   <p>Pod text �ifry si pak dop��eme �ifrovac� kl��, tedy t�et� slovo ze svitku vln, kter� zn� vzorek a to takov�m zp�sobem, aby se pod textem �ifry opakoval (s vynech�n�m mezer a te�ek), viz n�sleduj�c� uk�zka:</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="306px" style="margin: auto;" border="0">
      <tr>
         <td style="width: 18px;">J</td>
         <td style="width: 18px;">a</td>
         <td style="width: 18px;">h</td>
         <td style="width: 18px;">w</td>
         <td style="width: 18px;">q</td>
         <td style="width: 18px;"></td>
         <td style="width: 18px;">u</td>
         <td style="width: 18px;">o</td>
         <td style="width: 18px;">e</td>
         <td style="width: 18px;">b</td>
         <td style="width: 18px;"></td>
         <td style="width: 18px;">z</td>
         <td style="width: 18px;">w</td>
         <td style="width: 18px;">z</td>
         <td style="width: 18px;">x</td>
         <td style="width: 18px;">k</td>
         <td style="width: 18px;">j</td>
      </tr>
      <tr>
         <td>v</td>
         <td>z</td>
         <td>o</td>
         <td>r</td>
         <td>e</td>
         <td></td>
         <td>k</td>
         <td>v</td>
         <td>z</td>
         <td>o</td>
         <td></td>
         <td>r</td>
         <td>e</td>
         <td>k</td>
         <td>v</td>
         <td>z</td>
         <td>o</td>
      </tr>
   </table>
   </div>
   
   <p>Ka�d� znak, jak �ifry tak i kl��e, p�evedeme na ��sla podle prvn� tabulky a ty pak ve sloupci od sebe ode�teme. Pokud je v�sledek z�porn� nebo roven nule, tak n�mu p�i�teme ��slo 26. ��seln� v�sledky pak op�t podle prvn� tabulky p�evedeme na p�smena a m�me hotovo, viz:</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="324px" style="margin: auto;" border="0">
      <tr>
         <td style="width: 18px;"></td>
         <td style="width: 18px;">10</td>
         <td style="width: 18px;">1</td>
         <td style="width: 18px;">8</td>
         <td style="width: 18px;">23</td>
         <td style="width: 18px;">17</td>
         <td style="width: 18px;"></td>
         <td style="width: 18px;">21</td>
         <td style="width: 18px;">15</td>
         <td style="width: 18px;">5</td>
         <td style="width: 18px;">2</td>
         <td style="width: 18px;"></td>
         <td style="width: 18px;">26</td>
         <td style="width: 18px;">23</td>
         <td style="width: 18px;">26</td>
         <td style="width: 18px;">24</td>
         <td style="width: 18px;">11</td>
         <td style="width: 18px;">10</td>
      </tr>
      <tr>
         <td>-</td>
         <td>22</td>
         <td>26</td>
         <td>15</td>
         <td>18</td>
         <td>5</td>
         <td></td>
         <td>11</td>
         <td>22</td>
         <td>26</td>
         <td>15</td>
         <td></td>
         <td>18</td>
         <td>5</td>
         <td>11</td>
         <td>22</td>
         <td>26</td>
         <td>15</td>
      </tr>
      <tr>
         <td>=</td>
         <td>14</td>
         <td>1</td>
         <td>19</td>
         <td>5</td>
         <td>12</td>
         <td></td>
         <td>10</td>
         <td>19</td>
         <td>5</td>
         <td>13</td>
         <td></td>
         <td>8</td>
         <td>18</td>
         <td>15</td>
         <td>2</td>
         <td>11</td>
         <td>21</td>
      </tr>
      <tr>
         <td colspan="18">&nbsp;</td>
      </tr>
      <tr>
         <td>=</td>
         <td>N</td>
         <td>a</td>
         <td>s</td>
         <td>e</td>
         <td>l</td>
         <td></td>
         <td>j</td>
         <td>s</td>
         <td>e</td>
         <td>m</td>
         <td></td>
         <td>h</td>
         <td>r</td>
         <td>o</td>
         <td>b</td>
         <td>k</td>
         <td>u</td>
      </tr>
   </table>
   </div>
   
   <p>Stejn�m zp�sobem pokra�ujete d�le. Je to pon�kud zdlouhav�, ale sta�� v�m rozlu�tit jen ��st. Cel� zpr�va pak zn�: "Nasel jsem hrobku Mistra Kelvina a z jeho poznamek odvodil heslo. Je to sever vychod jih zapad stred. Svuj ukol jsem splnil a dluh splatil. Hodne stesti."</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
