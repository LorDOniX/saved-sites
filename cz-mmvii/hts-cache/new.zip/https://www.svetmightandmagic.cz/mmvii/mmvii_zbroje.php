<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VII</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; border: none; text-indent: 5px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvii_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <a class="zalozka" name="00"></a>
   <h2>Zbroje</h2>
   
   <ul>
      <li><a href="#01">Ko�en� zbroje</a></li>
      <li><a href="#02">Krou�kov� zbroje</a></li>
      <li><a href="#03">Pl�tov� zbroje</a></li>
      <li><a href="#04">�t�ty</a></li>
      <li><a href="#05">Helmy</a></li>
      <li><a href="#06">Pl�t�</a></li>
      <li><a href="#07">Rukavice</a></li>
      <li><a href="#08">Boty</a></li>
   </ul>
   
   <h3><a class="zalozka" name="01">Ko�en� zbroje</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item066.png" width="85px" height="110px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ko�en� zbroj je nejleh�� a nejsn�ze se nos�, poskytuje ale men�� ochranu ne� t쾹� zbroje. K��e t�to zbroje byla neodborn� vy�in�na a dosud p�chne po pou�it�ch chemik�li�ch.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item067.png" width="85px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vycp�van� ko�en� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato ko�en� zbroj je nam�sto ko�en�ch p�sk� zpevn�na bronzov�mi cvoky m�sto. Jej� konstrukce je o n�co pevn�j��, ale tak� t쾹�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item068.png" width="87px" height="106px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�stojnick� ko�en� krun��</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jinak b�n� ko�en� zbroj je zpevn�na jemn�m okouzlen�m, ani� by se t�m zv��ila jej� v�ha.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item069.png" width="90px" height="111px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Regnansk� ko�en� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>16</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Standardn� typ ko�en� zbroje pro d�stojn�ky Regnansk�ho n�mo�nictva. V�echny tyto zbroje byly b�hem v�roby v regnansk�ch d�ln�ch okouzleny pro zpevn�n� i pro sn��en� v�hy.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item070.png" width="130px" height="108px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kr�lovsk� ko�en� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>24</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Podobn�ch zbroj� bylo vyrobeno jen p�r a v�echny byly ur�eny pro �leny erathijsk� kr�lovsk� dynastie - Gryphonhearty. P�vod t�to zbroje lze vysv�tlit pouze jednou ze t�� mo�nost�: bu� byla uloupena z kr�lovsk� zbrojnice, uko�ist�na v bitv� nebo ukradena z hrobky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1150</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="02">Krou�kov� zbroje</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item071.png" width="95px" height="158px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Krou�kov� zbroj je tvo�en� mal�mi kovov�mi z�et�zen�mi krou�ky. Vypad�, jakoby ji kdosi zapomn�l naolejovat, nebo jakoby zmokla na de�ti, nebo� kolem pr�ramk� a n�kr�n�ku za��n� reziv�t.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item072.png" width="99px" height="154px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbroj je z oceli a je tud�� leh��, ne� podobn� zbroje vyroben� ze �eleza. Jej� krou�ky jsou ten��, ale proto�e jsou ocelov�, jsou velmi pevn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item073.png" width="108px" height="160px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Honosn� krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>18</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vysoce kvalitn� ocel je na tomto brn�n� kombinov�na s pob�jenou k��� pro utlumen� ran a sn��en� v�hy. Ko�en� d�ly jsou obzvl�t� um�lecky zpracov�ny ku pot�e oka.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>900</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item074.png" width="140px" height="134px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Skvostn� krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>26</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">V�razn� a skvouc� zbroj jako tato slou�ila k rozpozn�n� d�stojn�k� uprost�ed bojov� v�avy. Nejenom�e dob�e vypad�, je to tak� ta nejleh�� krou�kov� zbroj, jak� je k m�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item075.png" width="103px" height="159px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zlat� krou�kov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>36</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Velmi vz�cn� zbroj poch�z� z Nebesk�ch v�hn� guvern�ra Padishe z doby p�ed Tichem. Nosili ji v�hradn� nejvy��� vojen�t� hodnost��i jako odznak sv�ho ��adu. Nebyla to pouze z�le�itost vzhledu, tato krou�kov� zbroj je leh��, pevn�j�� a poddajn�j�� ne� kter�koliv jin� zbroj kdekoliv na sv�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1800</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="03">Pl�tov� zbroje</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item076.png" width="120px" height="104px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>20</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Pl�tov� zbroj je ta nejpevn�j��, jak� je k dispozici. Je mnohem t쾹� ne� v�echny ostatn� zbroje a vy�aduje ur�it� tr�nink, ne� si na ni nositel zvykne. Tato zbroj je vyrobena ze �eleza a jej� zpracov�n� je v�edn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item077.png" width="114px" height="117px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">P�epychov� pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>28</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbroj poch�zej�c� z Erathijsk� zbrojnice je ozna�ena signaturou: B.R. sl�v�rna Steadwick 1151. Inici�ly n�le�� Byronu Rockermannovi, erathijsk�mu kr�lovsk�mu zbroj��i. Jeho d�la jsou profesion�ln� a elegantn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1400</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item078.png" width="118px" height="112px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�lechtick� pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>54</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tak skv�l� zbroj, �e m��e poch�zet pouze od samotn�ho Mistra - Mekoriga Slep�ho. A skute�n�, tato zbroj nese u ostruhy inici�ly mistrova syna Kaseva Mekoriga. Klouby se snadno pohybuj�, materi�l zaujme svou trojvrstevnou konstrukc�, d�ky n�� je zbroj tenk� a lehk� a p�esto neuv��iteln� pevn�. Tak� vylo�en� je velmi pohodln�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2700</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="04">�t�ty</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>V�echny �t�ty ve h�e se rozd�luj� do dvou samostatn�ch kategori� - na velk� a mal� �t�ty. Ka�d� z nich je pak op�t �azena podle kvality od nejhor��ho po nejlep��.</p>
   
   <h4>Velk� �t�ty</h4>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item079.png" width="83px" height="141px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Goblin� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Prost� star� �t�t s jednoduch�mi znamen�mi na l�ci. O�kliv�, ale praktick�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item080.png" width="88px" height="134px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ev�n� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento �t�t je vyroben ze d�eva a �elezn�ho r�mu. Je t�k�, ale dob�e vyroben� a v dobr�m stavu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item081.png" width="79px" height="189px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Jezdeck� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento �t�t je �zk� a dole vykrojen�, nebo� byl zam��len pro j�zdn� boj, ale p��kovi poslou�� stejn� dob�e. Jeho konstrukce je pevn�, materi�l tvrd� a m�l by odolat i p��m�mu �deru kop�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item082.png" width="93px" height="190px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tepan� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�t�t je vyroben� z lehk�ho kovu a nese na sob� zna�ku Kelebrimsk� zbrojnice. A�koliv je lehk�, jeho materi�l je pevn� - kovov� d�ly jsou spojen� t�m�� beze �v�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item083.png" width="100px" height="161px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Finaxijsk� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>19</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto �t�ty byly ukov�ny ve Fynaxiansk�m c�sa�stv� b�hem jejich nedlouh�ho vzestupu a n�jezd� na jihoerathijsk� stepi (790-864). �t�t je vyroben ze staltu, kovu, kter� snadno p�ij�m� okouzlen� a kter� v�razn� p�isp�l fynaxi�nsk� vojensk� moci. Bohu�el, tohoto kovu je mo�n� vyt�it jen velmi m�lo a Fynaxie padla v roce 864 A.S. pod elfsk�m �tokem.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>800</td>
      </tr>
   </table>
   
   <h4>Mal� �t�ty</h4>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item084.png" width="63px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mal� d�ev�n� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento �t�t byl vyvinut pro ochranu bojovn�ka proti ��p�m, ani� by jej p�itom n�jak p�et��il. Zpracov�n� je rukod�ln�, ale je ve skv�l�m stavu a dob�e spln� sv�j ��el.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item085.png" width="96px" height="94px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Bronzov� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Bronzov� �t�ty jsou leh�� ne� stejn� velk� �elezn� �t�ty, ale nejsou tak pevn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item086.png" width="101px" height="103px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kovov� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�kn� �erven� znak na povrchu �t�tu signalizuje, �e poch�z� z Deyje a �e �erven� barva na n�m nen� tak docela barva. N�t�r je emulgov�n a konzervov�n, aby si uchoval p�vodn� jas?</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item087.png" width="84px" height="108px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Legovan� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�esn� receptura slo�en� slitiny t�chto pevn�ch �t�t� byla stovky let ztracena. Pokusy o znovuobjeven� postupu v�robn�ho procesu skon�ily ne�sp�chem. Na t�chto �t�tech nen� naprosto nic �arod�jn�ho nebo magick�ho - ve�ker� okouzlen� byla p�id�na a� po jeho vyroben�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item088.png" width="84px" height="115px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vzne�en� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>18</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Temn� zlatav� barva t�chto �t�t� je ve skute�nosti kazem. Asi 50 t�chto �t�t� bylo odlo�eno z Nebesk� v�hn�, kdy� se za�aly kazit. A�koliv nejsou dokonal�, nevyrovnaj� se jim ��dn� jin� �t�ty krom� on�ch zm�n�n�ch prvot��dn�ch v�robk� V�hn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="05">Helmy</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item089.png" width="44px" height="51px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Helma s rohy</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato lacin� helma se hod� sp��e na ma�karn� b�l ne� do bitvy. Rohy jsou nalepeny na vy�in�nou ko�enou �apku nat�enou na�erno, aby vypadala hroziv�ji. Materi�l je k�ehk� a popraskan� a z�ejm� se rozpadne v nejm�n� vhodn� chv�li.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>60</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item090.png" width="36px" height="38px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Voj�nova helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Prost� styl a uniformita t�chto helem m� ���it hr�zu v srdc�ch nep��tel, kdy� spat�� les t�chto bronzov�ch �pi�at�ch helem val�c�ch se na n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>260</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item091.png" width="52px" height="61px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Turnajov� helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento druh helmy byl u��v�n erathijsk�mi elfy u� od dob Ticha. Helma je vyrobena ze st��bra a oceli a je velmi pevn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>460</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item092.png" width="57px" height="60px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Finaxijsk� helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato helma byla no�ena p�ed sto lety fynaxijsk�mi dragouny b�hem n�jezd� jejich imp�ria. Jsou to helmy pevn�, ohebn� a lehk�. Jsou vyrobeny ze dvou pruh� dra�� k��e spojen�ch navz�jem staltov�mi kovov�mi v�ztu�emi.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>660</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item093.png" width="62px" height="46px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mogredsk� helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto helmy, z��sti vyroben� z lebek divok�ho karigorsk�ho mogreda, jsou rok od roku vz�cn�j��, jak se mogredi bl��� sv�mu vyhuben�. Ze dvou rud�ch skvrn vp�edu na helm� �asto vyr�staj� dva jedov� trny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>860</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="06">Pl�t�</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item105.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Oby�ejn� cestovn� plṻ.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item106.png" width="64px" height="42px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Loveck� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Loveck� plṻ je zelen�, aby sn��il n�padnost lovce v lese. Nen� na n�m nic v�jime�n�ho, ale sv�mu ��elu poslou��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item107.png" width="64px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hrani���sk� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Utk�ny z vl�ken rostlin Tulareansk�ho lesa jsou tyto pl�t� tradi�n�m od�vem elfsk�ch hrani��r�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item108.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elegantn� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento plṻ odpov�d� svou kvalitou vkusu bohat�ch �lechtic� a dvo�an�. T�ko najde� lep��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item109.png" width="64px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Skv�l� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">T�m�� v�echny podobn� pl�t� dopl�uje n�jak� okouzlen�. Nighonsk� �arod�jnice zam�stn�vaj� z�stupy ment�ln� podroben�ch lid�, aby pro n� prov�d�li f�dn� tkan� a ritu�ln� za��k�v�n� nezbytn� pro v�robu t�chto plṻ�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="07">Rukavice</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item110.png" width="24px" height="63px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nekvalitn� �elezn� rukavice s textiln�m vylo�en�m proti puch���m.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item111.png" width="24px" height="63px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento p�r rukavic je vyroben z oceli zdoben� mosazn�m lemov�n�m na vn�j�� stran� dlan� a h�betu ruky. Jsou v dobr�m stavu a d�kladn� naolejovan�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item112.png" width="23px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">St��brn� rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Skv�l� v�robek ze st��brn�ho pletiva. Tyto rukavice byly ukov�ny a utk�ny v trpasli��ch zbroj��sk�ch d�ln�ch Kamenn�ho m�sta. Zaru�uj� jak ohebnost, tak i pevnost. Jejich jedinou vadou je, �e se poko�ka m��e ob�as sk��pnout mezi pletivem, co� je bolestiv�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item113.png" width="32px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Rukavice z dra�� k��e</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vysoce kvalitn� rukavice, vynikaj�c� jak ohebnost�, tak i ochranou, kterou poskytuj�. Spoje jsou zes�len�, p�esto jsou ale natolik pohybliv�, �e umo��uj� t�m�� norm�ln� pohyb ruky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item114.png" width="25px" height="61px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mogredsk� rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto pevn�, vl��n� a magicky odoln� rukavice jsou vyrobeny z k��e karigorsk�ho mogreda. Ze dvou rud�ch skvrn �asto vyr�staj� jedovat� trny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>850</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="08">Boty</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item115.png" width="64px" height="64px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto boty jsou vyrobeny z m�kk� k��e, aby se l�pe nosily, ale krom� toho poskytuj� i ur�itou ochranu v boji.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item116.png" width="64px" height="64px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Boty z pl�tov� oceli</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento p�r ko�en�ch bot byl na n�rtech a na holen�ch dopln�n ocelov�mi pl�ty.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item117.png" width="94px" height="86px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hrani���sk� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kvalitn� p�r erathijsk�ch ko�en�ch bot. Tyto boty vynikaj� v�emi typick�mi znaky erathijsk�ho ko�ed�ln�ho �emesla - jsou m�kk�, nepromokav� a tich�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item118.png" width="77px" height="95px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ryt��sk� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Le�t�n� st��b�it� boty se sametov�m vylo�en�m jsou leh�� a mnohem pohodln�j�� ne� boty z pl�tov� oceli. Tak� vypadaj� p�kn� drs��cky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/item119.png" width="77px" height="100px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Paladinsk� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto st��b�it� a ocelov� boty, kter� byly vyrobeny v d�ln� Byrona Rockermanna, pat�� k nejlep��m na sv�t�. Jsou nejen neuv��iteln� pevn�, ale tak� pohodln� a jaksepat�� pohybliv�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>850</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
