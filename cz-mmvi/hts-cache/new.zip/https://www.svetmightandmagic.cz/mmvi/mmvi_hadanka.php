<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>H�danka z obelisk�</h2>
   <p>&nbsp;</p>
   
   <p>V ka�d� oblasti ve h�e naleznete jeden obelisk. Pokud kliknete na �ern� pult�k, zobraz� se v�m podivn� text, kter� se z�rove� pod p��slu�n�m ��slem zobraz� v informac�ch pod z�lo�kou obelisku. Jedn� se o skryt� �kol ve h�e, k jeho� spln�n� je t�eba nav�t�vit v�ech 15 obelisk�. Pot� si budete moci p�e��st celou zpr�vu - �te se po jednotliv�ch sloupc�ch z leva do prava. Jej� zn�n� je uvedeno dole pod tabulkou s jednotliv�mi zpr�vami.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" width="520px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td rowspan="1" style="width: 80px;">��slo obelisku</td>
         <td rowspan="1" style="width: 120px;">Lokace</td>
         <td rowspan="1" colspan="16">Zpr�va</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Dobr� voda</td>
         <td style="width: 20px;">N</td>
         <td style="width: 20px;">�</td>
         <td style="width: 20px;">e</td>
         <td style="width: 20px;">�</td>
         <td style="width: 20px;">,</td>
         <td style="width: 20px;"></td>
         <td style="width: 20px;">.</td>
         <td style="width: 20px;">n</td>
         <td style="width: 20px;"></td>
         <td style="width: 20px;">u</td>
         <td style="width: 20px;">y</td>
         <td style="width: 20px;">n</td>
         <td style="width: 20px;">t</td>
         <td style="width: 20px;">u</td>
         <td style="width: 20px;">u</td>
         <td style="width: 20px;">�</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Rajsk� �dol�</td>
         <td>a</td>
         <td>�</td>
         <td>m</td>
         <td>k</td>
         <td></td>
         <td>s</td>
         <td></td>
         <td>a</td>
         <td>s</td>
         <td>n</td>
         <td>.</td>
         <td></td>
         <td>u</td>
         <td></td>
         <td></td>
         <td>d</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Poustevn�k�v ostrov</td>
         <td></td>
         <td>m</td>
         <td>i</td>
         <td>r</td>
         <td>k</td>
         <td>v</td>
         <td>N</td>
         <td>p</td>
         <td>k</td>
         <td>e</td>
         <td></td>
         <td>a</td>
         <td>h</td>
         <td>r</td>
         <td>o</td>
         <td>a</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Kriegspire</td>
         <td>n</td>
         <td></td>
         <td></td>
         <td>y</td>
         <td>t</td>
         <td>�</td>
         <td>e</td>
         <td>o</td>
         <td>r</td>
         <td>�</td>
         <td>Z</td>
         <td></td>
         <td>l</td>
         <td>o</td>
         <td>b</td>
         <td>n</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Blackshire</td>
         <td>e</td>
         <td>s</td>
         <td>d</td>
         <td>t</td>
         <td>e</td>
         <td>j</td>
         <td>�</td>
         <td>s</td>
         <td>y</td>
         <td>n</td>
         <td>d</td>
         <td>v</td>
         <td>e</td>
         <td>z</td>
         <td>e</td>
         <td>k</td>
      </tr>
      <tr>
         <td>6</td>
         <td>Dra�� p�sky</td>
         <td>j</td>
         <td>e</td>
         <td>r</td>
         <td></td>
         <td>r</td>
         <td></td>
         <td></td>
         <td>l</td>
         <td>t</td>
         <td>i</td>
         <td>v</td>
         <td>y</td>
         <td></td>
         <td>k</td>
         <td>l</td>
         <td>u</td>
      </tr>
      <tr>
         <td>7</td>
         <td>Mraziv� vrchovina</td>
         <td>v</td>
         <td>v</td>
         <td>a</td>
         <td>k</td>
         <td>�</td>
         <td>v</td>
         <td>v</td>
         <td>e</td>
         <td>a</td>
         <td>m</td>
         <td>i</td>
         <td>�</td>
         <td>z</td>
         <td>o</td>
         <td>i</td>
         <td>.</td>
      </tr>
      <tr>
         <td>8</td>
         <td>Svobodn� p��stav</td>
         <td>z</td>
         <td>e</td>
         <td>k</td>
         <td>a</td>
         <td></td>
         <td>�</td>
         <td>y</td>
         <td>d</td>
         <td></td>
         <td>i</td>
         <td>h</td>
         <td>e</td>
         <td>a</td>
         <td>u</td>
         <td>s</td>
         <td></td>
      </tr>
      <tr>
         <td>9</td>
         <td>Mo��l proklet�ch</td>
         <td>d</td>
         <td>r</td>
         <td>�</td>
         <td>p</td>
         <td>z</td>
         <td>�</td>
         <td>d</td>
         <td>y</td>
         <td>p</td>
         <td></td>
         <td>n</td>
         <td>�</td>
         <td>p</td>
         <td>s</td>
         <td>k</td>
         <td></td>
      </tr>
      <tr>
         <td>10</td>
         <td>St��brn� z�toka</td>
         <td>�</td>
         <td>u</td>
         <td></td>
         <td>i</td>
         <td>d</td>
         <td>n</td>
         <td>e</td>
         <td>,</td>
         <td>�</td>
         <td>p</td>
         <td>i</td>
         <td>i</td>
         <td>e</td>
         <td>k</td>
         <td>o</td>
         <td></td>
      </tr>
      <tr>
         <td>11</td>
         <td>Z�toka pa�er�k�</td>
         <td>l</td>
         <td>,</td>
         <td>l</td>
         <td>t</td>
         <td>e</td>
         <td>�</td>
         <td>c</td>
         <td></td>
         <td>e</td>
         <td>a</td>
         <td></td>
         <td>l</td>
         <td>k</td>
         <td>o</td>
         <td>v</td>
      </tr>
      <tr>
         <td>12</td>
         <td>Hrad Ironfist</td>
         <td>e</td>
         <td></td>
         <td>e</td>
         <td>�</td>
         <td></td>
         <td></td>
         <td>h</td>
         <td>b</td>
         <td>d</td>
         <td>p</td>
         <td>k</td>
         <td></td>
         <td>l</td>
         <td>v</td>
         <td>o</td>
         <td></td>
      </tr>
      <tr>
         <td>13</td>
         <td>�ho�� vody</td>
         <td>n</td>
         <td>v</td>
         <td>�</td>
         <td>n</td>
         <td>s</td>
         <td>s</td>
         <td>l</td>
         <td>y</td>
         <td></td>
         <td>r</td>
         <td>�</td>
         <td>j</td>
         <td>i</td>
         <td>a</td>
         <td>u</td>
         <td></td>
      </tr>
      <tr>
         <td>14</td>
         <td>Ml�n� ostrovy</td>
         <td>�</td>
         <td></td>
         <td>�</td>
         <td>k</td>
         <td>n</td>
         <td>e</td>
         <td>a</td>
         <td>l</td>
         <td>s</td>
         <td>s</td>
         <td>m</td>
         <td>s</td>
         <td>t</td>
         <td>n</td>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td>15</td>
         <td>Nov� Sorpigal</td>
         <td>j</td>
         <td>z</td>
         <td></td>
         <td>y</td>
         <td>�</td>
         <td>n</td>
         <td></td>
         <td>a</td>
         <td>l</td>
         <td>k</td>
         <td>e</td>
         <td>i</td>
         <td>o</td>
         <td>o</td>
         <td>h</td>
         <td></td>
      </tr>
   </table>
   </div>
   
   <p>Na nejvzd�len�j��m severu, v zemi drak�, le�� �kryt kapit�nky, kter� zde sn� sv�j v��n� sen. Ne� vydechla naposledy, byla skryta p�ed slune�n�mi paprsky. Zdvihni k�men a vy�e�il jsi tuhle zapeklitou rozkouskovanou obeliskovou h�danku.</p>
   <p>Jakmile m�te tedy �kol spln�n, vydejte se do Dra��ch p�sk� a v severn� �asti naleznete kruh z kamen�. Pod velk�m balvanem se skr�v� truhla s artefakty a knihami kouzel Bo�sk� z�sah a Temn� tajemstv�. Po otev�en� nav�c z�sk�te 250 000 zl. Vyp�d� to, �e slo�en� artefakt� je st�le stejn� a naleznete zde Morgan, Igraine a Guinevere. V p��pad� obou kouzel je to jedin� p��le�itost jak se je nau�it, v ��dn� gild� je toti� nelze koupit (pova�uj� se za ztracen�).</p>
   <p><span class="tucne">Edit podzim 2012:</span> Kane v Knize n�v�t�v up�esnil, �e ob� "ztracen�" knihy ob�as vypadnou i jako poklad z drak� a tit�n�. O p�r t�dn� pozd�ji jsem objevil je�t� jeden zdroj, v Dra��ch p�sc�ch lze na Bo�sk� z�sah n�hodn� narazit p�i v�m�n� zlat�ch pyramidek za o�arovan� p�edm�t. Pravd�podobn� se tak d� z�skat i Temn� tajemstv�.</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
