<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Rozm�st�n� gild v Enrothu</h2>
   <p>&nbsp;</p>
   
   <p>Gildy jsou v�ukov� centra, kde se va�e postavy mohou nau�it jednotliv�m dovednostem. V z�kladu jsou v �est�m d�le rozd�leny na pa�er�ck�, �old�ck� a magick� gildy. Pa�er�ck� gildy se soust�e�uj� na v�uku ochrann�ch dovednost�, �old�ck� gildy na v�uku bojov�ch dovednost� a magick� gildy na v�uku magie, meditace a vzd�l�v�n�. Aby postavy mohly jejich slu�eb vyu��vat, mus� b�t nejprve �leny p��slu�n� gildy. �lenstv� je placen� a pokladn�ka naleznete v�dy v tom sam�m m�st�, kde stoj� i gilda (vyjma B�l� a �ern� magie, viz dodatek na konci kapitoly) - poplatky sta�� zaplatit jen jednou, plat� pot� i v dal��ch m�stech. Ka�d� ze skupin sdru�uje n�kolik samostatn�ch gild, jak je uvedeno v n�sleduj�c�ch tabulk�ch.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="600px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td colspan="4">Pa�er�ck� gildy</td>
      </tr>
      <tr>
         <td style="width: 150px;">N�zev</td>
         <td style="width: 150px;">Um�st�n�</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: 250px;">Vyu�uje</td>
      </tr>
      <tr>
         <td rowspan="2">Doup� bukan�r�</td>
         <td>Nov� Sorpigal</td>
         <td>150 zl.</td>
         <td>d�ka, obchodn�k, pozn�v�n� v�c�, bystrost, pasti</td>
      </tr>
      <tr>
         <td>Mist</td>
         <td>200 zl.</td>
         <td>ko�en� zbroj, diplomacie, pozn�v�n� v�c�, bystrost, pasti</td>
      </tr>
      <tr>
         <td rowspan="2">Ochrann� slu�by</td>
         <td>St��brn� z�toka</td>
         <td>300 zl.</td>
         <td>ko�en� zbroj, diplomacie, pozn�v�n� v�c�, bystrost, pasti</td>
      </tr>
      <tr>
         <td>Mraziv� vrchovina (u hradu Stone)</td>
         <td>250  zl.</td>
         <td>d�ka, obchodn�k, pozn�v�n� v�c�, bystrost, pasti</td>
      </tr>
      <tr>
         <td rowspan="2">Pa�er�ck� gilda</td>
         <td>Blackshire</td>
         <td>250 zl.</td>
         <td>ko�en� zbroj, diplomacie, pozn�v�n� v�c�, bystrost, pasti</td>
      </tr>
      <tr>
         <td>-</td>
         <td>-</td>
         <td>podle v�eho by se dal�� gilda m�la nach�zet ve Svobodn�m p��stavu, ale neni zde po n� ��dn� stopy</td>
      </tr>
   </table>
   </div>
   
   <p>Pozn�mka: otev�rac� doba v pa�er�ck�ch gild�ch je od 6 hodin odpoledne do 6 hodin r�no.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="600px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td colspan="4">�old�ck� gildy</td>
      </tr>
      <tr>
         <td style="width: 150px;">N�zev</td>
         <td style="width: 150px;">Um�st�n�</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: 250px;">Vyu�uje</td>
      </tr>
      <tr>
         <td rowspan="2">Zlomen� �avle</td>
         <td>Nov� Sorpigal</td>
         <td>375 zl.</td>
         <td>me�, sekyra, kop�, h�l, ko�en� zbroj</td>
      </tr>
      <tr>
         <td>B�l� �apka</td>
         <td>750 zl.</td>
         <td>me�, sekyra, kop�, h�l, opravov�n�</td>
      </tr>
      <tr>
         <td rowspan="2">Zu�iv� berserk�i</td>
         <td>Hrad Ironfist</td>
         <td>500 zl.</td>
         <td>krou�kov� zbroj, luk, �t�t, pl�tov� zbroj, opravov�n�</td>
      </tr>
      <tr>
         <td>St��brn� z�toka</td>
         <td>625 zl.</td>
         <td>krou�kov� zbroj, luk, �t�t, pl�tov� zbroj, opravov�n�</td>
      </tr>
      <tr>
         <td rowspan="2">Dvojit� ost��</td>
         <td>Mist</td>
         <td>500 zl.</td>
         <td>palc�t, luk, krou�kov� zbroj, �t�t, posilov�n�</td>
      </tr>
      <tr>
         <td>Svobodn� p��stav</td>
         <td>625 zl.</td>
         <td>palc�t, luk, krou�kov� zbroj, �t�t, posilov�n�</td>
      </tr>
   </table>
   </div>
   
   <p>Pozn�mka: otev�rac� doba v �old�ck�ch gild�ch je od 9 hodin dopoledne do 9 hodin odpoledne.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="2px" width="600px" style="margin: auto;" border="0">
      <tr class="hlavicka_tabulky">
         <td colspan="4">Magick� gildy</td>
      </tr>
      <tr>
         <td style="width: 200px;">N�zev</td>
         <td style="width: 150px;">Um�st�n�</td>
         <td style="width: 50px;">Cena za dovednost</td>
         <td style="width: 250px;">Vyu�uje</td>
      </tr>
      <tr>
         <td>Novick� gilda �ivl�</td>
         <td>Nov� Sorpigal</td>
         <td>750 zl.</td>
         <td>magie vody, vzduchu, ohn� a zem� (kouzla norm�ln� �rovn�)</td>
      </tr>
      <tr>
         <td>Novick� gilda sebepozn�n�</td>
         <td>Nov� Sorpigal</td>
         <td>750 zl.</td>
         <td>magie mysli, ducha a t�la (kouzla norm�ln� �rovn�)</td>
      </tr>
      <tr>
         <td>Novick� gilda mysli</td>
         <td>Hrad Ironfist</td>
         <td>1000 zl.</td>
         <td>magie mysli, meditace</td>
      </tr>
      <tr>
         <td>Novick� gilda ducha</td>
         <td>Hrad Ironfist</td>
         <td>1000 zl.</td>
         <td>magie ducha, meditace</td>
      </tr>
      <tr>
         <td>Novick� gilda t�la</td>
         <td>Hrad Ironfist</td>
         <td>1000 zl.</td>
         <td>magie t�la, meditace</td>
      </tr>
      <tr>
         <td>Novick� gilda vody</td>
         <td>Mist</td>
         <td>1000 zl.</td>
         <td>magie vody, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Novick� gilda vzduchu</td>
         <td>Mist</td>
         <td>1000 zl.</td>
         <td>magie vzduchu, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Novick� gilda ohn�</td>
         <td>Mist</td>
         <td>1000 zl.</td>
         <td>magie ohn�, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Novick� gilda zem�</td>
         <td>St��brn� z�toka</td>
         <td>1000 zl.</td>
         <td>magie zem�, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Novick� gilda B�l� magie</td>
         <td>St��brn� z�toka</td>
         <td>1500 zl.</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Novick� gilda �ern� magie</td>
         <td>B�l� �apka</td>
         <td>1500 zl.</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda �ivl�</td>
         <td>B�l� �apka</td>
         <td>1250 zl.</td>
         <td>magie vody, vzduchu, ohn� a zem� (max. kouzla expertn� �rovn�)</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda sebepozn�n�</td>
         <td>St��brn� z�toka</td>
         <td>1250 zl.</td>
         <td>magie mysli, ducha a t�la (max. kouzla expertn� �rovn�)</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda mysli</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie mysli, meditace</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda ducha</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie ducha, meditace</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda t�la</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie t�la, meditace</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda vody</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie vody, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda vzduchu</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie vzduchu, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda ohn�</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie ohn�, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda zem�</td>
         <td>Svobodn� p��stav</td>
         <td>1500 zl.</td>
         <td>magie zem�, vzd�l�v�n�</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda B�l� magie</td>
         <td>Blackshire</td>
         <td>2000 zl.</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Pokro�il� gilda �ern� magie</td>
         <td>Blackshire</td>
         <td>2000 zl.</td>
         <td>�ern� magie</td>
      </tr>
   </table>
   </div>
   
   <p>Ve h�e naleznete magick� gildy pro jednotliv� �koly magie i gildy, kter� slu�uj� spole�n� magick� obory. Pat�� sem gilda �ivl� (kouzelnick� �kola) a gilda sebepozn�n� (klerick� �kola). Ka�d� z magick�ch gild existuje ve dvou �rovn�ch. Novick� gildy nab�zej� kouzla norm�ln� �rovn� a pokro�il� gildy pak kouzla v�ech �rovn�. Vyj�mkou jsou gildy �ivl� a sebepozn�n�, kde si m��eme koupit kouzla max. expertn� �rovn�. U gild B�l� a �ern� magie je je�t� jedna zvl�tnost spo��vaj�c� v otev�rac� dob�. Gilda B�l� magie m� otev�eno od 10 hodin dopoledne do 2 hodin odpoledne, gilda �ern� magie pak od 10 hodin odpoledne do 2 hodin dopoledne. Ostatn� magick� gildy otev�raj� v 6 hodin dopoledne a zav�raj� v 6 hodin odpoledne.</p>
   
   <p><span class="tucne">Edit jaro 2012:</span> Celkem �asto dost�v�m dotazy, jak se lze vlastn� dovednost B�l� a �ern� magie nau�it. Odpov�� je v�dy stejn�, je to opravdu jako u ostatn�ch gild. Nejprve se dru�ina mus� st�t �lenem p��slu�n� gildy a a� pot� v n� m��e studovat danou dovednost a nakupovat kouzla. Pot�� je jen v tom, �e cechovn� (gildovn�) poplatky se daj� zaplatit jen na dvou m�stech - pro B�lou magii je to Blackshire, pro �ernou magii je to B�l� �apka. Preventivn� je�t� dod�m, �e tyto dv� dovednosti se m��e nau�it jen klerik nebo m�g.</p>
   
   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
