<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Spot�eba j�dla p�i odpo�inku</h2>
   <p>&nbsp;</p>
   
   <p>Ka�d� postava ve h�e pot�ebuje v pravideln�ch intervalech odpo��vat (min. 1x za 24 hodin). Krom p�irozen� �navy se postavy mohou unavit/oslabit vlivem magick�ch efekt� monster nebo pominut�m ��inku kouzla Zrychlen�. K regeneraci je pot�eba minim�ln� 8 hodin nep�eru�ovan�ho odpo�inku, p�i kter�m se z�rove� spot�ebov�vaj� d�vky j�dla. O mno�stv� takto spot�ebovan�ch d�vek rozhoduje povaha ter�nu, ve kter�m postavy odpo��vaj� (viz n�sleduj�c� tabulka).</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" width="300px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">Druh ter�nu</td>
         <td style="width: 150px;">D�vek j�dla</td>
      </tr>
      <tr>
         <td>Tr�va</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Hl�na</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Cesta</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Interi�r</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Sn�h</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Ba�ina</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Pl��</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Pou��</td>
         <td>5</td>
      </tr>
   </table>
   </div>
   
   <p>Pokud dru�ina nem� j�dla dostatek, postavy se nebudou moci zregenerovat. Do�asn�ho odstran�n� �navy lze dos�hnout i l��en�m v chr�mech nebo kouzlem Odstra� slabost, ale to v�s nutnosti odpo�inku nijak nezbav�. Pokud toti� budete �navu jen l��it, �asem postavy n�hodn� propadnou r�zn�m form�m zoufalstv� (�ast� je ��lenstv�) nebo jednodu�e um�ou. Odpo�inek nav�c slou�� k dopln�n� mno�stv� zdrav� a many.</p>
   <p>D�vky j�dla se spot�ebov�vaj� i b�hem pe��ho cestov�n� mezi oblastmi. Pokud dru�ina nebude m�t dostatek j�dla na cestu, postavy se v nov� oblasti objev� unaven�. M�jte to na pam�ti, proto�e unaven� postavy maj� negativn� bonus k �toku, co� v�m m��e p�ipravit mnoh� nemil� p�ekvapen�.</p>


   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
