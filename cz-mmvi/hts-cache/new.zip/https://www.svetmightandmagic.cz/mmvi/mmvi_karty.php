<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h1>Bal��ky osudu</h1>
   <p>&nbsp;</p>
   
   <p>Bal��ky osudu jsou bal��ky karet, kter� p�i pou�it� postav� trvale zv��� ur�itou vlastnost. M��eme je nal�zt na r�zn�ch m�stech Enrothu, ale nej�ast�ji je objev�me v dungeonech s nemrtv�mi (nap�. hrad Darkmoor). Pokud u� jste hr�li sedm� d�l, tak jsou sv�m ��inkem velmi podobn� d�inov�m lamp�m. Krom bonusu v�ak m��eme p�i pou�it� bal��ku tak� "vylosovat" i jeden z n�sleduj�c�ch negativn�ch stav� - zkamen�n�, smrt nebo vym�cen�. Na�t�st� je to v�z�no na konkr�tn� dny v m�s�ci, tak�e se lze pou�it� bal��k� v t�chto dnech �sp�n� vyhnout (viz n�sleduj�c� tabulka).</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="300px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">Den</td>
         <td style="width: 150px;">Negativn� efekt</td>
      </tr>
      <tr>
         <td>5</td>
         <td>zkamen�n�</td>
      </tr>
      <tr>
         <td>7</td>
         <td>vym�cen�</td>
      </tr>
      <tr>
         <td>13</td>
         <td>smrt</td>
      </tr>
      <tr>
         <td>21</td>
         <td>vym�cen�</td>
      </tr>
      <tr>
         <td>26</td>
         <td>zkamen�n�</td>
      </tr>
      <tr>
         <td>27</td>
         <td>smrt</td>
      </tr>
   </table>
   </div>
   
   <p>Podobn� jako jsou na konkr�tn�m dnu z�visl� negativn� stavy, tak je tomu i v p��pad� bonus�. To, jak� bonus si vylosujeme, je z�visl� na konkr�tn�m m�s�c� a nav�c s�la bonusu pak je�t� z�vis� na t�dnu v m�s�ci. Nejsiln�j�� bonus postava z�sk� b�hem �tvrt�ho t�dne. Rozpis poskytovan�ch bonus� a hodnota bonusu je sou��st� n�sleduj�c� tabulky.</p>

   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0px" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 70px;">M�s�c</td>
         <td style="width: 70px;">T�den</td>
         <td style="width: 160px;">Bonus</td>
         <td style="width: 70px;">M�s�c</td>
         <td style="width: 70px;">T�den</td>
         <td style="width: 160px;">Bonus</td>
      </tr>
      <tr>
         <td rowspan="4">Leden</td>
         <td>1</td>
         <td>+1 S�la trvale</td>
         <td rowspan="4">�ervenec</td>
         <td>1</td>
         <td>+1 �t�st� trvale</td>
      </tr>
      <tr>
         <td>2</td>
         <td>+2 S�la trvale</td>
         <td>2</td>
         <td>+2 �t�st� trvale</td>
      </tr>
      <tr>
         <td>3</td>
         <td>+3 S�la trvale</td>
         <td>3</td>
         <td>+3 �t�st� trvale</td>
      </tr>
      <tr>
         <td>4</td>
         <td>+4 S�la trvale</td>
         <td>4</td>
         <td>+4 �t�st� trvale</td>
      </tr>
      <tr>
         <td rowspan="4">�nor</td>
         <td>1</td>
         <td>+1 Intelekt trvale</td>
         <td rowspan="4">Srpen</td>
         <td>1</td>
         <td>+1 odolnost proti ohni</td>
      </tr>
      <tr>
         <td>2</td>
         <td>+2 Intelekt trvale</td>
         <td>2</td>
         <td>+2 odolnost proti ohni</td>
      </tr>
      <tr>
         <td>3</td>
         <td>+3 Intelekt trvale</td>
         <td>3</td>
         <td>+3 odolnost proti ohni</td>
      </tr>
      <tr>
         <td>4</td>
         <td>+4 Intelekt trvale</td>
         <td>4</td>
         <td>+4 odolnost proti ohni</td>
      </tr>
      <tr>
         <td rowspan="4">B�ezen</td>
         <td>1</td>
         <td>+1 Osobnost trvale</td>
         <td rowspan="4">Z���</td>
         <td>1</td>
         <td>+1 odolnost proti chladu</td>
      </tr>
      <tr>
         <td>2</td>
         <td>+2 Osobnost trvale</td>
         <td>2</td>
         <td>+2 odolnost proti chladu</td>
      </tr>
      <tr>
         <td>3</td>
         <td>+3 Osobnost trvale</td>
         <td>3</td>
         <td>+3 odolnost proti chladu</td>
      </tr>
      <tr>
         <td>4</td>
         <td>+4 Osobnost trvale</td>
         <td>4</td>
         <td>+4 odolnost proti chladu</td>
      </tr>
      <tr>
         <td rowspan="4">Duben</td>
         <td>1</td>
         <td>+1 Odolnost trvale</td>
         <td rowspan="4">��jen</td>
         <td>1</td>
         <td>+1 odolnost proti elekt�in�</td>
      </tr>
      <tr>
         <td>2</td>
         <td>+2 Odolnost trvale</td>
         <td>2</td>
         <td>+2 odolnost proti elekt�in�</td>
      </tr>
      <tr>
         <td>3</td>
         <td>+3 Odolnost trvale</td>
         <td>3</td>
         <td>+3 odolnost proti elekt�in�</td>
      </tr>
      <tr>
         <td>4</td>
         <td>+4 Odolnost trvale</td>
         <td>4</td>
         <td>+4 odolnost proti elekt�in�</td>
      </tr>
      <tr>
         <td rowspan="4">Kv�ten</td>
         <td>1</td>
         <td>+1 P�esnost trvale</td>
         <td rowspan="4">Listopad</td>
         <td>1</td>
         <td>+1 odolnost proti jedu</td>
      </tr>
      <tr>
         <td>2</td>
         <td>+2 P�esnost trvale</td>
         <td>2</td>
         <td>+2 odolnost proti jedu</td>
      </tr>
      <tr>
         <td>3</td>
         <td>+3 P�esnost trvale</td>
         <td>3</td>
         <td>+3 odolnost proti jedu</td>
      </tr>
      <tr>
         <td>4</td>
         <td>+4 P�esnost trvale</td>
         <td>4</td>
         <td>+4 odolnost proti jedu</td>
      </tr>
      <tr>
         <td rowspan="4">�erven</td>
         <td>1</td>
         <td>+1 Rychlost trvale</td>
         <td rowspan="4">Prosinec</td>
         <td>1</td>
         <td>+1 odolnost proti magii</td>
      </tr>
      <tr>
         <td>2</td>
         <td>+2 Rychlost trvale</td>
         <td>2</td>
         <td>+2 odolnost proti magii</td>
      </tr>
      <tr>
         <td>3</td>
         <td>+3 Rychlost trvale</td>
         <td>3</td>
         <td>+3 odolnost proti magii</td>
      </tr>
      <tr>
         <td>4</td>
         <td>+4 Rychlost trvale</td>
         <td>4</td>
         <td>+4 odolnost proti magii</td>
      </tr>
   </table>
   </div>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
