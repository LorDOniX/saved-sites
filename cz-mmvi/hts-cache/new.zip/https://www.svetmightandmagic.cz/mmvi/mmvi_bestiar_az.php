<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Abecedn� seznam monster</h2>
   <p>&nbsp;</p>
   <p>N�sleduj�c� seznam je abecedn�m seznamem monster, kter� se v Enrothu nach�zej�. Jsou v n�m vynech�ny postavy neutr�ln�ch  obyvatel m�st, oblast� a dungeon� (r�zn� d�ln�ci apod.). Ka�d� postava/nestv�ra je sou��st� ur�it� skupiny postav/monster, kter� jsou mimo jin� rozeps�ny na �vodn� str�nce <a href="mmvi_bestiar.php">besti��e</a> (zde najdete i vysv�tlivky k popisu). Odkaz u vybran� polo�ky v�s automaticky p�enese na str�nku dan� skupiny, tak�e krom vybran� nestv�ry uvid�te i charakteristiky zbyl�ch dvou nestv�r ze skupiny, pokud tedy existuj�.</p>
   <p>&nbsp;</p>
   
   <ul>
      <li><a href="mmvi_bzobrazeni.php?id=1">Agarova ohavnost</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=1">Agarova stv�ra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=1">Agar�v mazl��ek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=2">Baa�v akolyta</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=2">Baa�v klerik</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=2">Baa�v kn�z</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=4">Bandita</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=22">Bleskov� je�t�rka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=52">Bojovn�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=05">�arod�j</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=35">�arod�jnice</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=05">�ernokn�n�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=08">�erven� drak</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=14">D�mon prachu</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=06">D�mon� d�ln�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=06">D�mon� pot�r</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=06">D�mon� voj�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=30">D�siv� oko</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=16">Diamantov� gargoyla</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=40">Dozorce VARNu</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=10">Druid</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=43">Duch</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=12">Duch ohn�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=13">Duch vody</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=15">Duch zem�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=28">Duchosrk</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=11">D�in</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=11">Efr�t</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=09">Elektrick� dr��ek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=14">Element�l vzduchu</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=48">Expert �erm��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=03">Fanatik Baa</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=17">Goblin</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=17">Goblin� �aman</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=35">Gorgona</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=18">Harpyje</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=18">Harpyj� �arod�jnice</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=18">Harpyj� ochechule</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=40">Hl�dka VARNu</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=44">Hl�dkov� jednotka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=22">Hromov� je�t�rka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=19">Hun</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=19">Hunsk� matrona</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=19">Hunsk� voj�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=20">Hydra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=20">Jedovat� hydra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=21">Je�t�r�ck� kouzeln�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=21">Je�t�r�ck� lu�i�tn�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=21">Je�t�r�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=23">Kabibal</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=24">Kabibalka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=15">Kamenn� bestie</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=16">Kamenn� gargoyla</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=47">Kapit�n</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=07">Kapit�n d�mon�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=25">Kaps��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=26">Kobra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=27">Kost�n� ryt��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=27">Kostlivec</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=07">Kr�l d�mon�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=17">Kr�l goblin�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=36">Kr�l minotaur�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=54">Kr�lovna d�mon�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=26">Kr�lovna kober</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=26">Kr�lovsk� kobra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=28">Krvohlt</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=29">Krysa</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=46">Kyselinn� sliz</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=09">Ledov� dr��ek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=30">L�taj�c� oko</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=31">Lich</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=04">Lotr (bandita)</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=33">Lotr (lupi�)</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=23">Lovec lebek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=24">Lovkyn� lebek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=25">Lovec lid�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=32">Lu�i�tnice</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=33">Lupi�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=34">M�g</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=34">M�g tovary�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=34">M�g za��te�n�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=11">Mal� d�in</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=35">Med�za</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=36">Minotaur</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=36">Minotau�� m�g</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=48">Mistr �erm��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=32">Mistrovsk� lu�i�tnice</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=37">Mnich mistr</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=37">Mnich nov��ek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=37">Mnich zasv�cenec</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=08">Modr� drak</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=38">Mo�sk� monstrum</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=38">Mo�sk� had</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=28">Mozko�kr�b</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=16">Mramorov� gargoyla</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=03">Mystik Baa</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=41">N��eln�k ogr�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=03">N�sledovn�k Baa</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=10">Nejvy��� druid</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=49">Nep�emo�iteln� tit�n</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=39">Netop�r</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=45">Ni�itel</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=40">Obr�nce VARNu</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=20">Obrovsk� hydra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=42">Obrovsk� pavouk</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=29">Ob�� krysa</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=39">Ob�� netop�r</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=42">Ob�� pavouk</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=41">Ogr</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=41">Og�� n�jezdn�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=12">Ohniv� bestie</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=22">Ohniv� je�t�rka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=32">Ohniv� u�i�tnice</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=09">Ohniv� dr��ek</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=12">Ohniv� element�l</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=53">Ohromn� wyrm</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=07">P�n d�mon�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=26">P�n kostlivc�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=50">P�n trpasl�k�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=42">Pavouk</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=47">Poru��k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=44">Po��dkov� jednotka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=38">Postrach mo��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=29">P�erostl� krysa</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=54">Q</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=54">Reaktor</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=04">Rv��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=45">Ryt�� smrtit</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=45">Ryt�� zk�zy</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=46">Sliz</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=43">Spektra</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=47">Str�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=23">�aman</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=24">�amanka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=48">�erm��</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=30">��len� oko</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=05">Temn� m�g</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=44">Termina�n� jednotka</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=49">Tit�n</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=14">Torn�do</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=50">Trpasli�� bojovn�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=50">Trpasl�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=49">Urozen� tit�n</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=39">Vamp�r</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=10">Veledruid</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=31">Velelich</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=51">Velk� vlkodlak</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=53">Velk� wyrm</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=52">Veter�n</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=51">Vl�� mu�</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=51">Vlkodlak</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=13">Vodn� bestie</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=13">Vodn� element�l</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=52">Voj�k</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=25">Vrah</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=31">Vy��� lich</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=53">Wyrm</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=15">Zemn� element�l</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=08">Zlat� drak</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=33">Zlod�j</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=43">Zl� p��zrak</a></li>
      <li><a href="mmvi_bzobrazeni.php?id=46">��rav� sliz</a></li>
   </ul>

   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
