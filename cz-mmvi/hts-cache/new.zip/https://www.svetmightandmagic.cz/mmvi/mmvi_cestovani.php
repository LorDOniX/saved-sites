<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Cestov�n� po Enrothu</h2>
   <p>&nbsp;</p>
   <p>Enroth pat�� mezi velmi rozs�hl� kontinenty a nach�z� se na n�m stejnojmenn� ���e pod vl�dou rodu Ironfist�. V Enrothu existuj� standardn� 3 typy p�epravy. M��ete se vydat p�ky, lod� nebo vyu��t slu�eb ko�sk�ho povozu (st�j�). Lodn� p��stavy naleznete jen v n�kter�ch p��mo�sk�ch oblastech na v�chodn�m pob�e�� a na ostrovech. V�t�inu �zem� obsluhuje Cech dopravce, tzv. st�je. �ada m�st je v�ak dostupn�ch pouze p�mo. Alternativou k uveden�m zp�sob�m p�epravy je mo�nost vyu��t teleporta�n�ch kouzel. Pomoc� Lloydova maj�ku se m��ete p�epravit prakticky kamkoliv, kde si um�st�te zna�ku. Naproti tomu M�stsk� br�na v�m umo�n� p�epravu jen do oblast� s font�nou m�stk� br�ny, ze kter� se mus�te nejprve nap�t - jsou to Nov� Sorpigal, Mist, Svobodn� p��stav, St��brn� z�toka, B�l� �apka a Blackshire.</p>
   <p>N�sleduj�c� mapka ukazuje rozlo�en� oblast� v Enrothu a z�rove� nazna�uje mo�nosti p��ho cestov�n� po zemi (kliknut�m <span class="odkaz" onclick="nove_okno('mmvi_img01.html', 'mmvi_img01', 1000, 610)">sem</span> zobraz�te prostou mapku bez popisk� v samostatn�m okn�). Narozd�l od pozd�j��ch d�l� s�gy je mapa Enrothu nejv�ce ucelen�, tak�e se pohybujete skute�n� po cel� plo�e kontinetu a mapy �zem� na sebe pln� navazuj�. V tomto ohledu mus�m tak� konstatovat, �e lodn� a st�jov� doprava je zde nejrozs�hlej��.</p>
   <p>Krom standardn�ho p��ho cestov�n� p�es strany map lze v hojn� m��e vyu��vat i cestov�n� p�es rohy map. V principu toti� plat�, �e p�es roh mapy se snadno dostanete do oblasti, kter� s tou p�vodn� uhlop���n� soused� (nap�. p�es SZ roh Mo��lu proklet�ch se dostanete t�mto zp�sobem do Blackshire a obr�cen� i z Blackshire zp�t do Mo��lu proklet�ch). Doba cestov�n� p�itom st�le z�st�v� 5 dn�. Vyj�mku tvo�� jen ty rohy, kter� jsou sou��st� oce�nu, p�es n� logicky takto cestovat nelze. Men�� nev�hodou tohoto cestov�n� je fakt, �e rohy map jsou obvykle dob�e hl�dan� v�emo�n�mi potvorami, tak�e jim obvykle vb�hnete p��mo do r�ny. Jednotliv� mo�nosti cestov�n� pomoc� roh� map zn�zor�uje n�sleduj�c� schema.</p>
   
   <div style="text-align: center;">
      <img src="obrazky/mmvi_rohy.jpg" width="500px" height="300px" /></td>
   </div>
   
   <p>N�sleduj�c� mapka pak ukazuje p�ehled oblast� Enrothu. Pokud by to n�kdo nedo�etl do konce, tak to rad�ji nap��u i p�ed mapkou. V po��tku hry nebudete m�t mo�nost vyu��vat lodn� a st�jovou dopravu naplno. Dopravci v�s budou odm�tat dov�zt do oblasti Svobodn�ho p��stavu a d�le, dokud Svobodn� p��stav nenav�t�v�te nejprve p�mo. V Z�toce pa�er�k� si v�ak budete moci najmout mistra port�l�, kter� ovl�d� kouzlo M�stsk� br�na (1 vyvol�n� denn�), co� m��e v po��tku docela pomoci (p�i tro�e �t�st� na n�j naraz�te i d��ve, souvis� to s n�hodn�m generov�n�m NPC postav).</p>

   <div style="text-align: center;">
   <img src="obrazky/mmvi_velkama.jpg" width="980px" height="590px" usemap="#mapa_slozena" /></td>
   <map name="mapa_slozena">
      <area shape="rect" coords="1,2,194,195" alt="Dobr� voda" href="mmvi_obrazkym.php?obr=oblast15" />
      <area shape="rect" coords="197,2,390,194" alt="Kriegspire" href="mmvi_obrazkym.php?obr=oblast09" />
      <area shape="rect" coords="393,2,585,195" alt="Mraziv� vrchovina" href="mmvi_obrazkym.php?obr=oblast08" />
      <area shape="rect" coords="590,3,780,195" alt="St��brn� z�toka" href="mmvi_obrazkym.php?obr=oblast07" />
      <area shape="rect" coords="785,3,975,193" alt="�ho�� vody" href="mmvi_obrazkym.php?obr=oblast13" />
      <area shape="rect" coords="1,198,195,389" alt="Rajsk� �dol�" href="mmvi_obrazkym.php?obr=oblast14" />
      <area shape="rect" coords="198,199,389,388" alt="Blackshire" href="mmvi_obrazkym.php?obr=oblast10" />
      <area shape="rect" coords="394,199,585,389" alt="Svobodn� p��stav" href="mmvi_obrazkym.php?obr=oblast05" />
      <area shape="rect" coords="590,199,779,389" alt="Z�toka pa�er�k�" href="mmvi_obrazkym.php?obr=oblast04" />
      <area shape="rect" coords="784,199,976,389" alt="Ml�n� ostrovy" href="mmvi_obrazkym.php?obr=oblast03" />
      <area shape="rect" coords="3,394,193,585" alt="Poustevn�k�v ostrov" href="mmvi_obrazkym.php?obr=oblast12" />
      <area shape="rect" coords="198,393,389,584" alt="Dra�� p�sky" href="mmvi_obrazkym.php?obr=oblast11" />
      <area shape="rect" coords="394,395,583,584" alt="Mo��l proklet�ch" href="mmvi_obrazkym.php?obr=oblast06" />
      <area shape="rect" coords="589,395,779,584" alt="Hrad Ironfist" href="mmvi_obrazkym.php?obr=oblast02" />
      <area shape="rect" coords="786,396,975,584" alt="Nov� Sorpigal" href="mmvi_obrazkym.php?obr=oblast01" />
   </map>
   </div>
   <p>&nbsp;</p>
   
   <h4>St�je (��sla v z�vork�ch ud�vaj� d�lku p�epravy ve dnech)</h4>
   <table cellspacing="0" cellpadding="0" border="0" width="830px">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;">Lokace</td>
         <td style="width: 90px;">Pond�l�</td>
         <td style="width: 90px;">�ter�</td>
         <td style="width: 90px;">St�eda</td>
         <td style="width: 90px;">�tvrtek</td>
         <td style="width: 90px;">P�tek</td>
         <td style="width: 90px;">Sobota</td>
         <td style="width: 90px;">Ned�le</td>
      </tr>
      <tr>
         <td>Nov� Sorpigal</td>
         <td>Hrad Ironfist (2)</td>
         <td>-</td>
         <td>Hrad Ironfist (2)</td>
         <td>-</td>
         <td>Hrad Ironfist (2)</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Hrad Ironfist</td>
         <td>Nov� Sorpigal (2)</td>
         <td>Svobodn� p��stav (4)</td>
         <td>Nov� Sorpigal (2)</td>
         <td>-</td>
         <td>Nov� Sorpigal (2)</td>
         <td>Svobodn� p��stav (4)</td>
         <td>Arena (1)</td>
      </tr>
      <tr>
         <td>Svobodn� p��stav (Z�padn� st�je)</td>
         <td>St��brn� z�toka (4)</td>
         <td>Hrad Ironfist (4)</td>
         <td>Mo��l proklet�ch (5)</td>
         <td>St��brn� z�toka (4)</td>
         <td>Hrad Ironfist (4)</td>
         <td>Mo��l proklet�ch (5)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Svobodn� p��stav (V�chodn� st�je)</td>
         <td>Blackshire (3)</td>
         <td>Kriegspire (3)</td>
         <td>B�l� �apka (3)</td>
         <td>Blackshire (3)</td>
         <td>Kriegspire (3)</td>
         <td>B�l� �apka (3)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>B�l� �apka</td>
         <td>Svobodn� p��stav (3)</td>
         <td>-</td>
         <td>-</td>
         <td>Svobodn� p��stav (3)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>St��brn� z�toka</td>
         <td>Svobodn� p��stav (4)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>Svobodn� p��stav (4)</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Blackshire</td>
         <td>-</td>
         <td>Svobodn� p��stav (3)</td>
         <td>-</td>
         <td>-</td>
         <td>Svobodn� p��stav (3)</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Kriegspire</td>
         <td>-</td>
         <td>-</td>
         <td>Svobodn� p��stav (3)</td>
         <td>-</td>
         <td>-</td>
         <td>Svobodn� p��stav (3)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Mo��l proklet�ch</td>
         <td>Svobodn� p��stav (5)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>Svobodn� p��stav (5)</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   
   <p>K voln�mu pohybu st�jovou dopravou je t�eba nejprve p�mo nav�t�vit oblast Svobodn�ho p��stavu.</p>
   
   <p>&nbsp;</p>
   
   <h4>Lodn� doprava (��sla v z�vork�ch ud�vaj� d�lku p�epravy ve dnech)</h4>
   <table cellspacing="0" cellpadding="0" border="0" width="835px">
      <tr class="hlavicka_tabulky">
         <td style="width: 105px;">Lokace</td>
         <td style="width: 90px;">Pond�l�</td>
         <td style="width: 90px;">�ter�</td>
         <td style="width: 90px;">St�eda</td>
         <td style="width: 90px;">�tvrtek</td>
         <td style="width: 90px;">P�tek</td>
         <td style="width: 90px;">Sobota</td>
         <td style="width: 90px;">Ned�le</td>
      </tr>
      <tr>
         <td>Nov� Sorpigal (lo� Odyssea)</td>
         <td>-</td>
         <td>Mist (3)</td>
         <td>-</td>
         <td>Mist (3)</td>
         <td>-</td>
         <td>Mist (3)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Hrad Ironfist (lo� V�nek)</td>
         <td>Mist (2)</td>
         <td>Nov� Sorpigal (2), v�chod Z�toky pa�er�k� (3)</td>
         <td>Mist (2)</td>
         <td>Nov� Sorpigal (2)</td>
         <td>Nov� Sorpigal (2), v�chod Z�toky pa�er�k� (3)</td>
         <td>Nov� Sorpigal (2)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Hrad Ironfist (lo� Kr�lovna Catherine)</td>
         <td>Poustevn�k�v ostrov (21)</td>
         <td>Poustevn�k�v ostrov (21)</td>
         <td>Poustevn�k�v ostrov (21)</td>
         <td>Poustevn�k�v ostrov (21)</td>
         <td>Poustevn�k�v ostrov (21)</td>
         <td>Poustevn�k�v ostrov (21)</td>
         <td>Poustevn�k�v ostrov (21), Vulk�n (14), Vulk�n (2)</td>
      </tr>
      <tr>
         <td>Mist (lo� Dobrodru�stv�)</td>
         <td>Hrad Ironfist (2), St��brn� z�toka (3)</td>
         <td>v�chod Z�toky pa�er�k� (2)</td>
         <td>Hrad Ironfist (2)</td>
         <td>v�chod Z�toky pa�er�k� (2)</td>
         <td>Hrad Ironfist (2)</td>
         <td>v�chod Z�toky pa�er�k� (2)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Svobodn� p��stav (lo� V�troplach)</td>
         <td>Mist (4)</td>
         <td>St��brn� z�toka (3)</td>
         <td>Hrad Ironfist (5)</td>
         <td>Mist (4), St��brn� z�toka (3)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Z�toka pa�er�k� - v�chod (lo� Tsunami)</td>
         <td>z�pad Z�toky pa�er�k� (1)</td>
         <td>-</td>
         <td>z�pad Z�toky pa�er�k� (1)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Z�toka pa�er�k� - z�pad (lo� Valk�ra)</td>
         <td>-</td>
         <td>Hrad Ironfist (4)</td>
         <td>-</td>
         <td>Hrad Ironfist (4)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>St��brn� z�toka (lo� Cerule�nsk� oblaka )</td>
         <td>Mist (3)</td>
         <td>Svobodn� p��stav (3)</td>
         <td>Severn� ostrov (1)</td>
         <td>Mist (3)</td>
         <td>Svobodn� p��stav (3)</td>
         <td>Mist (3)</td>
         <td>-</td>
      </tr>
      <tr>
         <td>St��brn� z�toka (lo� Barracuda)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>Ji�n� ostrov (2)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Severn� ostrov (lo� Kladivoun)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>St��brn� z�toka (1)</td>
      </tr>
      <tr>
         <td>Ji�n� ostrov (lo� Cirrus)</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>Severn� ostrov (1)</td>
         <td>-</td>
      </tr>
   </table>
   
   <script language="javascript" src="new_window.js"></script>
   
   <p>Severn� a Ji�n� ostrov pat�� do oblasti �ho��ch vod. Lo� Kr�lovna Catherine bude v �elezn� p�sti k dispozici a� po spln�n� quest� s ��dem Baa. Omezen� se t�k� i lodn� p�epravy mimo oblasti Nov�ho Sorpigalu v po��tc�ch hry. Dokud se p�ky nedostanete do oblasti Svobodn�ho p��stavu, a pozd�ji i do oblasti St��brn� z�toky, nebudete moci vyu��vat lodn� dopravu do t�chto oblast�. Budete se tedy pohybovat jen v troj�heln�ku Nov� Sorpigal - Mist - Z�toka pa�er�k�. Oblasti Vulk�n se nach�zej� v Nov�m Sorpigalu. Pro lep�� p�ehlednost si kliknut�m <span class="odkaz" onclick="nove_okno('mmvi_tab01.html', 'mmvi_tab01', 1000, 510)">sem</span> m��ete v�echny t�i tabulky zobrazit v samostatn�m okn�.</p>
   
   <h4>P�� p�eprava (doba cestov�n� z jedn� oblasti do sousedn� oblasti)</h4>
   <table cellspacing="0" cellpadding="0" border="0" width="875px">
      <tr class="hlavicka_tabulky">
         <td style="width: 25px;">Lokace</td>
         <td style="width: 65px;">Nov� sorpigal</td>
         <td style="width: 65px;">Hrad Ironfist</td>
         <td style="width: 65px;">Z�toka pa�er�k�</td>
         <td style="width: 65px;">Svobodn� p��stav</td>
         <td style="width: 65px;">St��brn� z�toka</td>
         <td style="width: 65px;">Mraziv� vrchovina</td>
         <td style="width: 65px;">Mo��l proklet�ch</td>
         <td style="width: 65px;">Blackshire</td>
         <td style="width: 65px;">Kriegspire</td>
         <td style="width: 65px;">Dra�� p�sky</td>
         <td style="width: 80px;">Poustevn�k�v ostrov</td>
         <td style="width: 60px;">Rajsk� �dol�</td>
         <td style="width: 60px;">Dobr� voda</td>
      </tr>
      <tr>
         <td>Nov� sorpigal</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Hrad Ironfist</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Z�toka pa�er�k�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Svobodn� p��stav</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>St��brn� z�toka</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Mraziv� vrchovina</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Mo��l proklet�ch</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Blackshire</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Kriegspire</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
      </tr>
      <tr>
         <td>Dra�� p�sky</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Poustevn�k�v ostrov</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
      </tr>
      <tr>
         <td>Rajsk� �dol�</td>
         <td>-</td>
         <td></td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>5 dn�</td>
      </tr>
      <tr>
         <td>Dobr� voda</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
         <td>-</td>
         <td>5 dn�</td>
         <td>-</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
