<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 15px;}
      td {text-align: left; border: none; text-indent: 5px;}
      .popis {text-align: justify;}
      .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Relikvie</h2>
   <p>&nbsp;</p>
   
   <p><span class="tucne">Dodatek zima 2010/2011:</span> N�sleduj�c� seznam relikvi� obsahuje stejn� jako ostatn� p�edm�ty v sekc�ch origin�ln� popisky p��mo ze hry. Ov�em p�ekladatel� se m�sty dopustili men��ch chybek v nejednotnosti n�zvoslov� a tak n�kter� vlastnosti p�edm�t� mohou p�sobit trochu zmaten�. Nam�sto vlastnosti Odolnost je zde pou�it pojem V�dr�, nam�sto Rychlosti je to Hbitost a Odolnosti proti element�m jsou pou�ity ve zkr�cen� form� jako +x bod� k Odolnostem (u artefakt� je tomu zas o trochu jinak). Naproti tomu u efekt� Zlod�jstv� a Kryt se mi nepoda�ilo jejich ��inek objasnit (dovednost Zlod�jstv� neboli Kraden� neni v �est�m d�le nav�c v�bec implementov�na). Vys�v�n� �ivota se pak bude rovnat ��ink�m Up���, kdy jsou p�i �sp�n�m z�sahu p�en�eny body zdrav� na nositele. Ostatn� efekty by pak u� m�ly b�t z popisk� jasn�.</p>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/83.png" width="103px" height="107px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Aegis</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+29</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Legenda ��k�, �e Aegis byl darem od Boh� mu�i, kter� si p��l bojovat se stra�liv�mi med�zami v jejich kr�lovstv�. �t�t je zrcadlov� a zachra�uje u�ivatele p�ed pohledem med�zy. Nese tak� o�arov�n�, kter� pom�h� chr�nit p�ed ��py, ale je velmi t�k� a trochu u�ivatele zpomal�. (Speci�ln� s�ly: Imunn� ke Zkame�uj�c�m efekt�m, Kryt� +20, �t�st� a -20 Rychlost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/122.png" width="34px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Aphrodite</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytou�en� a vyhled�van� hlup�ky po v�ky, tento n�dhern� prsten uhlazuje poko�ku, �ist� hlas a dramaticky zlep�uje fyzickou kr�su nositele, stejn� jako jeho osobnost. Prsten tak� nese proklet� ne�t�st� a nositel obvykle brzy po n�lezu prstenu um�r� p�i n�jak� tragick� nehod�. (Speci�ln� sily: +100 Osobnost a -40 �t�st�)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/75.png" width="135px" height="151px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Apollo</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+46</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato unik�tn� zbroj poskytne sv�mu majiteli �t�st�, pom�haje mu uniknout v�t�in� element�ln�ch �tok�. �erp� nicm�n� svoji energii z t�la nositele, d�laj�ce tak no�en� t�to zbroje riskantn� nab�dkou. (Speci�ln� s�ly: +20 k Odolnostem, +20 �t�st� a -30 Odolnost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/54.png" width="49px" height="139px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ares</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+14</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+14</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mocn� v�le�� palc�t, Ares, ho�� ohn�m ze srdce hory, ze kter� byl vyroben. Ta sam� magie, kter� tento magick� ��r zp�sobuje, prop�j�uje sv�mu nositeli odolnost p�ed ohn�m. (Speci�ln� s�ly: +30 Ohniv� po�kozen�, +25 Odolnost p�ed Ohn�m)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/46.png" width="46px" height="229px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Artemis</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Poct�n silou bou�e, Artemis st��l� magick� elektrick� blesky. U�ivatel luku by m�l b�t opatrn� -- element�ln� magie se �erp� z luku a nad�l� v�ce �kody, kdy� je s n� zasa�en nositel. (Speci�ln� s�ly: +20 elektrick� po�kozen�, -10 k Odolnostem)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/129.png" width="38px" height="42px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Athena</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tak� zn�m jako Vzd�lanc�v prsten, Athena velice ost�� a zlep�uj� intelekt nositele za cenu fyzick� s�ly. P�esto�e efekt na fyzick� t�lo je skoro zmrza�uj�c�, pro v�t�inu �arod�j� je l�kadlem p��li� velk�m, ne� aby odolali. (Speci�ln� s�ly: +100 Intelekt a -40 S�la)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/109.png" width="81px" height="20px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Atlas</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+16</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Legenda ��k�, �e tento plṻ byl vyhozen Bohem, kter�mu se znel�bil. Sv�mu nositeli p�id�v� neporovnatelnou s�lu za cenu velk� ztr�ty rychlosti. (Speci�ln� s�ly: +100 S�la a -40 Rychlost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/27.png" width="48px" height="157px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Cronos</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+14</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+14</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e magick� kuriozita ne� skute�n� u�ite�n� zbra�, Cronos fantasticky zvy�uje nositelovu �ivotn� s�lu a zmen�uje o polovinu jeho �t�st�. (Speci�ln� s�ly: +100 �ivoty a -50 �t�st�)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/05.png" width="40px" height="184px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hades</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+15</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+15</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mocn� zbra�, o kter� se ��k�, �e m�la b�t na p��n� masov�ho vraha dopravena z Podsv�t�. Hades zp�sobuje stra�n� r�ny sv�m �iletkov�m ost��m a neust�le kapaj�c� kyselinou. Nejen stra�n� zbra�, me� poskytuje obratnost mistra zlod�je pro odstra�ov�n� past� a �t�st� 'd�bla p�i �niku, pokud se past spust�. Hades pomalu a ne�prosn� �erp� svoji s�lu ze sv�ho nositele. (Speci�ln� s�ly: +20 Otr�ven� jedem, +20 �t�st�, Zlod�jstv� a Vys�v�n� �ivota)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/134.png" width="35px" height="75px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hera</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">N�kdy zmi�ovan� jako Amulet Hlup�k�, tato kuri�zn� relikvie z �as� p�ed Tichem dramaticky zvy�uje osobn� �ivotnost, magickou energii a �t�st� nositele na ��et Osobnosti. Zat�mco obl�k�te zbroj, tv�� ochabne, o�i se stanou pr�zdn�mi a �ivotn� jiskra vyhasne. (Speci�ln� s�ly: +50 �ivoty, +50 Mana, +50 �t�st� a -50 Osobnost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/08.png" width="41px" height="207px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hercules</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Obrovsk� me� Hercules napl�uje sv�ho nositele silou sta mu��. Pro zachov�n� sv�ho 'velk� a hloup�' n�m�tu me� redukuje intelekt sv�ho nositele. (Speci�ln� s�ly: +50 S�la, +20 V�dr� a -30 Intelekt)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/119.png" width="57px" height="65px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hermes</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+17</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Relikvie z doby p�ed Tichem, tyto boty mus� obsahovat n�jakou skrytou magii, nebo� jsou velice t�k� a p�esto lehk� jakmile se obuj�. P�sob� na nervy a svaly nositele, zvy�uj�ce jeho rychlost a reflexy na nelidskou �rove�, ale z�rove� zp�sobuj�ce nep�esnost. Boty byly vlastn�ny mnoh�mi, jak �ly �asy, v�ichni v�ak zem�eli p�i n�jak� nehod�, se kterou m�la co do �in�n� rychlost ... jako vyb�hnut� do kopce a n�sledn� p�d dol� z �tesu na vrcholku. (Speci�ln� s�ly: +100 Rychlost a -40 P�esnost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/99.png" width="42px" height="27px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Odin</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato koruna je mocn� relikvie, kter� chr�n� proti element�ln�m magick�m �tok�m v�ech druh�, ale m� kaz, �e zna�n� nositele zpomaluje. (Speci�ln� s�ly: +50 k Odolnostem a -40 k Rychlosti)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/41.png" width="61px" height="285px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Poseidon</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+15</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6+15</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbra� je pravd�podobn� inspirov�na Regnansk�m n�mo�nictvem, kter� p�ijalo trojzubec za svoji obl�benou v�le�nou zbra�. Poseidon napl�uje sv�ho nositele d�sivou bojovou zu�ivost�, zvy�uj�ce nositelovu s�lu, odolnost a p�esnost za cenu osobn� bezpe�nosti. Tak stravuj�c� je nositelova touha zni�it sv� nep��tele, �e opom�j� uh�bat ran�m, kter�ch by se jinak mohl vyvarovat. Na druhou stranu, mrtv� nep��tel� se (obvykle) nebr�n�. (Speci�ln� s�ly: +20 S�la, +20 V�dr�, +20 P�esnost, -10 T��da zbroje a -10 Rychlost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/78.png" width="137px" height="204px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zeus</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+64</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbroj snad byla m�n�na pro Bohy. N�kdy no�ena barbarsk�mi n��eln�ky, zbroj zv��� jejich fyzickou �ivotnost a magickou energii, ale za stra�nou cenu. Dokonce i asparagus pak dosahuje lep��ch v�sledk� v testech intelektu. Jeden by si myslel, �e tak p�ekotnou ztr�tu my�lenek mus� n�sledovat rychl� smrt, nicm�n� �t�st�, kter� zbroj p�itahuje, se zd� odvracet katastrofu. �asto se toti� nositel zbroje st�v� tak hloup�m, �e ji zapomene svl�ci. (Speci�ln� s�ly: +50 �ivoty, +50 Mana, +50 �t�st� a -50 Intelekt)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30000</td>
      </tr>
   </table>

   <p>&nbsp;</p>   
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
