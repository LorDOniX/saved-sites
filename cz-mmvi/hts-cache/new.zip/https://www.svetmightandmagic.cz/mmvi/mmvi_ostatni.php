<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; border: none; text-indent: 5px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <a class="zalozka" name="00"></a>
   <h2>�apky, amulety, prsteny, opasky, h�lky</h2>
   
   <ul>
      <li><a href="#01">�apky, klobouky, koruny</a></li>
      <li><a href="#02">Opasky</a></li>
      <li><a href="#03">Prsteny</a></li>
      <li><a href="#04">Amulety</a></li>
      <li><a href="#05">H�lky</a></li>
   </ul>
   
   <h3><a class="zalozka" name="01">�apky, klobouky, koruny</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/94.png" width="60px" height="24px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">L�tkov� klobouk</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Oby�ejn� klobouk.  Materi�l je sm�s� bavlny a vlny, a p�ro je z kachny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/95.png" width="75px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ozdobn� klobouk</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Docela m�dn� a stylov�, tyto klobouky jsou popul�rn� mezi horn�mi t��dami a t�mi sna��c�mi se je napodobovat.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/96.png" width="60px" height="58px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arod�jova �apka</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nesm�jte se --i kdy� vypad� hloup�, skoro sm�n�-- mnoz� �arod�jov� str�v� docela dost �asu o�arov�v�n�m klobouk�, jako je tento, mocnou magi�.  K�nick� tvar a 'o�i' v p�edn� ��sti upout�vaj� pozornost bytost� z astr�ln�ho sv�ta, a tato vlastnost usnad�uje o�arov�n� klobouku.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/97.png" width="46px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Koruna</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Toto je uboze tepan� koruna, druh, kter� mohou vytvo�it goblini nebo n�zkorozpo�tov� herci, aby karikovali kr�lovskou d�stojnost.  Nenab�z� ��dnou skute�nou ochranu, a�koliv m��e n�st n�jak� mal� o�arov�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/98.png" width="45px" height="16px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vznosn� koruna</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Do st�edu t�to k�ehk� st��brn� koruny je vsazen velk�, kazov� saf�r.  Extr�mn� jemn� znaky kladiva nazna�uj�, �e tato koruna byla vyrobena trpasli��ma rukama.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/99.png" width="42px" height="27px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�emocn� koruna</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Koruny tohoto druhu jsou typicky vytvo�eny s pou�it�m magie. Pokud je nalezena n�jak� bez jak�hokoli o�arov�n�, byla pravd�podobn� z n�jak�ho d�vodu zanech�na nedokon�ena. </td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="02">Opasky</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/100.png" width="63px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kus k��e u�en� k tomu, aby v�m dr�el spodky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/101.png" width="69px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�oldn���v opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�irok� ko�en� p�sek s velkou, lacinou p�ezkou druhy, kter� maj� v oblib� bandit� a kupci.  Jak kupci, tak i bandit�, na nich maj�, jako pomoc do bitvy, r�di zakl�nadla nebo men�� kouzla.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/102.png" width="71px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Avantgardn� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyd�lan� dra�� k��e a nale�t�n� bronz jsou k sob� p�ipevn�ny, aby utvo�ili p�sek neobvykl� s�ly a magick� odolnosti.  P�esto�e se s nimi �patn� pracuje, tyto p�sky mohou nab�dnout excelentn� ochranu proti magii, jakmile je do nich �sp�n� vlo�eno o�arov�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>225</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/103.png" width="64px" height="36px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Opasek p�na v�lky</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyrobeno ze st��bra a k��e n�jak� nezn�m� nestv�ry, tento p�sek je okov�n vertik�ln�mi prou�ky zkalen�ho zlata.  P�ezka je jeden velk� op�l zasazen� do platinov� z�kladny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/104.png" width="68px" height="35px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Svrchovan� opasek</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�esto�e m�kk� a poddajn�, materi�l tohoto p�sku je vyroben z extr�mn� jemn�ch vl�ken b�l�ho zlata.  B�l� zlato je spleteno dohromady zp�sobem p��li� p�esn�m na lidsk� ruce, a rub�n zasazen� do p�ezky byl perfektn� u��znut zp�sobem d�vno ztracen�m v �ase.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="03">Prsteny</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/120.png" width="40px" height="24px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hezk� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� zlat� prsten se �vrtkar�tov�m diamantem.  Styl je jednoduch� a elegantn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/121.png" width="38px" height="28px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">T�pytiv� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento jednoduch� platinov� prsten zdob� dva ametysty.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/122.png" width="34px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Lun�rn� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zlat� prsten s velk�m m�s��n�m kamenem usazen�m ve st�edu.  Tyto prsteny v�t�inou nesou n�jak� o�arov�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/123.png" width="42px" height="25px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arod�jn� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Prsteny jako tento byly no�eny �arod�jnou gildou k ozna�en� �lenstv� b�hem jejich rozkv�tu v letech 550-800 P.T.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>700</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/124.png" width="40px" height="33px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Po�ehnan� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Na prstenu v�s na prvn� pohled upoutaj� t�i perly, p�ipevn�n� na zlat� z�klad, kter� se, kdy� je dr��te proti slunci, t�pyt� slabou mod��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>900</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/125.png" width="36px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Cenn� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Velk� hv�zdicov� saf�r lemovan� dv�ma men��mi rub�ny zdob� jinak jednoduch� zlat� p�s.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/126.png" width="38px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vz�cn� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">T�i drahokamy, symetricky stejn� co do velikosti i kvality zdob� kovan� zlat� p�s.  Prost�edn� drahokam je rub�n, a dva lemuj�c� drahokamy jsou purpurov� topazy.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/127.png" width="40px" height="32px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�terick� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kovan� prsten z b�l�ho zlata s velk�m centr�ln�m diamantem a dv�ma mal�mi perlami, sv�tlo na n�j nedopad� norm�ln�.  Prsten se bly�t� a pohas�n� nep�edv�dateln�, jako by byl osv�tlov�n n�jak�m neviditeln�m sluncem sv�t�c�m v neviditeln�m, paraleln�m sv�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/128.png" width="40px" height="30px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">N�dhern� prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">T�i op�ly obrouben� podivn�m rud�m kovem jsou zasazeny do perfektn�ho prstenu ze staltu--velmi vz�cn�ho kovu vyskytuj�c�ho se jen v ji�n� Erathii.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1700</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/129.png" width="38px" height="42px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Skarabe�v prsten</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zlat� obru� zdoben� krovkami vz�cn�ho brouka vyskytuj�c�ho se pouze v pou�t�ch Enrothu.  Spr�vn� zpracovan� n�jak�m alchymistou, tyto krovky mohou b�t upraveny, aby nesly nejmocn�j�� kouzla.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="04">Amulety</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/130.png" width="36px" height="75px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tyrkysov� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyrkysov� k�men podp�ran� bronzov�m �et�zem a sponou tvo�� levn�, p�esto okouzluj�c� amulet.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/131.png" width="35px" height="80px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Gotick� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento podivn� amulet byl pravd�podobn� vytvo�en n�jak�m alchymistou.  Tvar a symetrie pom�haj� udr�et jak�koli kouzlo, kter� do n�j vlo�il.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/132.png" width="34px" height="70px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pa��tov� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Do zkostnat�l� nohy n�jak� nezn�m� �elmy nebo stv�ry byl vsazen velk�, kazov� purpurov� topaz.  Nen� to p�kn�, ale ur�it� to je magick�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/133.png" width="40px" height="72px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Starobyl� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento amulet je slo�en ze dvou ��st�:  v p�edn� ��sti je starobyl�, perfektn� vy�ezan� ze siln�ho, neposkvrn�n�ho kovu.  Rub je mnohem nov�j�� zlat� �et�z a spona.  Pe�liv� prohl�dka p�edn�ho ��sti odhaluje, �e to je plaketa zobrazuj�c� jm�no n�jak�ho dlouho mrtv�ho voj�ka nebo d�ln�ka.  Symboly vp�edu z�ejm� zna�� postaven� a hodnost.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/134.png" width="35px" height="75px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Rub�nov� amulet</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�ist� rub�n vybrou�en� do tvaru hv�zdy a obklopen� zlatou sponou d�vaj� tomuto amuletu jeho jm�no.  Kdy� se na n�j d�v� v �eru, lze ve st�edu drahokamu vid�t planouc� a tan��c� jiskru.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="05">H�lky</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/135.png" width="14px" height="152px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka ohn�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ty�ka z modr�ho kovu a d�eva s modr�m kamenem na vrcholu.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/135.png" width="14px" height="152px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka statick� elekt�iny</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ty�ka z modr�ho kovu a d�eva s modr�m kamenem na vrcholu.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/135.png" width="14px" height="152px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka mrazu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ty�ka z modr�ho kovu a d�eva s modr�m kamenem na vrcholu.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/135.png" width="14px" height="152px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka omra�ov�n�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ty�ka z modr�ho kovu a d�eva s modr�m kamenem na vrcholu.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/135.png" width="14px" height="152px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�lka ��p�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ty�ka z modr�ho kovu a d�eva s modr�m kamenem na vrcholu.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/140.png" width="34px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arovn� h�lka ohn�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e h�l ne� h�lka, tato �arovn� h�lka je nevysv�tliteln� st�le �iv�, i kdy� byla ze stromu od��znuta p�ed mnoha lety.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/140.png" width="34px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arovn� h�lka jisker</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e h�l ne� h�lka, tato �arovn� h�lka je nevysv�tliteln� st�le �iv�, i kdy� byla ze stromu od��znuta p�ed mnoha lety.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/140.png" width="34px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arovn� h�lka jedu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e h�l ne� h�lka, tato �arovn� h�lka je nevysv�tliteln� st�le �iv�, i kdy� byla ze stromu od��znuta p�ed mnoha lety.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/140.png" width="34px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arovn� h�lka Mysli</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e h�l ne� h�lka, tato �arovn� h�lka je nevysv�tliteln� st�le �iv�, i kdy� byla ze stromu od��znuta p�ed mnoha lety.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/140.png" width="34px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arovn� h�lka zra�ov�n�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e h�l ne� h�lka, tato �arovn� h�lka je nevysv�tliteln� st�le �iv�, i kdy� byla ze stromu od��znuta p�ed mnoha lety.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/145.png" width="10px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornov� h�lka Ohniv�ch koul�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z vydlaban�ho rohu jednoro�ce a nabodnut� na kus uhlazen�ho d�eva, h�lky jako tato jsou zrozeny z krutosti a zla.  Kouzlo, kter� obsahuje, je u�ite�n�;  jedin� ot�zka je, zda v����, �e tvoje v�c ospravedl�uje pou�it� p�edm�tu tak hanebn� vytvo�en�ho.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/145.png" width="10px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornov� h�lka Ledu</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z vydlaban�ho rohu jednoro�ce a nabodnut� na kus uhlazen�ho d�eva, h�lky jako tato jsou zrozeny z krutosti a zla.  Kouzlo, kter� obsahuje je u�ite�n�;  jedin� ot�zka je, zda v����, �e tvoje v�c ospravedl�uje pou�it� p�edm�tu tak hanebn� vytvo�en�ho.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/145.png" width="10px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornov� h�lka Roje</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z vydlaban�ho rohu jednoro�ce a nabodnut� na kus uhlazen�ho d�eva, h�lky jako tato jsou zrozeny z krutosti a zla.  Kouzlo, kter� obsahuje je u�ite�n�;  jedin� ot�zka je, zda v����, �e tvoje v�c ospravedl�uje pou�it� p�edm�tu tak hanebn� vytvo�en�ho.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/145.png" width="10px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornov� h�lka �epel�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z vydlaban�ho rohu jednoro�ce a nabodnut� na kus uhlazen�ho d�eva, h�lky jako tato jsou zrozeny z krutosti a zla.  Kouzlo, kter� obsahuje je u�ite�n�;  jedin� ot�zka je, zda v����, �e tvoje v�c ospravedl�uje pou�it� p�edm�tu tak hanebn� vytvo�en�ho.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/145.png" width="10px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Alakornov� h�lka Zaklet�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z vydlaban�ho rohu jednoro�ce a nabodnut� na kus uhlazen�ho d�eva, h�lky jako tato jsou zrozeny z krutosti a zla.  Kouzlo, kter� obsahuje je u�ite�n�;  jedin� ot�zka je, zda v����, �e tvoje v�c ospravedl�uje pou�it� p�edm�tu tak hanebn� vytvo�en�ho.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/150.png" width="20px" height="194px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Magick� h�lka V�buch�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z �ervenav�ho kovu, bazili��� vejce p�pevn�n� k pracovn�mu konci zavr�uje h�lku obsahuj�c� mocn� kouzlo.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/150.png" width="20px" height="194px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Magick� h�lka Blesk�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z �ervenav�ho kovu, bazili��� vejce p�ipevn�n� k pracovn�mu konci zavr�uje h�lku obsahuj�c� mocn� kouzlo.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/150.png" width="20px" height="194px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Magick� h�lka Kamen�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z �ervenav�ho kovu, bazili��� vejce p�ipevn�n� k pracovn�mu konci zavr�uje h�lku obsahuj�c� mocn� kouzlo.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/150.png" width="20px" height="194px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Magick� h�lka Paral�zy</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z �ervenav�ho kovu, bazili��� vejce p�ipevn�n� k pracovn�mu konci zavr�uje h�lku obsahuj�c� mocn� kouzlo.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/150.png" width="20px" height="194px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Magick� h�lka Mra�en</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben� z �ervenav�ho kovu, bazili��� vejce p�ipevn�n� k pracovn�mu konci zavr�uje h�lku obsahuj�c� mocn� kouzlo.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/155.png" width="33px" height="154px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mystick� h�lka Imploze</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�en� z p�edn� tlapy ml�d�te draka opat�en� dr�py, h�lky jako tato mohou n�st nejsiln�j�� kouzla.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/155.png" width="33px" height="154px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mystick� h�lka Pok�iven�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�en� z p�edn� tlapy ml�d�te draka opat�en� dr�py, h�lky jako tato mohou n�st nejsiln�j�� kouzla.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/155.png" width="33px" height="154px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mystick� h�lka St�epin</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�en� z p�edn� tlapy ml�d�te draka opat�en� dr�py, h�lky jako tato mohou n�st nejsiln�j�� kouzla.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/155.png" width="33px" height="154px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mystick� h�lka Smr��ov�n�</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�en� z p�edn� tlapy ml�d�te draka opat�en� dr�py, h�lky jako tato mohou n�st nejsiln�j�� kouzla.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/predmety/ostatni/155.png" width="33px" height="154px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mystick� h�lka Smrti</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�en� z p�edn� tlapy ml�d�te draka opat�en� dr�py, h�lky jako tato mohou n�st nejsiln�j�� kouzla.  K pou�it� mus�te h�lku uchopit, jako byste uchopili zbra�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3000</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
