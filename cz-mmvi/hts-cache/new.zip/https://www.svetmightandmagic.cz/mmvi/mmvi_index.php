<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h1>Might and Magic VI - The Mandate of Heaven</h1>
   
   <ul>
      <li><a href="mmvi_recenze.php">Recenze</a></li>
      <li><a href="mmvi_prolog.php">Prolog</a></li>
      <li><a href="mmvi_manual.php">P�t dopis� kr�lovn� Catherine</a></li>
      <li><a href="mmvi_vlastnosti.php">Vlastnosti postav</a></li>
      <li><a href="mmvi_dovednosti.php">Dovednosti</a></li>
      <li><a href="mmvi_povolani.php">Povol�n� postav</a></li>
      <li><a href="mmvi_levely.php">Tr�nink postav</a></li>
      <li><a href="mmvi_ucitele.php">Um�st�n� u�itel�</a></li>
      <li><a href="mmvi_alchymie.php">Alchymie</a></li>
      <li><a href="mmvi_obchodovani.php">Obchodov�n�</a></li>
      <li><a href="mmvi_gildy.php">Rozm�st�n� gild v Enrothu</a></li>
      <li class="li_1">Hern� postavy
      <ul>
         <li><a href="mmvi_npc.php">Naj�m�n� NPC</a></li>
         <li><a href="mmvi_npclokace.php">NPC postavy k najmut� v domech</a></li>
      </ul>
      </li>
      <li class="li_1">P�ehled monster
      <ul>
         <li><a href="mmvi_bestiar.php">Besti��</a></li>
      </ul>
      </li>
      <li class="li_1">P�edm�ty
      <ul>
         <li><a href="mmvi_zbrane.php">Zbran�</a></li>
         <li><a href="mmvi_zbroje.php">Zbroje</a></li>
         <li><a href="mmvi_ostatni.php">�apky, amulety, prsteny, opasky, h�lky</a></li>
         <li><a href="mmvi_artefakty.php">Artefakty</a></li>
         <li><a href="mmvi_relikvie.php">Relikvie</a></li>
         <li><a href="mmvi_bonusy.php">Bonusy p�edm�t�</a></li>
      </ul>
      </li>
      <li class="li_1">Magie
      <ul>
         <li><a href="mmvi_svitky.php">Kouzeln� knihy, svitky a h�lky</a></li>
         <li><a href="mmvi_kouzla_seznam.php">Abecedn� seznam kouzel</a></li>
         <li class="li_2">P�ehled kouzel podle �koly magie
         <ul>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=ohne">Magie ohn�</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=vzduchu">Magie vzduchu</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=vody">Magie vody</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=zeme">Magie zem�</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=ducha">Magie ducha</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=mysli">Magie mysli</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=tela">Magie t�la</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=bila">B�l� magie</a></li>
            <li style="list-style: circle;"><a href="mmvi_kouzla.php?magie=cerna">�ern� magie</a></li>
         </ul>
				 </li>
      </ul>
      </li>
      <li class="li_1">Mapy, cestov�n�, respawn
      <ul>
         <li><a href="mmvi_mapy.php">Mapy oblast� a dungeon�</a></li>
         <li><a href="mmvi_mestskabrana.php">M�stsk� br�na</a></li>
         <li><a href="mmvi_cestovani.php">Cestov�n� po Enrothu</a></li>
         <li><a href="mmvi_vmapa.php">Velk� mapa Enrothu</a></li>
         <li><a href="mmvi_respawn.php">Obnoven� (respawn) map</a></li>
      </ul>
      </li>
      <li class="li_1">N�vod, tipy
      <ul>
         <li><a href="mmvi_navod.php">N�vod na hru Might and Magic VI</a></li>
         <li><a href="mmvi_ukoly.php">P�ehled jednotliv�ch �kol�</a></li>
      </ul>
      </li>
      <li class="li_1">Ostatn� (dopl�kov� informace)
      <ul>
         <li><a href="mmvi_skrytepoklady.php">Skryt� poklady</a></li>
         <li><a href="mmvi_karty.php">Bal��ky osudu</a></li>
         <li><a href="mmvi_mecevkameni.php">Me�e v kameni</a></li>
         <li><a href="mmvi_cirkus.php">Lokace cirkusu</a></li>
         <li><a href="mmvi_hadanka.php">H�danka z obelisk�</a></li>
         <li><a href="mmvi_kaple.php">Rozm�st�n� kapl�</a></li>
         <li><a href="mmvi_chrambohu.php">Chr�m Boh�</a></li>
         <li><a href="mmvi_studny.php">Rozm�st�n� studn� s bonusy, sudy a kotle</a></li>
         <li><a href="mmvi_jidlo.php">Spot�eba j�dla p�i odpo�inku</a></li>
         <li><a href="mmvi_cas.php">Hern� �as</a></li>
         <li><a href="../pmm/pmm_atypdruziny.php">Atypick� dru�iny (hr��i)</a></li>
      </ul>
      </li>
   </ul>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
