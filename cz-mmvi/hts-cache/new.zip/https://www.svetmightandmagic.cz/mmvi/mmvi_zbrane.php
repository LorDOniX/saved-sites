<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; border: none; text-indent: 5px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <a class="zalozka" name="00"></a>
   <h2>Zbran�</h2>
   
   <ul>
      <li><a href="#01">Me�e</a></li>
      <li><a href="#02">D�ky</a></li>
      <li><a href="#03">Sekyry</a></li>
      <li><a href="#04">Kop�</a></li>
      <li><a href="#05">Halapartny</a></li>
      <li><a href="#06">Trojzubce</a></li>
      <li><a href="#07">Luky</a></li>
      <li><a href="#08">Ku�e</a></li>
      <li><a href="#09">Palc�ty</a></li>
      <li><a href="#10">Kladiva</a></li>
      <li><a href="#11">Kyje</a></li>
      <li><a href="#12">Hole</a></li>
      <li><a href="#13">Blastery</a></li>
   </ul>
   
   <h3><a class="zalozka" name="01">Me�e</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>V�echny me�e ve h�e se d�l� celkem do �ty� samostatn�ch kategori� - na dlouh� me�e, obouru�n� me�e, �irok� me�e a �avle. Krom obouru�n�ch me�� se v�echny ostatn� dr�� jen v jedn� ruce. Ka�d� z kategori� je pak op�t se�azena podle kvality od nejhor��ho po nejlep��.</p>
   
   <h4>Dlouh� me�e</h4>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/01.png" width="45px" height="184px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dlouh� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">A� jednoduch�ho proveden� a vzhledu, tento dlouh� me� je p�esto smrteln�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/02.png" width="42px" height="181px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�le�n� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Dlouh� me� v�born� s�ly a ost��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/03.png" width="32px" height="184px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">K�i��ck� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tepan� kovov� obrazce na �epeli tohoto dlouh�ho me�e nazna�uj� vysoce kvalitn� trpasli�� v�robek.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>350</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/04.png" width="33px" height="189px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ryt��sk� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Dlouh� me� extr�mn� kvality, tato zbra� je jedna z ne v�ce ne� tis�ce sv�ho druhu ukovan�ch mistrem kov��em Mekorigem Slep�m cca 780-800.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/05.png" width="40px" height="184px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Me� Lv� srdce</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d3+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zbra� tak vz�cn� jako starobyl�, tento dlouh� me� byl ukov�n b�hem �asu z�zrak�.  Proces pou�it� k ukov�n� oceli t�to kvality byl ztracen n�kdy po Tichu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <h4>Obouru�n� me�e</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/06.png" width="61px" height="217px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Obouru�n� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Z�kladn� obouru�n� me�.  Tis�ce t�chto zbran� n�zk� kvality lze nal�zt po cel�m Enrothu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/07.png" width="60px" height="232px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Velk� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Op�t dal�� jednoduch� obouru�n� me�, tato barbarsk� zbra� stav� na odiv vlnitou a zna�n� k�ivou �epel.  Je pevn� konstrukce a �epel je ostr�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/08.png" width="41px" height="207px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hrdinsk� me�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d5+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Obouru�n� me� neobvykle vysok� kvality, toto ost�� je jak siln�, tak spolehliv�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>800</td>
      </tr>
   </table>
   
   <h4>�irok� me�e</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/09.png" width="38px" height="176px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Me� s �irokou �epel�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Obvykl� me� se �irokou �epel�.  Tyto �epele lze naj�t po cel� zemi v rukou jak hrdin�, tak i zloduch�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/10.png" width="43px" height="183px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� me� s �irokou �epel�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Me� se �irokou �epel� z ryz� erathiansk� oceli excelentn� kvality a ost��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/11.png" width="38px" height="184px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mohutn� me� s �irokou �epel�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ost�� a rukov� tohoto me�e se �irokou �epel� jsou o�arovan� a nedot�en� �asem.  �epel vypad� jako kdyby byla ukov�na v�era.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h4>�avle</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/12.png" width="41px" height="187px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�avle</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">�avle goblin� v�roby, toto ost�� je stejn� smrteln� jako o�kliv�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/13.png" width="33px" height="179px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pir�tsk� �avle</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tradi�n� rezervn� zbra� regnansk�ch pir�t� �ij�c�ch na nespo�etn�ch ostrovech na v�chod od ostrova Mist.  Tyto �avle byly ukov�ny jedn�m z dlouh� �ady kov���.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>290</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/14.png" width="41px" height="191px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�avle mistr�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Chyt�e ukryt� inici�ly bl�zko z�tity t�to �avle prokazuj�, �e tato kr�sn� zbra� je d�lem Aleca Telinga, mistra kov��e Harecka IX, P�na Regny, a c�sa�e Nekone�n�ho oce�nu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>590</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="02">D�ky</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>Podobn� jako je tomu u me��, tak se i d�ky d�l� do dvou samostatn�ch kategori� - na oby�ejn� d�ky a na dlouh� d�ky. Ka�d� z kategori� je op�t �azena podle kvality od nejhor�� po nejlep��.</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/15.png" width="38px" height="109px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Oby�ejn� d�ka, obl�ben� mezi zlod�ji a vrahy po cel�m sv�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>8</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/16.png" width="30px" height="123px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ob�tn� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ob�tn� d�ky jsou ceremoni�ln� zbran� no�en� regnanskou �lechtou.  Jejich popularita se v posledn�ch letech roz���ila tak� mezi enrothskou �lechtu, a nyn� je lze nal�zt po cel� zemi.  P�esto�e ceremoni�ln�, jsou to ostr� a spolehliv� ost��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/17.png" width="34px" height="123px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ka temnot</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Schv�len� Erikem ��len�m, kdy� byl je�t� �lov�k, ��k� se, �e tyto d�ky maj� spojen� se Sv�tem mrtv�ch.  U��vaj� se p�i jist�ch magick�ch ritu�lech ur�en�ch k nep�irozen�mu prodlou�en� �ivota.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/18.png" width="26px" height="105px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ka m�g�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jedna z m�n� ne� sta takov�chto �epel�, d�ky m�g� byly ukov�ny �leny Alchymistick� aliance, zhruba p�ed 300 lety, v plamenech pod hradem Alamos. Dnes ji� tak jemn� ost�� nen� mo�n� vykovat.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/19.png" width="37px" height="112px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zdoben� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d2+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zbra� z �asu z�zrak�, tato �epel je jak velmi star�, tak velmi kvalitn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>
   
   <h4>Dlouh� d�ky</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/20.png" width="38px" height="150px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dlouh� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Obvykl� dlouh� d�ka.  Na pomez� mezi me�i, tyto dlouh� d�ky jsou obl�ben� mezi vrahy, kte�� cht�j� zbra�, jen� je lehce zatajiteln�, ale p�itom m� del�� dosah ne� tradi�n� d�ka.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/21.png" width="34px" height="143px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ostr� d�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Skute�n� sp��e kr�tk� me� ne� d�ka, �zk� �epel skr�v� neobvyklou s�lu a mo�nost o�arovat ost��.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/22.png" width="37px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ka boh�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3+7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">'Zbra� Boh�', tato zbra� je jedna z posledn�ch vytvo�en�ch ne� velk� kov�rny upadly do Ticha v roce 113 P.T (Po Tichu).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>350</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="03">Sekyry</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>Aby to nebylo tak snadn�, tak i sekyry maj� sv� dv� samostatn� kategorie. Krom b�n�ch seker se ve h�e setk�me i s obouru�n�mi sekyrami, kter� se zcela dle o�ek�v�n� dr�� ob�ma rukama. Nem��ete je tedy pou��vat spole�n� s me�i. Ka�d� z kategori� je op�t d�lena podle kvality od nejhor�� po nejlep��.</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/23.png" width="34px" height="109px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ru�n� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Sp��e n�stroj ne� zbra�, tato jednoduch� zbra� bude fungovat v p��pad� nouze.  Ale neo�ek�vejte mnoho.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>30</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/24.png" width="51px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Bojov� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�ena jako zbra� pro v�lku m�sto jako n�stroj, bojov� sekyra je obvykle pou��v�na barbary a nedisciplinovan�mi arm�dami.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/25.png" width="44px" height="131px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�le�n� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato v�le�n� sekyra vypad� jako jedna z velk� z�silky takov�ch sekyr uko�ist�n� Rolandem za N�stupnick� v�lky.  Byla vyrobena v Karigoru na p��kaz Archibalda Ironfista pro pou�it� proti jeho bratrovi v jejich z�pase o tr�n Enrothu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/26.png" width="45px" height="119px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trpasli�� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P��klad vysoce kvalitn� pr�ce odveden� trpasl�ky v Rud�ch hor�ch, �epel je ostr� a vyv�en� perfektn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/27.png" width="48px" height="157px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Skv�l� sekyra</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato zbra� m� nepochybn� temnou historii. Sekyra t�to kvality b�v� ukov�na pouze jako osobn� zbra� urozen�ho trpasl�ka, a nikdy se neprod�v� ani se s ni neobchoduje...</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>550</td>
      </tr>
   </table>
   
   <h4>Obouru�n� sekyry</h4>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/28.png" width="71px" height="178px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�iro�ina</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento typ sekyry s dlouhou rukojet� je typicky pou��v�n v�chodn�mi kmeny a elitn� str�� n�kter�ch aristokr�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>225</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/29.png" width="37px" height="252px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">T�k� �iro�ina</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Siln�j�� verze z�kladn� �iro�iny, tato zbra� je �asto pou��v�na m�stsk�mi str�emi a jin�mi bojovn�ky, kte�� neo�ek�vaj� velkou bitvu ve velk�ch koordinovan�ch skupin�ch (jako arm�dy).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/30.png" width="52px" height="266px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mocn� �iro�ina</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Hlava �epele t�to zbran� byla zjevn� stvo�ena za pomoci magie. Je neoby�ejn� ostr� a p�itom velmi lehk�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>900</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="04">Kop�</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/31.png" width="9px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">St�� v�ce ne� naost�en� ty�, toto kop� je p�esto pom�rn� smrteln�.  Jako v�echna kop� m��e b�t pou��v�no jednou nebo ob�ma rukama (+1D9 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>15</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/32.png" width="13px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ostr� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Toto kop� m� pos�len� ocelov� hrot pro lep�� proniknut� skrz brn�n� a z�kryty.  Jako v�echna kop� m��e b�t pou��v�no jednou nebo ob�ma rukama (+1D9 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/33.png" width="45px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Had� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zdoben� vy�ez�van�mi hady obt��ej�c�mi se kolem n�sady, toto kop� je vybaveno p���nou ��st�, kter� m� zabr�nit probodnut�m um�raj�c�m nep��tel�m v posouv�n� se pod�l n�sady kop�.  Jako v�echna kop� m��e b�t pou��v�no jednou nebo ob�ma rukama (+1D9 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/34.png" width="28px" height="289px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Divok� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Cel� vytvo�ena ze vz�cn�ho, namodral�ho kovu, spodn� polovina tohoto kop� je obto�ena drahou k���.  Sb�ratelsk�  p�edm�t!  Jako v�echna kop� m��e b�t pou��v�no jednou nebo ob�ma rukama (+1D9 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/35.png" width="36px" height="287px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Posv�tn� kop�</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>13</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d9+13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Symbol kov�rny a datum zna��, �e toto kop� bylo vyrobeno v magick�ch v�hn�ch vl�dce Padishe 12 let p�ed Tichem (+1D9 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="05">Halapartny</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/36.png" width="52px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Halapartna</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kombinace halapartny a kop�, halapartn�k m��e zasadit stra�liv� r�ny, ale pomalu se znovu rozmachuje.  Tento kousek je pr�m�rn� kvality a zpracov�n� (+1D6 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/37.png" width="56px" height="282px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Robustn� halapartna</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Solidn� konstrukce, tato halapartna m� zvl�t� t�kou �epel.  V ruk�ch siln�ho v�le�n�ka m��e b�t nepochybn� pou�ita k zab�jen� nejodoln�j��ch stv�r (+1D6 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/38.png" width="50px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Nejlep�� halapartna</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d6+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� zn�mka na �epeli t�to zbran� zna��, �e byla zkonstruov�na ve slavn� Mekorigov� sl�v�rn� mistrem samotn�m, Mekorigem Slep�m.  T�ko bys kdekoli na sv�t� hledal lep�� halapartnu (+1D6 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>700</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="06">Trojzubce</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/39.png" width="56px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Trojzubec</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">V�le�n� trojzubce jako tento jsou zbran� dobr� kvality pou��van� C�sa�sk�m regnansk�m n�mo�nictvem k v�b�ru cla na �ir�ch mo��ch.  V�t�ina kupc� a jin�ch vl�d ale tuto aktivitu naz�v� pir�tstv�...(+1D6 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/40.png" width="63px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zdoben� trojzubec</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">V�le�n� trojzubec typu pou��van�ho d�stojn�ky C�sa�sk�ho regnansk�ho n�mo�nictva.  Tento kus byl pravd�podobn� z�sk�n od d�stojn�ka v bitv� o "clo", kter� se pro N�mo�nictvo nevyv�jela moc dob�e (+1D6 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/41.png" width="61px" height="285px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tit�nsk� trojzubec</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d6+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento n�dhern� trojzubec je vyroben hlavn� z Kergaru, vz�cn�ho namodral�ho kovu, kter� nerezav� ani se �asem neotup� (+1D6 p�i pou�it� obouru�n�).</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>700</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="07">Luky</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/42.png" width="37px" height="247px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dlouh� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jednoduch� dlouh� luk zkonstruovan� z obvykl�ch materi�l� a neinspirativn�ho vzhledu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/43.png" width="45px" height="223px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elf� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zbra� vyr�b�n� pouze elfy z velk�ho erathiansk�ho lesa.  Tento vykazuje stejnou vysokou kvalitu zpracov�n� jako v�echny elf� artefakty.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/44.png" width="34px" height="226px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">P�esn� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>4</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vy�ezan� inici�ly prozrazuj�, �e tento luk vznikl v proslul� d�ln� elf�ho mistra Ivana Selvinga b�hem V�lek o d�evo koncem sedm�ho stolet�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/45.png" width="43px" height="203px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kouzeln� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>6</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento luk je slo�en� z podivn�ch materi�l� v�zan�ch dohromady d�mysln�mi kouzly.  Je extr�mn� lehk� a p�esn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/46.png" width="46px" height="229px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kompozitn� luk</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vytvo�en� z ��st� Nebesk�ch kov�ren, kdy� se staly zbyte�n�mi n�kolik let po Tichu, pouze velice m�lo z t�chto luk� p�e�ilo cestu �asu.  T�ch p�r zbyl�ch nahromadili elfov� a sb�ratel�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="08">Ku�e</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/47.png" width="70px" height="145px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ku�e</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Ku�e jsou nejsmrteln�j�� st�eln� zbran� vytvo�en� od �asu z�zrak�.  Tato ku�e je ud�l�na z dubov�ho d�eva a kovov�ch up�nadel, ale jinak je sp��e oby�ejn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/48.png" width="92px" height="161px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">P�esn� ku�e</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto ku�e byly shrom�d�ny Archibaldem pr�v� p�ed N�stupnickou v�lkou, proto�e je cht�l pou��t proti jeho bratrovi.  Jako p�i v�ech rozhodnut�ch t�kaj�c�ch se smrti, Archibald vyb�ral moud�e.  Tyto ku�e pat�� k nejlep��m v zemi.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/49.png" width="65px" height="166px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Spolehliv� ku�e</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>4d2+7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vybaven� ru�n� klikou a m��idly, tyto mimo��dn� ku�e jsou kvalitn�j�� ne� jak�koliv jin�.  Jenom jejich p�vod je v sou�asn� dob� z�hada...</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="09">Palc�ty</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/50.png" width="34px" height="117px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Palc�t</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jenom o trochu v�ce ne� vylep�en� kyj, tyto obvykl� palc�ty jsou vyrobeny z obvykl�ch materi�l� a bez kvalitn�ho zpracov�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/51.png" width="39px" height="168px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Palc�t strachu</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Solidn� navr�en� ke zp�soben� fat�ln�ch zran�n� i p�es brn�n�.  Vyv�en� je naho�e trochu moc t�k�, ale zpracov�n� je dobr�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/52.png" width="47px" height="155px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Hromov� palc�t</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento palc�t je jeden z tis�c� vytvo�en�ch v Nebesk�ch kov�rn�ch p�ed Tichem.  Ale to bylo p�ed v�ce ne� tis�ci lety, a tak jich u� moc nezb�v�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/53.png" width="26px" height="130px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�arovn� palc�t</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Pouze magie mohla ud�lat takovou t�kop�dnou zbra� tak lehkou, ale p�itom zachovat jej� tvrd� �der.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/54.png" width="49px" height="139px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Smrt�c� palc�t</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>11</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+11</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zkonstruov�n Nekromancerskou gildou zrovna p�ed jejich p�dem v N�slednick� v�lce, tyto neobvykl� zbran� jsou t�m�� v�dy o�arovan� mocnou magi�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="10">Kladiva</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/55.png" width="51px" height="151px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kladivo</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nemilostn� a nevynal�zav� zbra�, kladiva jsou pomal�, ale jejich z�sah velmi tvrd�.  Toto je obvykl� konstrukce a materi�l�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>120</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/56.png" width="57px" height="143px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kladivo temnot</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Krok kup�edu v kvalit� konstrukce, tato kladiva jsou obvykle pou��v�na humanoidn�mi stv�rami.  A proto�e ka�d� v�, �e v�t�ina stv�r nevyr�b� zbran�, vyvst�v� ot�zka 'odkud je tedy berou?'...</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/57.png" width="39px" height="141px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Svat� kladivo</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>9</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5+9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magicky vytvo�ena, tato kladiva jsou majetkem C�rkve M�s�ce v Karigoru.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="11">Kyje</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/58.png" width="32px" height="151px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kyj</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Primitivn� zbra� pou��van� jen nejtup�j��mi ze stv�r.  Nechcete ji snad pou��vat, �e ne?</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/59.png" width="39px" height="185px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kyj s hroty</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vylep�en� jednoduch�ho kyje, tento kyj s hroty zp�sob� o�kliv�j�� r�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/60.png" width="22px" height="151px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zabij�ck� kyj</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>5</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>1d3+5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Kr�l rodiny kyj�.  Kdyby tato zbra� m�la na konci homoli nebo kouli, byl by to palc�t.  Na tomto kyji jsou zn�mky skute�n� �emesln� zru�nosti, ale nejsou na n� vid�t ��dn� skute�n� identifika�n� zna�ky, kter� by zna�ily, kdo ji vytvo�il.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="12">Hole</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/61.png" width="21px" height="213px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">H�l</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">H�l je tradi�n� zbra� utiskovan�ch.  Tato je v�edn� a rub�n na konci je vlastn� jen barevn� skl��ko.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>40</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/62.png" width="19px" height="287px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Smaragdov� h�l</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>3</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magicky lehk� a tvrd�, tato h�l je vyrobena ze vz�cn�ho d�eva uloupen�ho ef�m b�hem V�lky o d�evo 600 P.T.  Smaragd na konci je prav�, a pravd�podobn� slou�� jako magick� z�sob�rna, ze kter� h�l �erp� svoji s�lu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/63.png" width="77px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mocn� h�l</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato h�l, spolu s dal��mi sv�ho druhu, byla nalezena v pokladnici Nekromancersk� gildy po jejich katastrof�ln� por�ce Rolandem na konci N�stupnick� v�lky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="13">Blastery</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/64.png" width="36px" height="103px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Blaster</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d5+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zbra� stra�liv� s�ly, z�eteln� vytvo�en� b�hem �asu z�zrak�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>0</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbrane/65.png" width="62px" height="235px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Plasmov� pu�ka</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d5+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nejlep�� z osobn�ch zbran� vyroben�ch b�hem �asu z�zrak�, tato plasmov� pu�ka um� ���it smrt rychleji ne� jak�koli zbra�, kterou jsi kdy vid�l.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>0</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
