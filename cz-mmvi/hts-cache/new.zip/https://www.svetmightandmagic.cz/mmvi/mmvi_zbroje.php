<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; border: none; text-indent: 5px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <a class="zalozka" name="00"></a>
   <h2>Zbroje</h2>
   
   <ul>
      <li><a href="#01">Ko�en� zbroje</a></li>
      <li><a href="#02">Krou�kov� zbroje</a></li>
      <li><a href="#03">Pl�tov� zbroje</a></li>
      <li><a href="#04">�t�ty</a></li>
      <li><a href="#05">Helmy</a></li>
      <li><a href="#06">Pl�t�</a></li>
      <li><a href="#07">Rukavice</a></li>
      <li><a href="#08">Boty</a></li>
   </ul>
   
   <h3><a class="zalozka" name="01">Ko�en� zbroje</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/66.png" width="74px" height="119px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� brn�n�</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nejleh�� a nejsnadn�ji vyrobiteln� mezi brn�n�mi, ko�en� brn�n� nab�z� nejm�n� ochrany.  Tento konkr�tn� oblek je pr�m�rn� kvality.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/67.png" width="100px" height="102px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Tvrzen� k��e</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tvrzen� k��e nab�z� v�ce ochrany ne� oby�ejn� ko�en� brn�n� za cenu v�t�� tuhosti a v�hy.  Tento konkr�tn� oblek je dob�e ud�l�n.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/68.png" width="103px" height="144px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Za�arovan� k��e</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jinak oby�ejn� ko�en� brn�n� je prostoupeno d�mysln�m o�arov�n�m, kter� zesiluje materi�l proti ran�m, ani� by zvy�ovalo v�hu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/69.png" width="116px" height="130px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">C�sa�sk� k��e</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>16</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Standardn� druh ko�en�ho brn�n� pro d�stojn�ky Regnansk�ho n�mo�nictva.  V�echna takov� ko�en� brn�n� obdr�� o�arov�n� k pos�len� a zleh�en� b�hem v�roby v Regnansk�ch zbrojovk�ch.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/70.png" width="91px" height="142px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Dra�� k��e</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>24</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Velice vz�cn� ko�en� brn�n� vytvo�en� b�hem konflikt� mezi C�rkv� M�s�ce a C�rkv� Slunce zhruba p�ed 80 lety.  Tyto obleky poskytuj� nejlep�� ochranu, kter� je mo�n� s ko�en�m brn�n�m.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1150</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="02">Krou�kov� zbroje</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/71.png" width="89px" height="150px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Krou�kov� brn�n�</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Krou�kov� brn�n� je zbroj slo�en� z mal�ch, navz�jem zapadaj�c�ch kovov�ch krou�k�.  Tento oblek je n�zk� kvality:  pou�it� kov je �ist� �elezo, m� pouze dv� vrstvy krou�k� a je t�k� a tuh� na svoji velikost.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/72.png" width="93px" height="157px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� brn�n�</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Lep�� krou�kov� brn�n�, pou�it� kov je ocel a p�edchoz� vlastn�k je pe�liv� udr�oval naolejovan� a bez rzi.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>600</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/73.png" width="119px" height="146px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Vzne�en� brn�n�</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>18</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Krou�kov� brn�n� d�stojn�ka kaval�rie z dob vl�dy Taledona V. z Karigoru, Bo�sk�ho Velekn�ze a Nejvy��� Jasnosti C�rkve Slunce, cca 870 P.T.  Zbroj je vysok� kvality, o�arovan� k zleh�en� a pos�len� kovu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>900</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/74.png" width="118px" height="149px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kr�lovsk� brn�n�</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>26</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vysoce o�arovan� zbroj no�en� elfskou �lechtou a kr�li b�hem V�lek o d�evo v sedm�m a osm�m stolet�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/75.png" width="135px" height="151px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Majest�tn� brn�n�</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>36</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Velice vz�cn� zbroj vyroben� v Nebesk�ch kov�rn�ch guvern�ra Padishe p�ed Tichem.  Zbroj byla p�vodn� no�ena pouze Guvern�rem a jeho nejvy���mi vojensk�mi d�stojn�ky jako odznak ��adu.  Nen� jen na d�v�n�; toto krou�kov� brn�n� je leh��, siln�j�� a v�ce ohebn� ne� jak�koli jin� na sv�t�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1800</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="03">Pl�tov� zbroje</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/76.png" width="140px" height="198px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>20</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Slo�en� z navz�jem zapadaj�c�ch pl�t� a spoj�, pl�tov� zbroj je ta nejlep�� neo�arovan� zbroj.  Je ale nicm�n� t�k� a zpomaluje pohyby nositele.  Tento oblek je pr�m�rn� kvality a kov�� je nezn�m�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1000</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/77.png" width="138px" height="201px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>28</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Dob�e vytvo�en� ocelov� pl�ty dohromady formuj� celkov� znamenitou zbroj.  Zna�ka sl�v�rny pod pravou pa�� zna��, �e byla vyrobena ned�vno v Kelebrimu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>1400</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/78.png" width="137px" height="204px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Zlat� pl�tov� zbroj</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>54</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato pl�tov� zbroj byla ukov�na v Mekorigov� sl�v�rn� osmn�ct let po smrti Mekoriga Slep�ho.  Mistrovsk� d�lo, zbroj se nos� skoro stejn� lehce jako oby�ejn� �aty a je to pravd�podobn� nejlep�� brn�n�, jak� je na sv�t� k dispozici.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2700</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="04">�t�ty</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <p>V�echny �t�ty ve h�e se rozd�luj� do dvou samostatn�ch kategori� - na velk� a mal� �t�ty. Ka�d� z nich je pak op�t �azena podle kvality od nejhor��ho po nejlep��.</p>
   
   <h4>Velk� �t�ty</h4>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/79.png" width="89px" height="164px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tvo�en� usn� nata�enou na d�ev�n� r�m, tento jednoduch� �t�t poskytuje z�kladn� ochranu proti fyzick�m �tok�m.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/80.png" width="79px" height="140px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">V�ov� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jednoduchost heraldick�ho vzoru na tomto �t�tu vede k my�lence, �e byl vytvo�en bu� barbary nebo gobliny.  Je vyroben z odoln�ch materi�l� a m�l by v boji odol�vat p�ijateln� dob�e.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/81.png" width="88px" height="135px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Velk� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento �t�t je tvo�en d�evem or�movan�m �elezem.  Je pon�kud t�k� na svoji velikost, ale bitvu bys s n�m m�l p�e��t bezpe�n� -- pokud ov�em nebude� p�epaden zezadu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>400</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/82.png" width="98px" height="104px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Nebesk� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>13</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vyroben z lehk�ho kovu, podle zna�ku sl�v�rny tento �t�t poch�z� z Kelebrimovy zbrojovky.  P�esto�e lehk�, jeho materi�l je velmi siln� a kov je sva�en t�m�� bezesp�rov�.  </td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>500</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/83.png" width="103px" height="107px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Olympsk� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>19</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto �t�ty byly ukov�ny v Phynaxiansk�m c�sa�stv� b�hem jeho kr�tk�ho obdob� moci na step�ch ji�n� Erathie (790-864).  Jsou vyrobeny ze staltu, kovu, kter� lze velice dob�e o�arovat, a p�isp�ly velk�m d�lem k Phynaxiansk� vojensk� moci.  Nane�t�st�, tohoto kovu nebylo mnoho, a tak Phynaxia padla 864 P.T. p�i ofenz�v� elf�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>800</td>
      </tr>
   </table>
   
   <h4>Mal� �t�ty</h4>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/84.png" width="73px" height="74px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">D�ev�n� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>4</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Mal� d�ev�n� �t�t navrhnut� hlavn� jako ochrana p�ed ��py.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/85.png" width="70px" height="74px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Bronzov� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Bronzov� �t�ty jsou leh�� ne� �elezn� �t�ty stejn� velikosti, ale nejsou ani zdaleka tak ��inn�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>200</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/86.png" width="74px" height="79px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Proto�e tento �t�t je vyroben z kalen� oceli, m�l by odol�vat v�emu a� na ty nejneobvyklej�� �arovn� zbran�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>300</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/87.png" width="83px" height="86px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Du�evn� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Du�evn� �t�ty jsou obvykl� ocelov� �t�ty o�arovan� ritu�ln�m procesem, kter� m��e m�t mohutn�, t�eba�e nep�edv�dateln� n�sledky.  Proces je �asov� n�ro�n� a vy�aduje plnou pozornost alespo� t�� mistr� Du�evn� magie.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/88.png" width="72px" height="78px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Astr�ln� �t�t</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>18</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto vz�cn� �t�ty byly kdysi vyr�b�ny po stovk�ch v Nebesk�ch kov�rn�ch pro boj s rebely. Ti v nekone�n�m �et�zci �arv�tek a loupe�n�ch v�pad� testovali (a kone�n� p�emohli) Panovn�kovy s�ly v prvn�m stolet� P.T.  Jako ka�d� takov� vybaven� je lehk�, tvrd� a schopn� n�st nejmocn�j�� kouzla.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="05">Helmy</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/89.png" width="44px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Oby�ejn� helma.  Tato je vyrobena z k��e nata�en� na d�evo.  Vevnit� nen� ��dn� ko�e�ina ani v�pl�, tak�e kdy� dostane� po��dnou r�nu, bude tvoje hlava asi zn�t jako zvon.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>60</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/90.png" width="48px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Toto je obvykl� ocelov� helma.  Tvar m� dobr� a je pou��v�na po stalet� v�le�n�ky v�ude na sv�t�.  Nejlep�� odhad je, �e tato helma je 50-75 let star�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>260</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/91.png" width="76px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Str�cova helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento typ helmy je pou��v�n elfy z Erathie od dob Ticha.  Je vyrobena ze st��bra a oceli a je velice siln�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>460</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/92.png" width="62px" height="68px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Obr�ncova helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Zpola vyrobena z lebky Mogreda, stra�liv� �elmy z Karigoru, tyto helmy se st�vaj� ka�d�m rokem vz�cn�j��, jak se Mogredov� bl��� vyhynut�.  �erven� pruhy okolo roh� helmy podporuj� o�arov�n�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>660</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/93.png" width="56px" height="75px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">And�lsk� helma</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tyto helmy jsou extr�mn� vz�cn�, a proto nikdo nev�, odkud poch�zej�, ale t�m�� jist� jsou z �asu z�zrak�.  Nesm�rn� tenk� n�pis uvnit� helmy ��k�  'Majetek lodn�ho skladu, VARN MCMIV'.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>860</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="06">Pl�t�</a> (<a href="#00">Zp�t na obsah</a>)</h3>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/105.png" width="74px" height="19px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>1</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Pou�it� ko�en� plṻ.  Slab� zap�ch� naftal�nem a prachem.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/106.png" width="74px" height="18px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Fantom�v plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">K obarven� tohoto vln�n�ho pl�t� na barvu letn� no�n� oblohy byl pou�it indigov� odst�n z Regnanansk�ho souostrov�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>150</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/107.png" width="76px" height="21px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Elf� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>5</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tkanina z rostlinn�ch vl�ken z les� Erathie, tyto pl�t� jsou tradi�n�m od�vem elf�ch jezdc�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/108.png" width="77px" height="21px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kardin�lsk� plṻ</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>7</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Plṻ d��ve no�en� vysok�mi ��edn�ky C�rkve Slunce z Karigoru p�ed rozpu�t�n�m C�rkve v roce 1083 P.T.  T�m�� v�echny tyto pl�t� byly n�jak�m zp�sobem o�arov�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/109.png" width="81px" height="20px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Plṻ Soudn�ho dne</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>9</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Plṻ d��ve no�en� vysok�mi ��edn�ky C�rkve M�s�ce z Karigoru p�ed rozpu�t�n�m C�rkve v roce 1083 P.T.  T�m�� v�echny tyto pl�t� byly n�jak�m zp�sobem o�arov�ny.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>750</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="07">Rukavice</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/110.png" width="39px" height="82px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>3</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Rukavice z ocelov�ch pl�t�, jednoduch�ho typu a v�roby.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/111.png" width="38px" height="83px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ryt��sk� rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato rukavice je vylep�en� verze jednoduch�, neohebn� ocelov� rukavice obvykle no�en� gobliny a zbojn�ky.  Vr�ek ruky a z�p�st� jsou pevn�, zat�mco spojen� okolo prst� je vyrobeno z krou�kov�ch spoj� k vylep�en� obratnosti.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/112.png" width="37px" height="81px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Paladinovy rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">A�koli �patn� ohebn�, tato rukavice m� pos�len� sp�ry nad kotn�ky a v z�kladn� z�p�st�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/113.png" width="37px" height="84px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Kaval�rsk� rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vysoce kvalitn� rukavice, nab�z� jak ohebnost, tak i ochranu. Sp�ry jsou pos�len�, nicm�n� jsou dost 'm�kk�', aby umo�nily norm�ln� pohyb ruky.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/114.png" width="34px" height="81px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ultim�tn� rukavice</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento mistrovsk� kus rukavic vytvo�ili trpasli�� kov��i. A� na extra objem nevypad�, �e by m�ly mnoho rozd�l� oproti sametov� rukavi�ce.  Ve sp�rech a z�p�st� se chyt�e posouvaj�c� a rotuj�c� pl�ty dovoluj� �pln� norm�ln� pohyb, zat�mco po cel� �as zaji��uj� plnou ochranu.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>850</td>
      </tr>
   </table>
   
   <h3><a class="zalozka" name="08">Boty</a> (<a href="#00">Zp�t na obsah</a>)</h3>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/115.png" width="61px" height="61px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ko�en� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>2</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Cestovn� boty vyroben� z k��e a okovan�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/116.png" width="57px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ocelov� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>6</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">T�k� ocelov� boty tvo�� pevnou ochranu nohy v bitv�.  Chod� se v nich nepohodln� a maj� tendenci zevnit� reziv�t.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>250</td>
      </tr>

   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/117.png" width="55px" height="62px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Obrn�n� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Vnit�ek t�chto bot z ocelov�ch pl�t� je vyroben z pe�� a l�tky ke zm�k�en� ostr�ch hran na kovov�ch pl�tech.  Jsou trochu t�k� a unavuj�c� pro dlouh� no�en�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>450</td>
      </tr>
   </table>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/118.png" width="57px" height="63px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">�terlingov� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Le�t�n� st��brn� boty se sametov�m vnit�kem, tyto boty jsou leh�� ne� ocelov� a jsou daleko pohodln�j��.  A taky dob�e vypadaj�.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>650</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="550px" style="margin: 15px 15px;">
      <tr>
         <td rowspan="4" style="width: 150px;" class="pravy"><img src="obrazky/predmety/zbroje/119.png" width="57px" height="65px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Ultim�tn� boty</td>
      </tr>
      <tr>
         <td>T��da zbroje:</td>
         <td>12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Boty z dra�� k��e, pos�len� kostrou z prou�k� roh� a staltov�ch kovov�ch n�t�.  M�kk� a lehk�, nab�zej� nesrovnatelnou ochranu nohy.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>850</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
