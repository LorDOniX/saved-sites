<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Me�e v kameni</h2>
   <p>&nbsp;</p>
   
   <p>V n�kolika oblastech Enrothu se m��ete setkat se zvl�tn�m �kazem, kter�m jsou me�e zap�chnut� v kamenech (celkem jich je 6). Nikdo nev�, kde se tu vzaly, ale k jejich vyta�en� je t�eba, aby postava m�la dostate�nou s�lu. V�hodou je, �e posta�� m�t s�lu zv��enou r�zn�mi bonusov�mi p�edm�ty, studnami nebo kouzly.</p>
   
   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/mecvkameni.png" width="163px" height="207px" />
   </div>
   
   <p>Krom me�e v Nov�m Sorpigalu existuje u ostatn�ch ur�it� pravd�podobnost, �e me� ponese n�jak� ze siln�j��ch o�arov�n� (bonus k vlastnostem nebo �toku). Pravd�podobnost p�itom nesouvis� s dal��mi vlastnostmi, tak�e je nap�. celkem jedno, jak velk� m�te �t�st� apod. V principu je to podobn� jako u obchod�, kdykoliv hru p�ed vyta�en�m me�e nahrajete, vypo��t� se nov� hodnota a me� bude m�t hodnoty podle n�. N�sleduj�c� tabulka ukazuje p�ehled jednotliv�ch me�� a pot�ebnou s�lu k jejich vyta�en�.</p>
   
   <div style="text-align: center; margin-top: 15px;">
      <table cellspacing="0" cellpadding="0" border="0" width="400px" style="margin: auto;">
         <tr class="hlavicka_tabulky">
            <td style="width: 100px;">Oblast</td>
            <td style="width: 100px;">Druh me�e</td>
            <td style="width: 100px;">Pot�ebn� s�la</td>
            <td style="width: 100px;">O�arov�n�</td>
         </tr>
         <tr>
            <td>Nov� Sorpigal</td>
            <td>Obouru�n� me�</td>
            <td>25</td>
            <td>nem�</td>
         </tr>
         <tr>
            <td>Hrad Ironfist</td>
            <td>Velk� me�</td>
            <td>40</td>
            <td>p�ibli�n� 40%</td>
         </tr>
         <tr>
            <td rowspan="3">St��brn� z�toka</td>
            <td>Hrdinsk� me�</td>
            <td>100</td>
            <td>p�ibli�n� 40%</td>
         </tr>
         <tr>
            <td>Me� Lv� srdce</td>
            <td>60</td>
            <td>p�ibli�n� 10%</td>
         </tr>
         <tr>
            <td>Ryt��sk� me�</td>
            <td>60</td>
            <td>p�ibli�n� 10%</td>
         </tr>
         <tr>
            <td>�ho�� vody</td>
            <td>Excalibur</td>
            <td>200</td>
            <td>nem�</td>
         </tr>
      </table>
   </div>
   
   <p>Hodnoty pravd�podobnosti o�arov�n� berte jen orienta�n�, jsou vypo��t�ny pr�v� na z�klad� po�tu nahr�t� hry p�ed vyta�en�m me�e z kamene a sledov�n�m z�skan�ch vlastnost�. Na n�sleduj�c�ch �ty�ech mapk�ch je pak zakreslena poloha v�ech �esti me��.</p>
   
   <p>V <span class="tucne">Nov�m Sorpigalu</span> se kousek nad m�stem nach�z� v kameni zap�chnut� Obouru�n� me�. K jeho vyta�en� je pot�eba s�la min. 25 a tento me� nem��e n�st ��dn� o�arov�n�.</p>
   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/sorpigal.png" width="209px" height="239px" />
   </div>
     
   <p>Pod <span class="tucne">Hradem Ironfist</span> se na mal�m ostr�vku se �pi�atou sk�lou nach�z� v kameni zap�chnut� Velk� me�. K jeho vyta�en� je pot�eba m�t s�lu alespo� 40. Existuje tak� v�ce jak 40% �ance, �e me� ponese siln�j�� o�arov�n�.</p>
   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/hradironfist.png" width="120px" height="127px" />
   </div>
      
   <p>Ve <span class="tucne">St��brn� z�toce</span> lze naj�t celkem 3 me�e zap�chnut� v kamenech. Na z�padn� ��sti pevniny se pobl�� hor nach�z� Hrdinsk� me�. Na mal�m ostrov� ve st�edu mapy je Me� Lv� srdce a na ostrov� s kruhem Slunce se nach�z� Ryt��sk� me�. K vyta�en� Hrdinsk�ho me�e je pot�eba s�la min. 100 a je 40% �ance, �e me� ponese siln� o�arov�n�. K vyta�en� Me�e Lv� srdce a Ryt��sk�ho me�e posta�� s�la 60 a u obou je p�ibli�n� 10% �ance, �e ponesou siln� o�arov�n�.</p>
   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/stribrzatoka.png" width="325px" height="208px" />
   </div>
   
   <p>Na severn�m ostrov� v <span class="tucne">�ho��ch vod�ch</span> nalezneme v kameni zap�chnut� artefakt Excalibur. K jeho vyta�en� je v�ak pot�eba s�la min. 200.</p>
   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/uhorvody.png" width="184px" height="165px" />
   </div>


   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
