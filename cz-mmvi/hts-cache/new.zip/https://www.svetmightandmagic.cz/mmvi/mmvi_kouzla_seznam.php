<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Abecedn� seznam kouzel</h2>
   <p>&nbsp;</p>
   
   <p>N�sleduj�c� tabulka obsahuje pouze abecedn� seznam v�ech 99-ti kouzel dostupn�ch ve h�e a jejich p��slu�nost ke konkr�tn� �kole magie. V jednotliv�ch kapitol�ch p�ehledu �kol si pak m��ete nal�zt podrobnosti o ka�d�m z nich.</p>

   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="3px" border="1" width="300px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 150px;">�kola magie</td>
      </tr>
      <tr>
         <td>And�l str�n�</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Armageddon</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Blesk</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Bo�sk� z�sah</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>�arod�jovo oko</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>�epele</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Den Boh�</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Den ochrany</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>D鹻 meteorit�</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Dotek smrti</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Dra�� dech</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Duhov� sv�tlo</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Duchovn� ��p</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Hodina Moci</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Hrdinstv�</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Hromadn� strach</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Hv�zdn� spou��</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Ch�ze po vod�</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Imploze</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Inferno</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Jedovat� sprej</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Jiskry</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Kamenn� k��e</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Kamenn� v�buch</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Kruh ohn�</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Kv�t smrti</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Kyselinov� v�r</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>L��ba zran�n�</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>L��iv� dotek</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Ledov� hrot</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Ledov� �der</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>L�t�n�</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Lloyd�v maj�k</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Magick� ��p</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Masivn� deformace</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Masov� proklet�</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Meditace</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Ment�ln� �der</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>M�s��n� paprsek</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>M�stsk� br�na</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Moc</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Mocn� l��ba</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Mraziv� proud</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>O�aruj p�edm�t</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Odkamen�n�</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Odolnost proti</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Odolnost proti jedu</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Odolnost proti magii</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Odolnost v��i elekt�in�</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Odstra� jed</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Odstra� magii</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Odstra� ochromen�</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Odstra� slabost</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Odstra� ��lenstv�</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Odstran�n� proklet�</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Ohniv� koule</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Ohniv� �ipka</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Ohniv� proud</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Ohniv� ��p</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Ochrana proti chladu</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Ochromen�</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Omr��en�</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Oslaben� mysli</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>O�iv mrtv�ho</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Pe���ko</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Pochode�</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Po�ehn�n�</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Preciznost</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Procitnut�</td>
         <td>Magie vody</td>
      </tr>
      <tr>
         <td>Prvn� pomoc</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Psychick� �ok</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Rychlost</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Sd�len� �ivot</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Sejmi strach</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Skok</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Slune�n� paprsek</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Smr��ovac� paprsek</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Smrt�c� roj</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Spla�en� p�st</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Statick� v�boj</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>St�epina</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>�arm</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>��astn� den</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>�t�t</td>
         <td>Magie vzduchu</td>
      </tr>
      <tr>
         <td>Telekineze</td>
         <td>Magie mysli</td>
      </tr>
      <tr>
         <td>Temn� tajemstv�</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Toxick� mrak</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Uzdrav nemoc</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Vytvo�en� j�dla</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Vzk���en�</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Za�e� nemrtv�</td>
         <td>Magie ducha</td>
      </tr>
      <tr>
         <td>Zkamen�n�</td>
         <td>Magie zem�</td>
      </tr>
      <tr>
         <td>Zlat� dotek</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Zmrtv�chvst�n�</td>
         <td>�ern� magie</td>
      </tr>
      <tr>
         <td>Zni�en� nemrtv�ho</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Zpomalen�</td>
         <td>B�l� magie</td>
      </tr>
      <tr>
         <td>Zpopeln�n�</td>
         <td>Magie ohn�</td>
      </tr>
      <tr>
         <td>Zra�</td>
         <td>Magie t�la</td>
      </tr>
      <tr>
         <td>Zrychlen�</td>
         <td>Magie ohn�</td>
      </tr>
   </table>
   </div>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
