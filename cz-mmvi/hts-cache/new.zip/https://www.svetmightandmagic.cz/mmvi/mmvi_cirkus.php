<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Lokace cirkusu</h2>
   <p>&nbsp;</p>
   
   <p>Putov�n� cirkusu pro v�s nabyde nejv�t��ho v�znamu ve chv�li, kdy v�m b�hem odpo�inku zlomysln� ute�e princ Nikolai. Kdy� se mi toto stalo poprv�, trvalo mi velmi dlouho, ne� jsem na�el osobu, kter� mi pov�d�la o cirkusov� trase a je�t� ke v�emu jsem jednu zast�vku zme�kal. D�ky tomu jsem musel pom�rn� dlouho �ekat s pov��en�m paladina, proto�e do n�lezu prince se nedalo do hradu Ironfist dostat. Trasa je tedy n�sleduj�c�: duben - Blackshire, srpen - Mo��l proklet�ch a prosinec - Z�toka pa�er�k�.</p>
   <p>Kdy� u� se do cirkusu dostanete, ud�lejte si rovnou chvilku a v hlavn�m stanu se seznamte s podm�nkami v�hry. Pokud m� n�kter� z va�ich postav jednu ze z�kladn�ch vlastnost� na vysok� �rovni, pak nev�hejte a najd�te si v okoln�ch stanech p��slu�nou hru. Za mal� obnos 50 zlat�ch za kolo pak m��ete sout�it. Podle toho, jak budete �sp�n�, budete vyhr�vat r�zn� ceny, kter� pak m��ete op�t v hlavn�m stanu vym�nit za hlavn� v�hry - zlatou pyramidku nebo soudek v�na. Krom toho m��ete jednotliv� v�hern� p�edm�ty po r�znu rozprodat ve Svobodn�m p��stavu. S pyramidkou nebo soudkem pak m��ete zaj�t do o�zy v Dra��ch p�sc�ch a vym�nit ji za zbroj, zbra� nebo jin� p�edm�t vysok� kvality.</p>
   <p>Jednotliv� ceny a jejich bodov� ohodnocen� je n�sleduj�c�: magnetovec je za 1 bod, pero harpyje za 3 body a �ty�l�stek za 5 bod�. Za 10 bod� si m��ete vyzvednout soudek v�na a za 30 bod� zlatou pyramidku. Ov�em je tu men�� z�drhel. Pokud nap�. do hlavn�ho stanu p�ijdete s v�hrami za 20 bod�, nedostanete 2 soudky v�na, ale jen jeden soudek a o zbytek bod� p�ijdete. Je tedy dobr� do hlavn�ho stanu chodit jen s takov�m po�tem bod�, kter� odpov�d� jednomu soudku v�na nebo jedn� zlat� pyramidce.</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
