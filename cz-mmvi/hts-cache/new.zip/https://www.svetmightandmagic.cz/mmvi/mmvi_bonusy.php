<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      td {text-align: left; padding: 4px;}
      td.center {text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Bonusy p�edm�t�</h2>
   <p>&nbsp;</p>
   
   <p>Ve h�e m�te k dispozici �adu p�edm�t�, kter� m��e postava p�i sv�m cestov�n� pou��vat. Jsou to zbran�, zbroje, prsteny, amulety, knihy kouzel, svitky, lektvary a r�zn� �kolov� p�edm�ty. Ka�d� z dan�ch p�edm�t� m��e krom� sv�ch z�kladn�ch vlastnost� disponovat je�t� ur�it�m bonusem nav�c. Bonus se projevuje bu�to jako p��davek do z�kladn�ch a sekund�rn�ch vlastnost� postavy (prim�rn� atributy, zdrav�, mana, t��da zbroje, odolnosti) anebo jako bonus k dovednosti, ke zran�n�, k magii aj. Velikost bonusu m��e b�t prom�nn� (viz prvn� tabulka) nebo m��e b�t bonus konstantn� (viz druh� tabulka).</p>
   <p>V p��pad� bonus� k z�kladn�m vlastnostem postavy (tak� nap�. pro TZ, zdrav� a manu) se bonusy jednotliv�ch p�edm�t� vz�jemn� s��taj�. V p��pad� bonus� k dovednostem se pak ze v�ech p�edm�t�, kter� m� postava na sob�, bere v �vahu jen p�edm�t s nejsiln�j��m bonusem - nap�. z trojice prsten� +5, +10 a +15 ke vzdu�n� magii se po��t� jen bonus +15 (tedy nikoliv cel�ch +30). Z tohoto d�vodu nem� ��dn� smysl nosit v�ce p�edm�t� se stejn�m bonusem k p��slu�n� dovednosti, ale je dobr� si vybrat jen ten nejlep��. Samoz�ejm� i tady nalezneme men�� vyj�mku. Pokud je bonusov�m p�edm�tem artefakt nebo relikvie, pak se jej� p��padn� bonus k dovednosti m��e p�i��st k ji� no�en�mu oby�ejn�mu bonusov�mu p�edm�tu - bonusy se vz�jemn� se�tou. Pokud tedy p�edchoz� �adu dopln�me o artefakt s bonusem +5 ke vzdu�n� magii, pak v�sledn� bonus bude 15 + 5 neboli +20 k magii vzduchu.</p>
   <p>P�edm�ty s bonusem je mo�n� ve h�e z�skat prohled�v�n�m truhel, mrtvol nep��tel, nakupov�n�m nebo m��ete p�edm�ty s bonusem vyr�b�t. K v�rob� p�edm�t� poslou�� jak�koliv dostate�n� kvalitn� neokouzlen� p�edm�t, na kter� pak zakouzl�me kouzlo vodn� magie O�aruj p�edm�t. V z�vislosti na �rovni dovednosti ve vodn� magii a na kvalit� p�edm�tu pak dostaneme odpov�daj�c� trval� o�arov�n�. Nekvalitn� p�edm�t se p�i pokusu o o�arov�n� rozbije. Stejn� tak rozbit� o�arovan� p�edm�t ztr�c� sv�j bonus do t� doby, ne� je znovu opraven.</p>
   <p>O�arov�n� p�edm�t� m� krom v�hod bonus� je�t� jednu v�raznou vlastnost. Okouzlen�m roste hodnota dan�ho p�edm�tu. O kolik bude vy��� pak z�vis� na s�le a mno�stv� "uv�zn�n�ho" kouzla. N�r�st ceny je u p�edm�t� s konstantn�mi bonusy st�le stejn�, u p�edm�t� s prom�nou velikost� bonusu se pak li�� pr�v� podle mno�stv� bod�, kter� do vlastnosti poskytuje. Pro p�edm�ty s prom�n�m bonusem se zav�d� tzv. jednotkov� hodnota, tedy o kolik vzroste hodnota p�edm�tu, kdy� se hodnota bonusu zv��� o jedna (viz prvn� tabulka). Nap�. v�sledn� cena Lun�rn�ho prstenu My�len� s bonusem +5 k Intelektu bude cena prstenu + 5 x jednotkov� hodnota, tedy 500 + 5 x 100 = 1000.</p>
   <p><span class="tucne">N�sleduj�c� tabulka uv�d� p�ehled bonus� s prom�nou velikost� bonusu:</span></p>
   
   <div style="text-align: center;">
   <table width="550px" celspacing="0" cellpadding="0" border="1" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;" class="center">Bonus</td>
         <td style="width: 100px;" class="center">Cena p�edm�tu se zv��� o</td>
         <td style="width: 350px;" class="center">Popis</td>
      </tr>
      <tr>
         <td>My�len�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Intelektu.</td>
      </tr>
      <tr>
         <td>�armu</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Osobnosti.</td>
      </tr>
      <tr>
         <td>Sv�esti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Odolnosti.</td>
      </tr>
      <tr>
         <td>Preciznosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do P�esnosti.</td>
      </tr>
      <tr>
         <td>Rychlosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Rychlosti.</td>
      </tr>
      <tr>
         <td>�t�st�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do �t�st�.</td>
      </tr>
      <tr>
         <td>Zdrav�</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Zdrav�.</td>
      </tr>
      <tr>
         <td>Magie</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do Many.</td>
      </tr>
      <tr>
         <td>Obrany</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do T��dy zbroje.</td>
      </tr>
      <tr>
         <td>ohniv� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti ohni.</td>
      </tr>
      <tr>
         <td>elektrick� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti elekt�in�.</td>
      </tr>
      <tr>
         <td>chladov� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti mrazu.</td>
      </tr>
      <tr>
         <td>jedov� odolnosti</td>
         <td class="center">100</td>
         <td>P�id�v� dan� mno�stv� bod� do odolnosti proti jedu.</td>
      </tr>
   </table>
   </div>
   
   <p><span class="tucne">N�sleduj�c� tabulka uv�d� p�ehled bonus� s konstantn� velikost� bonusu:</span></p>   
      
   <div style="text-align: center;">
   <table width="550px" celspacing="0" cellpadding="0" border="1" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 100px;" class="center">Bonus</td>
         <td style="width: 100px;" class="center">Cena p�edm�tu se zv��� o</td>
         <td style="width: 350px;" class="center">Popis</td>
      </tr>
      <tr>
         <td>Ochrany</td>
         <td class="center">1000</td>
         <td>+10 v�em odolnostem.</td>
      </tr>
      <tr>
         <td>Boh�</td>
         <td class="center">3000</td>
         <td>+10 ke v�em sedmi vlastnostem.</td>
      </tr>
      <tr>
         <td>Krveprolit�</td>
         <td class="center">5000</td>
         <td>V�bu�n� �der!</td>
      </tr>
      <tr>
         <td>Chladu</td>
         <td class="center">500</td>
         <td>P�id� 3-4 body zran�n� mrazem.</td>
      </tr>
      <tr>
         <td>Mrazu</td>
         <td class="center">1000</td>
         <td>P�id� 6-8 body zran�n� mrazem.</td>
      </tr>
      <tr>
         <td>Ledu</td>
         <td class="center">2000</td>
         <td>P�id� 9-12 bod� zran�n� mrazem.</td>
      </tr>
      <tr>
         <td>Jisker</td>
         <td class="center">500</td>
         <td>P�id� 3-4 body zran�n� elekt�inou.</td>
      </tr>
      <tr>
         <td>Blesk�</td>
         <td class="center">1000</td>
         <td>P�id� 4-10 bod� zran�n� elekt�inou.</td>
      </tr>
      <tr>
         <td>Hrom�</td>
         <td class="center">2000</td>
         <td>P�id� 6-15 bod� zran�n� elekt�inou.</td>
      </tr>
      <tr>
         <td>Ohn�</td>
         <td class="center">500</td>
         <td>P�id� 1-6 bod� zran�n� ohn�m.</td>
      </tr>
      <tr>
         <td>Plamene</td>
         <td class="center">1000</td>
         <td>P�id� 2-12 bod� zran�n� ohn�m.</td>
      </tr>
      <tr>
         <td>Pekla</td>
         <td class="center">2000</td>
         <td>P�id� 3-18 bod� zran�n� ohn�m.</td>
      </tr>
      <tr>
         <td>Zmije</td>
         <td class="center">500</td>
         <td>P�id� 5 bod� zran�n� jedem.</td>
      </tr>
      <tr>
         <td>Kobry</td>
         <td class="center">1000</td>
         <td>P�id� 8 bod� zran�n� jedem.</td>
      </tr>
      <tr>
         <td>Ch�est��e</td>
         <td class="center">2000</td>
         <td>P�id� 12 bod� zran�n� jedem.</td>
      </tr>
      <tr>
         <td>Vamp�r�</td>
         <td class="center">500</td>
         <td>Vys�v� �ivoty z ob�ti.</td>
      </tr>
      <tr>
         <td>Zotaven�</td>
         <td class="center">200</td>
         <td>Zkracuje dobu zotaven�.</td>
      </tr>
      <tr>
         <td>Imunity</td>
         <td class="center">1000</td>
         <td>Nositel odoln� nemocem.</td>
      </tr>
      <tr>
         <td>Rozumu</td>
         <td class="center">1000</td>
         <td>Nositel odoln� ��lenstv�.</td>
      </tr>
      <tr>
         <td>Svobody</td>
         <td class="center">2000</td>
         <td>Nositel odoln� ochromen�.</td>
      </tr>
      <tr>
         <td>Protijed�</td>
         <td class="center">1000</td>
         <td>Nositel odoln� jedu.</td>
      </tr>
      <tr>
         <td>Poplachu</td>
         <td class="center">500</td>
         <td>Nositel odoln� usp�n�.</td>
      </tr>
      <tr>
         <td>Med�zy</td>
         <td class="center">2000</td>
         <td>Nositel odoln� zkamen�n�.</td>
      </tr>
      <tr>
         <td>Brutality</td>
         <td class="center">500</td>
         <td>Zvy�uje odra�en�.</td>
      </tr>
      <tr>
         <td>Moci</td>
         <td class="center">2500</td>
         <td>+5 �rovn�.</td>
      </tr>
      <tr>
         <td>Vzduchu</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie vzduchu.</td>
      </tr>
      <tr>
         <td>T�la</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie t�la.</td>
      </tr>
      <tr>
         <td>�ern� magie</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel �ern� magie.</td>
      </tr>
      <tr>
         <td>Zem�</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie zem�.</td>
      </tr>
      <tr>
         <td>Ohn�</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie ohn�.</td>
      </tr>
      <tr>
         <td>B�l� magie</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel B�l� magie.</td>
      </tr>
      <tr>
         <td>Mysli</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie mysli.</td>
      </tr>
      <tr>
         <td>Ducha</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie ducha.</td>
      </tr>
      <tr>
         <td>Vody</td>
         <td class="center">2000</td>
         <td>Zvy�uje ��inek v�ech kouzel magie vody.</td>
      </tr>

      <tr>

         <td>Zlod�j�</td>
         <td class="center">2000</td>
         <td>Zvy�uje chmat�ckou �anci.</td>
      </tr>
      <tr>
         <td>Za�t�t�n�</td>
         <td class="center">1000</td>
         <td>Polovi�n� zran�n� ze st�eln�ch zbran�.</td>
      </tr>
      <tr>
         <td>Regenerace</td>
         <td class="center">1000</td>
         <td>Dopl�uje pr�b�n� body zdrav�.</td>
      </tr>
      <tr>
         <td>Many</td>
         <td class="center">1000</td>
         <td>Dopl�uje pr�b�n� body many.</td>
      </tr>
      <tr>
         <td>D�mon� kat</td>
         <td class="center">500</td>
         <td>Dvojn�sobn� zran�n� proti d�mon�m.</td>
      </tr>
      <tr>
         <td>Dra�� zhouba</td>
         <td class="center">500</td>
         <td>Dvojn�sobn� zran�n� proti drak�m.</td>
      </tr>
      <tr>
         <td>Temnot</td>
         <td class="center">1000</td>
         <td>Vys�v� �ivoty z ob�ti a zvy�uje rychlost zbran�.</td>
      </tr>
      <tr>
         <td>Zhouby</td>
         <td class="center">750</td>
         <td>+1 k vlastnostem zdrav�, man�, t��d� zbroje a odolnostem.</td>
      </tr>
      <tr>
         <td>Zem�</td>
         <td class="center">2000</td>
         <td>+10 Odolnost, t��da zbroje a zdrav�.</td>
      </tr>
      <tr>
         <td>�ivota</td>
         <td class="center">2000</td>
         <td>+10 zdrav� a dopl�uje pr�b�n� body zdrav�.</td>
      </tr>
      <tr>
         <td>Lotr�</td>
         <td class="center">500</td>
         <td>+5 Rychlost a P�esnost.</td>
      </tr>
      <tr>
         <td>Draka</td>
         <td class="center">3000</td>
         <td>P�id�v� 10-20 bod� zran�n� ohn�m a +25 s�ly.</td>
      </tr>
      <tr>
         <td>Zatm�n�</td>
         <td class="center">2000</td>
         <td>+10 many a dopl�uje pr�b�n� body many.</td>
      </tr>
      <tr>
         <td>Golema</td>
         <td class="center">1500</td>
         <td>+15 Odolnost a +5 t��da zbroje.</td>
      </tr>
      <tr>
         <td>M�s�ce</td>
         <td class="center">1000</td>
         <td>+10 Intelekt a �t�st�.</td>
      </tr>
      <tr>
         <td>F�nixe</td>
         <td class="center">3000</td>
         <td>+30 odolnost proti ohni a dopl�uje pr�b�n� body zdrav�.</td>
      </tr>
      <tr>
         <td>Nebes</td>
         <td class="center">2500</td>
         <td>+10 many, Rychlosti a Intelektu.</td>
      </tr>
      <tr>
         <td>Hv�zd</td>
         <td class="center">1000</td>
         <td>+10 Odolnost a P�esnost.</td>
      </tr>
      <tr>
         <td>Slunce</td>
         <td class="center">1000</td>
         <td>+10 S�la a Osobnost.</td>
      </tr>
      <tr>
         <td>Trol�</td>
         <td class="center">1500</td>
         <td>+15 Odolnost a dopl�uje pr�b�n� body zdrav�.</td>
      </tr>
      <tr>
         <td>Jednoro�ce</td>
         <td class="center">1500</td>
         <td>+15 �t�st� a dopl�uje pr�b�n� body many.</td>
      </tr>
      <tr>
         <td>V�le�n�k�</td>
         <td class="center">500</td>
         <td>+5 S�la a Odolnost.</td>
      </tr>
      <tr>
         <td>M�g�</td>
         <td class="center">500</td>
         <td>+5 Intelekt a Osobnost.</td>
      </tr>
      <tr>
         <td>Staro�itnosti</td>
         <td class="center">4500</td>
         <td>Zv��en� hodnota.</td>
      </tr>
      <tr>
         <td>Hbitosti</td>
         <td class="center">500</td>
         <td>Zv��en� rychlost zbran�.</td>
      </tr>
   </table>
   </div>
   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
