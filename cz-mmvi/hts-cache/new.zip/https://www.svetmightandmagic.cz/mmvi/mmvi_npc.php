<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin: 15px 15px 15px 15px;}
      td {padding: 2px;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Naj�m�n� NPC</h2>
   
   <p>Naj�m�n� NPC, neboli Non Player Character (nehern�ch charakter�), je pro Might and Magic typick�. Jejich p��tomnost pom�h� zejm�na v po��tku hry nebo u nevyv�en�ch dru�in, proto�e s jejich p��tomnost� v dru�in� se zvy�uj� ur�it� dovednosti nebo dru�iny mohou vyu��vat magick�ch dovednost� t�chto postav (nap�. kouzla L�t�n� a Ch�ze po vod�). V�t�ina NPC v�ak vy�aduje p�ed najmut�m ur�it� poplatek a krom povol�n� lupi�e bude po�adovat ur�it� obnos z ka�d�ho mno�stv� nalezen�ho zlata. N�kter� NPC se tak mohou dru�in� zna�n� prodra�it.</p>
   <p>Na druhou stranu budete do dru�iny moci najmout i takov� NPC, kter� v�m nebudou poskytovat ��dn� bonus, ale tak� po v�s nebudou cht�t poplatek. Pat�� sem aristokrat, bedn��, d�ln�k, farm��, hr��, hrn���, kamen�k, krej��, lovec ko�e�in, mision��, mlyn��, n�sledovn�k Baa, nevoln�k, p�sa�, poskok, sedl�k, str�, �a�ek, �vec, tesa�, tkadlec, ��edn�k, zeman, zlod�j dobytka a �ebr�k.</p>
   <p>N�sleduj�c�ch n�kolik tabulek je rozd�leno podle skupin bonus�, kter� obsa�en� NPC poskytuj�. V p��pad� NPC s v�ce bonusy je uva�ov�n jen ten hlavn�. Naleznete je mezi obyvateli venku v �ad� oblast� nebo v domech. U voln� se pohybuj�c�ch obyvatel plat�, �e prakticky ka�d�ho m��ete najmout. Ov�em um�st�n� voln� se pohybuj�c�ch NPC neni striktn� v�z�no na p��slu�nou lokaci, tak�e je nenajdete v�dy na stejn�m m�st�. M�n� se nap�. s ka�dou novou hrou, p�i opu�t�n� oblasti apod. Oproti tomu NPC v domech z�st�vaj� st�le stejn� (viz <a href="mmvi_npclokace.php">NPC k najmut� v domech</a>). Jakmile je nebudete nad�le v dru�in� pot�ebovat, m��ete je propustit. NPC se nezapojuj� do bitev a ani nejsou monstry zra�ov�na, nemus�te se o n� tedy nijak starat. Ohledn� seznam� nezaru�uji, �e soupis je kompletn�, sna�il jsem se naj�t v�echny, ale t�ko ��ct, nakolik jsem byl �sp�n�.</p>
   
   <h4>Obchodov�n� a finance</h4>
   
   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">kupec</td>
         <td style="width: 350px">4 body k dovednosti obchodov�n�</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>obchodn�k</td>
         <td>6 bod� k obchodov�n�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>�ejd��</td>
         <td>8 bod� k obchodov�n�, reputace klesne o jednu kategorii</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>jednatel</td>
         <td>bonus 10% k nalezen�m zlat�m</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>bank��</td>
         <td>bonus 20% k nalezen�m zlat�m</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>J�dlo</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">nosi�</td>
         <td style="width: 350px">spot�eba j�dla se b�hem t�bo�en� sn��� o 1 j�dlo</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>ubytovatel</td>
         <td>spot�eba j�dla se b�hem t�bo�en� sn��� o 2 j�dla</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>cik�n</td>
         <td>sn��en� spot�eba j�dla b�hem odpo�inku, obchodov�n� se zv��� o 3 body, reputace se sn��� o jednu kategorii</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kucha� </td>
         <td>vyrob� jedno j�dlo denn� (max na 14 dn�)</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>��fkucha�</td>
         <td>vyrob� dv� j�dla denn� (max na 14 dn�)</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Cestov�n�</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">pr�vodce</td>
         <td style="width: 350px">pohyb po map� je o 1 den rychlej��</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>stopa�</td>
         <td>pohyb po map� je o 2 dny rychlej��</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>pr�kopn�k</td>
         <td>pohyb po map� je o 3 dny rychlej��</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>jezdec</td>
         <td>cestov�n� ko�mo se zkr�t� o 2 dny</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>pir�t</td>
         <td>cesty lod� se o 2 dny zkr�t�, bonus 10% k nalezen�m zlat�m, reputace klesne o jednu kategorii</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>n�mo�n�k</td>
         <td>cesty lod� se o 2 dny zkr�t�</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>navig�tor</td>
         <td>cesty lod� se o 3 dny zkr�t�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>badatel</td>
         <td>v�echny cesty se o 1 den zkr�t�</td>
         <td>bere 1% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Kouzeln�ci</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">mistr Vody</td>
         <td style="width: 350px">jednou denn� vykouzl� kouzlo Ch�ze po vod� po dobu 3 hodin</td>
         <td style="width: 130px">bere 10% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mistr Vzduchu</td>
         <td>jednou denn� vykouzl� kouzlo L�t�n� po dobu 2 hodin</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mistr Port�l�</td>
         <td>jednou denn� vykouzl� kouzlo M�stsk� br�na na mistrovsk� �rovni</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kartograf</td>
         <td>kouzlo �arod�jovo oko na expertn� �rovni je trvale aktivn�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>akolyta</td>
         <td>jednou denn� vykouzl� kouzlo Po�ehn�n� na mistrovsk� �rovni po dobu 2 hodin</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>dud�k</td>
         <td>jednou denn� vykouzl� kouzlo Hrdinstv� po dobu 2 hodin na mistrovsk� �rovni</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>fel�ar</td>
         <td>jednou denn� vyl��� cel� dru�in� body zdrav�</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>expert fel�ar</td>
         <td>jednou denn� vyl��� cel� dru�in� body zdrav� a proklet� (krom� smrti a zkamen�n�)</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mistr fel�ar</td>
         <td>jednou denn� vyl��� celou dru�inu</td>
         <td>bere 50% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Zbroj��i</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">mistr zbran�</td>
         <td style="width: 350px">2 body k dovednostem se zbran�mi</td>
         <td style="width: 130px">bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>zbroj��</td>
         <td>dovednosti ve zbrani a zbroji se zv��� o 2 body</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mistr zbroj��</td>
         <td>3 body k dovednostem se zbran�mi</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Identifikace a opravov�n�</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">u�enec</td>
         <td style="width: 350px">neomezen� identifikace p�edm�t�, +5% k z�skan�m zku�enostem</td>
         <td style="width: 130px">bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>alchymista</td>
         <td>neomezen� oprava magick�ch p�edm�t�</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>kov��</td>
         <td>neomezen� oprava zbran�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>zbroj��</td>
         <td>neomezen� oprava zbroje</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
   </table>

   <h4>Bonusy k magick�m dovednostem postav</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">u�e�</td>
         <td style="width: 350px">2 body ke v�em magick�m dovednostem</td>
         <td style="width: 130px">bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mystik</td>
         <td>3 body ke v�em magick�m dovednostem</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>mistr kouzel</td>
         <td>4 body ke v�em magick�m dovednostem</td>
         <td>bere 20% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Bonusy k diplomacii, reputace a zku�enosti</h4>
   
   <p>Na reputaci maj� vliv i dal�� NPC, kter� jsou uvedena v jin�ch bonusech. Obvykle se toti� jedn� o vedlej�� efekt, najmut� takov� postavy reputaci sn��� o jednu kategorii (cik�ni, pir�ti, �ejd��i, lupi�i). Reputaci zvy�uje jen bard. Na mno�stv� z�skan�ch zku�enost� m� vliv i u�enec.</p>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">poradce</td>
         <td style="width: 350px">4 body k diplomacii</td>
         <td style="width: 130px">bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>advok�t</td>
         <td>8 bod� k diplomacii</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>bard</td>
         <td>zvy�uje reputaci o jednu kategorii</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>u�itel</td>
         <td>bonus 10% k z�skan�m zku�enostem</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>instruktor</td>
         <td>bonus 15% k z�skan�m zku�enostem</td>
         <td>bere 7% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Bystrost a odstran�n� past�</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">pr�zkumn�k</td>
         <td style="width: 350px">6 bod� k bystrosti</td>
         <td style="width: 130px">bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>z�me�n�k</td>
         <td>6 bod� k odpas�ov�n�</td>
         <td>bere 3% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>okultista</td>
         <td>5 bod� k bystrosti</td>
         <td>bere 4% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>klemp��</td>
         <td>4 body k odpas�ov�n�</td>
         <td>bere 5% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>lupi�</td>
         <td>8 bod� k odpas�ov�n�, reputace kles� o jednu kategorii</td>
         <td>nebere nic z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <h4>Bonusy k vlastnostem (�t�st�, odolnosti)</h4>

   <table width="550px" cellspacing="0" cellpadding="0" border="0">
      <tr>
         <td style="width: 70px">bl�zen</td>
         <td style="width: 350px">bonus 5 bod� ke �t�st�</td>
         <td style="width: 130px">bere 1% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>komin�k</td>
         <td>bonus 20 bod� ke �t�st�</td>
         <td>bere 2% z nalezen�ch zlat�ch</td>
      </tr>
      <tr>
         <td>zakl�na�</td>
         <td>v�echny 4 element�rn� ochrany se zv��� trvale o 20 bod�</td>
         <td>bere 10% z nalezen�ch zlat�ch</td>
      </tr>
   </table>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
