<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Respawn map</h2>
   <p>&nbsp;</p>
   <p>N�sleduj�c� tabulka ukazaje tzv. respawn map. Proto�e tento pojem nemus� b�t ka�d�mu z�ejm�, uvedu ve stru�nosti o� se jedn�. Ka�d� mapa, kter� se ve h�e vyskytuje, m� nastaven� ur�it� po��te�n� stav (monstra, obnoviteln� zdroje, existenci ur�it�ch postav a jejich chov�n� apod.). Jak se hrou pohybujete, doch�z� ke zm�n�m v tomto stavu. Typick�m p��kladem je zab�jen� nestv�r. Ka�d� mapa m� tedy krom po��te�n�ch podm�nek nastaven� i �as, za kter� se n�vr�t� do p�vodn�ho stavu (ten nemus� b�t striktn� toto�n� s po��te�n�mi podm�nkami). V praxi to pozn�te nejz�eteln�ji tak, �e se na ji� vy�i�t�n�ch m�stech op�t objev� p�vodn� nestv�ry. �as do respawnu je po��t�n �ist� jen jako �as ub�hl� ve h�e. B�hem respawnu se i tak��kaj�c vyma�e pam�t NPC, co� m� velk� praktick� v�znam. Pokud n�koho napadnete, tak si to dan� NPC nebude po t�to dob� ji� pamatovat.</p>

   <div style="text-align: center;">
   
   <h4>Oblasti</h4>
   
   <table width="400px" cellspacing="0" cellpadding="0" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 200px;">Oblast</td>
         <td style="width: 200px;">Respawn (dn�)</td>
      </tr>
      <tr>
         <td>Blackshire</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Dobr� voda</td>
         <td>224</td>
      </tr>
      <tr>
         <td>Dra�� p�sky</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Hrad Ironfist</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Kriegspire</td>
         <td>224</td>
      </tr>
      <tr>
         <td>Ml�n� ostrovy</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Mo��l proklet�ch</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Mraziv� vrchovina</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Nov� Sorpigal</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Poustevn�k�v ostrov</td>
         <td>168</td>
      </tr>
      <tr>
         <td>Rajsk� �dol�</td>
         <td>168</td>
      </tr>
      <tr>
         <td>St��brn� z�toka</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Svobodn� p��stav</td>
         <td>672</td>
      </tr>
      <tr>
         <td>�ho�� vody</td>
         <td>224</td>
      </tr>
      <tr>
         <td>Z�toka pa�er�k�</td>
         <td>224</td>
      </tr>
   </table>
   </div>
   
   <div style="text-align: center;">
   
   <h4>Dungeony</h4>

   <table width="400px" cellspacing="0" cellpadding="0" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 200px;">Dungeon</td>
         <td style="width: 200px;">Respawn (dn�)</td>
      </tr>
      <tr>
         <td>Agarova laborato�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Ar�na</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Corlagonovo panstv�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Dra�� doup�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Gharikova kov�rna</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Goblin� hl�ska</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrad Alamos</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrad Darkmoor</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrad Kriegspire</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrobka Erika ��len�ho</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Hrobka VARN</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m Baa</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m hada</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m M�s�ce</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m ��du P�sti</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m Slunce</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Chr�m Tsantsa</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Jeskyn� dra��ch jezdc�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Jeskyn� Dragoun�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Kontroln� centrum</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Monolit</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Nejvy��� chr�m Baa</td>
         <td>672</td>
      </tr>
      <tr>
         <td>New World Computing</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Opu�t�n� chr�m</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Or�kulum Enrothu</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Pevnost d�mon�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Pevnost Dragoun�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Pevnost Icewind</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Pevnost St��brn�ch helem</td>
         <td>672</td>
      </tr>
      <tr>
         <td>S�dlo P�na ohn�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Snerglovy jeskyn�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Snerglovy �elezn� doly</td>
         <td>672</td>
      </tr>
      <tr>
         <td>St�nov� gilda</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Stoky Svobodn�ho p��stavu</td>
         <td>672</td>
      </tr>
      <tr>
         <td>�kryt St�nov� gildy</td>
         <td>672</td>
      </tr>
      <tr>
         <td>�l</td>
         <td>7</td>
      </tr>
      <tr>
         <td>Vl�� doup�</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Vojev�dcova pevnost</td>
         <td>672</td>
      </tr>
      <tr>
         <td>V�spa St��brn�ch helem</td>
         <td>672</td>
      </tr>
      <tr>
         <td>Vy��� chr�m Baa</td>
         <td>672</td>
      </tr>
   </table>
   </div>
   
   <p>Mus�m je�t� zm�nit jednu podstatnou v�c. Ve sv�t� Might and Magic trv� hern� m�s�c 28 dn�, tedy rok m� celkem jen 336 dn�.</p>

   <p>&nbsp;</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
