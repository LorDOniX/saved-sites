<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">
   <h2>Mapy oblast� a dungeon�</h2>
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="0" border="1" width="600px" style="margin: auto; border: 0px;">
      <tr class="hlavicka_tabulky">
         <td style="width: 300px;">Oblasti</td>
         <td style="width: 300px;">Dungeony</td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvi_mapy.php?mapa=oblast01">Nov� Sorpigal</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon01">Goblin� hl�ska</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon02">Opu�t�n� chr�m</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon03">Gharikova kov�rna</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5"><a href="mmvi_mapy.php?mapa=oblast02">Hrad Ironfist</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon04">Jeskyn� Dragoun�</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon05">�kryt St�nov� gildy</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon06">Chr�m Baa</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon07">Corlagonovo panstv�</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon08">Snerglovy jeskyn�</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=oblast03">Ml�n� ostrovy ( Mist )</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon09">V�spa St��brn�ch helem</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="4"><a href="mmvi_mapy.php?mapa=oblast04">Z�toka pa�er�k�</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon10">S�dlo P�na ohn�</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon11">Chr�m ��du P�sti</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon12">Chr�m Tsantsa</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon13">Chr�m Slunce</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="6"><a href="mmvi_mapy.php?mapa=oblast05">Svobodn� p��stav</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon14">Stoky Svobodn�ho p��stavu</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon15">Pevnost Dragoun�</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon16">Hrobka Erika ��len�ho</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon17">Chr�m M�s�ce</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon18">Or�kulum Enrothu</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon19">Kontroln� centrum</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvi_mapy.php?mapa=oblast06">Mo��l proklet�ch</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon20">Hrad Darkmoor</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon21">Snerglovy �elezn� doly</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon22">Dra�� doup�</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3"><a href="mmvi_mapy.php?mapa=oblast07">St��brn� z�toka</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon23">Pevnost St��brn�ch helem</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon24">Vojev�dcova pevnost</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon25">Monolit</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvi_mapy.php?mapa=oblast08">Mraziv� vrchovina ( B�l� �apka)</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon26">Pevnost Icewind</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon27">St�nov� gilda</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="5"><a href="mmvi_mapy.php?mapa=oblast09">Kriegspire</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon28">Hrad Kriegspire</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon29">Pevnost d�mon�</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon30">Nejvy��� chr�m Baa</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon31">Jeskyn� dra��ch jezdc�</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon32">Agarova laborato�</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvi_mapy.php?mapa=oblast10">Blackshire</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon33">Chr�m hada</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon34">Vl�� doup�</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="2"><a href="mmvi_mapy.php?mapa=oblast11">Dra�� p�sky</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon35">Hrobka VARN</a></td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=dungeon36">Tajn� NWC dungeon</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=oblast12">Poustevn�k�v ostrov</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon37">Vy��� chr�m Baa</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=oblast13">�ho�� vody</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon38">Hrad Alamos</a></td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=oblast14">Rajsk� �dol�</a></td>
         <td>-</td>
      </tr>
      <tr>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
         <td><a href="mmvi_mapy.php?mapa=oblast15">Dobr� voda</a></td>
         <td><a href="mmvi_mapy.php?mapa=dungeon39">�l</a></td>
      </tr>
   </table>
   </div>
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
