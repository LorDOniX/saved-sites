<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Um�st�n� u�itel�</h2>
   <p>&nbsp;</p>
   <div style="text-align: center;">
   
   <table cellspacing="0" cellpadding="0" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">Dovednost</td>
         <td style="width: 150px;">�rove�</td>
         <td style="width: 150px;">U�itel</td>
         <td style="width: 150px;">Um�st�n�</td>
      </tr>
      <tr>
         <td rowspan="3">Me�</td>
         <td rowspan="2">expert</td>
         <td>Michael Ogillvy</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>Aaron Strongmun</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Guy Hampton</td>
         <td>Blackshire</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Sekera</td>
         <td rowspan="2">expert</td>
         <td>Stephen Biggs</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Conie Lettering</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Avinril Smythers</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Palc�t</td>
         <td rowspan="2">expert</td>
         <td>Dickson Parks</td>
         <td>B�l� �apka</td>
      </tr>
      <tr>
         <td>Jack Crow</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Errol Ostermann</td>
         <td>Blackshire</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">N��</td>
         <td rowspan="2">expert</td>
         <td>Logan Dasher</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>Terrance Smith</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Jules Miles</td>
         <td>B�l� �apka (hrad Stone)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Kop�</td>
         <td rowspan="2">expert</td>
         <td>Gonzalo Ramirez</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td>Sigriv</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Burton Rutherford</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">H�l</td>
         <td rowspan="2">expert</td>
         <td>Dorf</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Calvin Black</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Jasper Rice</td>
         <td>St��brn� z�toka (vzadu za hospodou na ostrov�)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Lukost�elba</td>
         <td rowspan="2">expert</td>
         <td>Helen Teal</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Jed Morrison</td>
         <td>B�l� �apka</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Desmond Weller</td>
         <td>Kriegspier (na hrad�)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Starobyl� zbran�</td>
         <td rowspan="2">expert</td>
         <td>Igor</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Pat Skylark</td>
         <td>�ho�� vody</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Rexella</td>
         <td>Rajsk� �dol�</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">no�en� ko�en� zbroje</td>
         <td rowspan="2">expert</td>
         <td>Newt Headrow</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Arthur O�Leery</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Arlen Sailor</td>
         <td>B�l� �apka (hrad Stone)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">no�en� krou�kov� zbroje</td>
         <td rowspan="2">expert</td>
         <td>Rich Hamburg</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Preston Harper</td>
         <td>Z�toka pa�er�k�</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>David Feather</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">no�en� pl�tov� zbroje</td>
         <td rowspan="2">expert</td>
         <td>Benito Telmann</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Woodrow Albright</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Forrest Suthers</td>
         <td>Svobodn� p��stav (hrad Temper)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">obrana se �t�tem</td>
         <td rowspan="2">expert</td>
         <td>Edgar Carpenter</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Takao</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Bronwyn Meck</td>
         <td>Blackshire</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie Ohn�</td>
         <td rowspan="2">expert</td>
         <td>Isao Magistrus</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Jack Van Imp</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Jezebel</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie Vzduchu</td>
         <td rowspan="2">expert</td>
         <td>Cheryl Duncan</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Zodahn Delphi</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Caao Salem</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie Vody</td>
         <td rowspan="2">expert</td>
         <td>Douglas Hill</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Hitomi Mirumoto</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Harper Collins</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie Zem�</td>
         <td rowspan="2">expert</td>
         <td>Taro</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Li Tizare</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Revee Botania</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie Ducha</td>
         <td rowspan="2">expert</td>
         <td>Enoch Highridge</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Michele Blackshire</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Bishop Inquisitorio</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie Mysli</td>
         <td rowspan="2">expert</td>
         <td>Virgil Holiday</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Mynasia</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Thane Roper</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Magie T�la</td>
         <td rowspan="2">expert</td>
         <td>Abdulai Mahgreb</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Tim O�Hoolihan</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Gilbert Hammer</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">B�l� magie</td>
         <td rowspan="2">expert</td>
         <td>Tina Sheltan</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td>Nicholas Roth</td>
         <td>Kriegspiere</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Ki Lo Nee</td>
         <td>Alamos</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">�ern� magie</td>
         <td rowspan="2">expert</td>
         <td>Ambrose Bruse</td>
         <td>Blackshire</td>
      </tr>
      <tr>
         <td>Morton Holovin</td>
         <td>B�l� �apka</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Su Lang Manchu</td>
         <td>Rajsk� �dol�</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Bystrost</td>
         <td rowspan="2">expert</td>
         <td>Tara D�Cathay</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Shoshi Pertoniki</td>
         <td>Z�toka pa�er�k�</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Macro Caligula</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Odstra�ov�n� past�</td>
         <td rowspan="2">expert</td>
         <td>Tyler Tailor</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Ivan Magyar</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Gabe Lester</td>
         <td>B�l� �apka (hrad Stone)</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Oprav��</td>
         <td rowspan="2">expert</td>
         <td>Cyrus Montebleu</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td>Bernard Jacobs</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Ryan Treacle</td>
         <td>B�l� �apka</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Obchodn�k</td>
         <td rowspan="2">expert</td>
         <td>Livia Farrel</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>Casey Ludwig</td>
         <td>Mo��l proklet�ch</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Will Ottoman</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Meditace</td>
         <td rowspan="2">expert</td>
         <td>Victor Hosen</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Clyde Dagget</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Norio Ariganaka</td>
         <td>Mist</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Vzd�l�v�n�</td>
         <td rowspan="2">expert</td>
         <td>Donald Retzer</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Elton Astrogate</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>John Tuck</td>
         <td>St��brn� z�toka</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Identifikace</td>
         <td rowspan="2">expert</td>
         <td>Sheila Loompus</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Leon Lazaru</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Hans Gifford</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Posilov�n�</td>
         <td rowspan="2">expert</td>
         <td>Erik Salzburg</td>
         <td>Nov� Sorpigal</td>
      </tr>
      <tr>
         <td>Olaf Berring</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Jason Traveler</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td colspan="4">&nbsp;</td>
      </tr>
      <tr>
         <td rowspan="3">Diplomacie</td>
         <td rowspan="2">expert</td>
         <td>Walter Hargreaves</td>
         <td>Hrad Ironfist</td>
      </tr>
      <tr>
         <td>Sylvester Moore</td>
         <td>Svobodn� p��stav</td>
      </tr>
      <tr>
         <td>mistr</td>
         <td>Jacques Kohl</td>
         <td>B�l� �apka (hrad)</td>
      </tr>
   </table>
   
   </div>
   <p>&nbsp;</p>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
