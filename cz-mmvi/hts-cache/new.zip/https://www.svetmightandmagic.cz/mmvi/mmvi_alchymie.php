<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 20px; border: 1px solid maroon;}
      td {text-align: left; border: none; text-indent: 0px; padding: 4px;}
     .popis {text-align: justify;}
     .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Lektvary</h2>
   <p>&nbsp;</p>

   <p>Might and Magic 6 nezn� dovednost alchymie jako takovou. Ka�d� postava je od p��rody schopna vyr�b�t a m�chat lektvary a to bez ohledu na povol�n� a dosa�enou �rove�. V podstat� by se dalo ��ci, �e v �est�m d�le byly polo�eny z�klady t�to dovenosti, kter� se pak pln� rozvinuly v d�lech n�sleduj�c�ch. Tedy vyjma dev�t�ho d�lu, kde mo�nost tvorby lektvar� op�t zmizela. Nez�vislost tvorby lektvar� na postav� je ve skute�nosti velmi v�hodn�. Krom toho, �e lektvary maj� vy��� prodejn� cenu ne� ingredience, lze z�rove� hned v po��tku vytv��et velmi mocn� lektvary v�etn� esenc� s trval�m bonusem.</p>
   <p>Z�kladn� ingredience jsou jen t�i - brusinky, Phirnin ko�en a petrkl��. Brusinky poskytuj� z�kladn� �erven� lektvar Hojen� ran, Phirnin ko�en z�kladn� modr� Magick� lektvar a petrkl�� z�kladn� �lut� lektvar Energie. Jejich vz�jemnou kombinac� z�sk�me t�i jednoduch� m�chan� lektvary. Sm�ch�n�m jednoduch�ch m�chan�ch lektvar� a z�kladn�ch lektvar� obdr��me b�l� lektvary. Kombinac� b�l�ch lektvar� se z�kladn�mi nebo jednoduch�mi m�chan�mi lektvary vznikaj� lektvary �ern�. �ada �ern�ch lektvar� poskytuje trval� bonus k z�kladn�m vlastnostem postav (zvy�uje trvale hodnotu ur�it�ho atributu). Na opl�tku v�ak sn��� velikost jin�/jin�ch vlastnost�. �ern� lektvary s p��vlastkem "bo�sk�" pak obvykle po po�it� zvy�uj� st��� postavy.</p>
   
   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item01.png" width="40px" height="40px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Petrkl��</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� bylina neobvykl�ch vlastnost�, jej�� hlavi�ky mohou b�t po�ity k v�rob� lektvar�. (K pou�it� seberte bylinu a prav�m tla��tkem my�i klikn�te na pr�zdnou l�hev na lektvary.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>2</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item02.png" width="31px" height="43px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Phirnin ko�en</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� bylina neobvykl�ch vlastnost�.  Phirnin ko�en m��e b�t po�ity k v�rob� lektvar�. (K pou�it� seberte bylinu a prav�m tla��tkem my�i klikn�te na pr�zdnou l�hev na lektvary.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>3</td>
      </tr>
   </table>

   <table cellspacing="0" cellpadding="2" border="0" width="500px" style="margin: 15px 35px;">
      <tr>
         <td rowspan="3" style="width: 150px;" class="pravy"><img src="obrazky/alchymie/item03.png" width="36px" height="33px" /></td>
         <td style="width: 80px;">N�zev:</td>
         <td style="width: 270px;">Brusinky</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Magick� bylina neobvykl�ch vlastnost�, kter� m��e b�t po�ita k v�rob� lektvar�. (K pou�it� seberte bylinu a prav�m tla��tkem my�i klikn�te na pr�zdnou l�hev na lektvary.</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>4</td>
      </tr>
   </table>
   
   <p>Existuje �ada mo�n�ch kombinac� lektvar�, ale jen p�r jich je spr�vn�ch. V ��dn�m p��pad� se nepokou�ejte m�chat lektvary stejn�ch vlastnost�. Ne�sp�n� kombinace kon�� v�buchem a jeho s�la je z�visl� na stupni nejvy���ho pou�it�ho lektvaru. Po v�buchu siln�j�� sm�si by mohlo doj�t a� k vym�cen� postavy.</p>

   <h3>Z�kladn� lektvary</h3>

   <h5>Hojen� ran</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle26.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Obnov� 10 �ivot�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Brusinky</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>
   
   <h5>Magick� lektvar</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle23.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Obnov� 10 many.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Phirnin ko�en</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>
   
   <h5>Energie</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle28.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�i�te 10 k prim�rn�m vlastnostem.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Petrkl��</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>10</td>
      </tr>
   </table>
   
   <h3>Jednoduch� kombinace z�kladn�ch lektvar�</h3>
   
   <h5>Odolnost</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle24.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�i�te 10 k odolnostem.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + Energie</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>25</td>
      </tr>
   </table>
   
   <h5>L��ba otravy</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle29.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Vyl��� otravu.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + Hojen� ran</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>25</td>
      </tr>
   </table>
   
   <h5>Ochrana</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle25.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�i�te 10 k t��d� zbroje.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Energie + Hojen� ran</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>25</td>
      </tr>
   </table>
   
   <h3>B�l� lektvary</h3>

   <h5>Super odolnost</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�id� 20 k dolnostem.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + Odolnost</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Po�ehn�n�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Prop�j�� Po�ehn�n� (jako kouzlo) na 6 hodin.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + L��ba otravy</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Kamenn� k��e</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Prop�j�� Kamennou k��i (jako kouzlo) na 6 hodin.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + Ochrana</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Zrychlen�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Prop�j�� Rychlost (jako kouzlo) na 6 hodin.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Energie + Odolnost</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Extr�mn� energie</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�ite 20 k prim�rn�m vlastnostem.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Energie + Ochrana</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Hrdinstv�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Prop�j�� Hrdinstv� (jako kouzlo) na 6 hodin.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hojen� ran + Ochrana</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Zotaven�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Vyl��� v�echny stavy mimo smrti a zkamen�n�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Odolnost + L��ba otravy</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h5>Maxim�ln� ochrana</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle27.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�i�te 20 k t��d� zbroje.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Odolnost + Ochrana</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>50</td>
      </tr>
   </table>
   
   <h3>�ern� lektvary</h3>
   
   <h5>Esence Intelektu</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k Intelektu a ode�te 5 od S�ly.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + Kamenn� k��e</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Esence Osobnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k Osobnosti a ode�te 5 od Rychlosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Magick� lektvar + Zotaven�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Esence P�esnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k P�esnosti a ode�te 5 od �t�st�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Energie + Po�ehn�n�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Esence Odolnosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k Odolnosti a ode�te 1 ode v�ech ostatn�ch vlastnost�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Energie + Maxim�ln� ochrana</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Esence Rychlosti</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k Rychlosti a ode�te 5 od Osobnosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hojen� ran + Zrychlen�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Esence S�ly</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k S�le a ode�te 5 od Intelektu.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Hojen� ran + Hrdinstv�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Esence �t�st�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Pouze jedenkr�t: Trvale p�i�te 15 k �t�st� a ode�te 5 od P�esnosti.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>L��ba otravy + Super odolnost</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Bo�sk� magie</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�i�te 100 many (do maxima) a p�id� 1 rok st���.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Odolnost + Super odolnost</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Bo�sk� s�la</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�echodn� p�i�te 20 k �rovni a p�id� 1 rok st���.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>L��ba otravy + Extr�mn� energie</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Bo�sk� l��ba</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">P�ite 100 �ivot� (do maxima) a p�id� 1 rok st���.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Ochrana + Zotaven�</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>
   
   <h5>Omlazen�</h5>
   <table cellspacing="0" cellpadding="0" border="0" width="500px">
      <tr>
         <td rowspan="3" style="width: 100px;" class="pravy"><img src="obrazky/alchymie/bottle22.png" width="36px" height="65px" alt="" /></td>
         <td style="width: 50px;">��inek:</td>
         <td style="width: 350px;">Odstran� v�echny magick� st�rnouc� efekty a ode�te 1 ode v�ech 7 prim�rn�ch vlastnost�.</td>
      </tr>
      <tr>
         <td>V�roba:</td>
         <td>Odolnost + Extr�mn� energie</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>100</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
