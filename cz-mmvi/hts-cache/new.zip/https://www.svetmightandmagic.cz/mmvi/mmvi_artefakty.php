<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      table {margin-left: 15px;}
      td {text-align: left; border: none; text-indent: 5px;}
      .popis {text-align: justify;}
      .pravy {border-right: solid 1px maroon; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Artefakty</h2>
   <p>&nbsp;</p>
   
   <p><span class="tucne">Dodatek zima 2010/2011:</span> N�sleduj�c� seznam artefakt� obsahuje stejn� jako ostatn� p�edm�ty v sekc�ch origin�ln� popisky p��mo ze hry. Ov�em p�ekladatel� se m�sty dopustili men��ch chybek v nejednotnosti n�zvoslov� a tak n�kter� vlastnosti p�edm�t� mohou p�sobit trochu zmaten�. Nam�sto vlastnosti Odolnost je zde pou�it pojem V�dr�, nam�sto Rychlosti je to Hbitost a Odolnosti proti element�m jsou pou�ity ve zkr�cen� form� jako Ochrana (u relikvi� je tomu zas o trochu jinak). Naproti tomu u efektu Zlod�jstv� se mi nepoda�ilo jeho ��inek objasnit (dovednost Zlod�jstv� neboli Kraden� nen� v �est�m d�le nav�c v�bec implementov�na). Efekt Up��� je pops�n jako stav, kdy jsou p�i �sp�n�m z�sahu p�en�eny body zdrav� na nositele. Efekt Bo�sk� zna�� +10 k z�kladn�m vlastnostem a efekt Masakr se d� p�irovnat k sesl�n� kouzla ohniv� koule. Efekt �t�t by mohl zna�it podobu s kouzlem �t�t, ale nepoda�ilo se mi to nijak ov��it. Podobn� je tomu u efekt� posiluj�c�ch ur�itou skupinu magick�ch dovednost�, kdy nelze ��ci, o kolik tyto dovednosti opravdu zvedaj�, resp. jak�m zp�sobem v�bec tyto dovednosti zvy�uj�. Ostatn� efekty by pak u� m�ly b�t z popisk� jasn�, nap�. bonusy k z�sahu ur�it� skupiny nestv�r nebo rychlej�� zotaven� ze z�sahu.</p>
   
   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/99.png" width="42px" height="27px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Arthur</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">V jejich nekone�n� snaze o vytvo�en� perfektn�ho Kn�ze-Kr�le stvo�ili kn�� C�rkve Slunce Arthura a prodchli ho silou zv��it nositelovu osobn� schopnost, stejn� jako z�skat v�ce magick� energie. Fungovalo to, zvy�uj�ce moc jejich kr�le -- a jeho p�chu. V roce 1073, Leopold VII. za�al svatou v�lku proti rival�m v C�rkvi M�s�ce, rozdrcuj�ce ob� organizace do chudoby a kone�n� vedouce k jejich z�niku. (Speci�ln� s�ly: 'Bo�sk�' a +25 Mana)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/30.png" width="52px" height="266px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Conan</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d7+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tato mocn� sekyra je o�arov�na ke zni�en� drak� a ��bl�. Zn� zp�soby, jak "naj�t" majitele, kter� pravd�podobn� na takov� stv�ry naraz� a je dostate�n� siln�, aby s nimi bojoval. (Speci�ln� s�ly: Zab�jen� d�mon� a drak�)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/11.png" width="38px" height="184px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Excalibur</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>3d4+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">T�k�, a� zd�nliv� lehk� jako p�rko v devedn�ch ruk�ch, Excalibur sv�mu majiteli prop�j�uje velkou s�lu. R�ny ud�len� touto legend�rn� zbran� m��e p�e��t opravdu jen m�lokdo. (Speci�ln� s�ly: +30 S�la)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/75.png" width="135px" height="151px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Galahad</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+38</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Snad nejlep�� krou�kov� brn�n� vyroben� od Ticha, �arovn� s�la Galahadov�ch materi�l� je tak siln�, �e se ��ste�n� p�en�� na nositelovo t�lo, umo��uj�c� mu vydr�et mnohem v�ce ne� norm�ln�. (Speci�ln� s�ly: Ochrana a +25 �ivot�)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/122.png" width="34px" height="37px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Guinevere</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Guinevere byl vytvo�en Alchymistickou gildou pod kameny hradu Kriegspire p�ed mnoha lety. Zvy�uje magick� zdroje pou�iteln� jeho nositelem a usnad�uje pou�it� kouzel Zrcadlov� cesty. (Speci�ln� s�ly: +30 Mana, 'B�l� magie' a '�ern� magie') </td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/129.png" width="38px" height="42px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Igraine</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Lord Solomon Stone m�l tento prsten vybrat b�hem sv� dr�by ��adu Velekn�ze Cesty v 1018. Prsten zvy�uje u�ivatelovu schopnost v klerik�ln� magii. (Speci�ln� s�ly: +25 Mana a 'magie du�e, mysli a t�la')</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/119.png" width="57px" height="65px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Lucius</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+14</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Nikdo nev�, kde byly tyto magick� boty vyrobeny, ale mnoh� p��b�hy o nich vypr�v�j�, jak se zjevili na nejneobvyklej��ch m�stech. Sv�mu nositeli prop�j�uj� nadlidskou rychlost a p�vab pohybu. (Speci�ln� s�ly: +30 S�la)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/63.png" width="77px" height="288px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Merlin</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d4+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�vodn� pou��van� Arcidruidem, ale ztracen� b�hem sv�r� okolo n�bo�ensk� doktr�ny, Merlin se chov� jako rezervo�r kouzeln� s�ly, kterou majitel m��e kdykoliv �erpat. Nav�c je o�arov�n hbitost�, tak�e r�ny na nep��tele jen pr��, mnohem rychleji ne� u oby�ejn� hole. (Speci�ln� s�ly: Hbitost a +40 Mana)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/22.png" width="37px" height="136px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Mordred</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+8</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d3+8</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Jedno z dev�ti takov�ch ost�� na sv�t�, Mordred byl vyroben Bratrstvem v roce 428 P. T. jako ��st jejich prvn�ch experiment� s v�vojem �ern� magie. Jejich nad�j� bylo naj�t cestu k prodlou�en� jednoho lidsk�ho �ivota za cenu jin�ho, ale m�sto ot��en� v�k� sotva na�li cestu, jak kr�st zdrav�. (Speci�ln� s�ly: up���)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/134.png" width="35px" height="75px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Morgan</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�esto�e je Morgan�v p�vod nezn�m�, m�l v posledn�ch stech letech mnoho majitel�, o nikom z nich ale nikdo p�ed jeho nalezen�m nic nesly�el. Amulet je toti� tak mocn�, �e ve skute�nosti ka�d� d�t� pas�ka, kter� na n�j polo�� sv� ruce, m� jistotu, �e se ur�it� stane legendou sv� doby. (Speci�ln� s�ly: +20 Mana a 'magie ohn�, vzduchu, vody a zem�')</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/78.png" width="137px" height="204px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pellinore</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+56</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Pojmenov�na po starod�vn�m ryt��i, Pellinore zlep�uje nositelovu odolnost, tak�e se ten l��� z v�n�ch zran�n� ji� v pr�b�hu hodin. Zbroj je celkem t�k� a chr�n� nositele od z�sah� b�hem boje. (Speci�ln� s�ly: +30 V�dr�, zotaven� ze z�sahu a regenerace �ivot�)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/109.png" width="81px" height="20px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Pendragon</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+11</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Tento plṻ p�vodn� pat�il Alastairovi Blanovi, Mistrovi zlod�jovi z Gildy St�n�. Plṻ v�born� zvy�oval jeho �t�st� a ur�it� zlod�jsk� dovednosti, umo��uj�ce mu dos�hnout dlouh� prosperuj�c� kari�ry. Blane nebyl nikdy pohn�n p�ed soud za sv� zlo�iny -- byl m�sto toho zavra�d�n p�i kart�ch za podv�d�n�. (Speci�ln� s�ly: +30 �t�st�, Zlod�jstv�, Imunita p�ed jedem)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/46.png" width="46px" height="229px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Percival</td>
      </tr>
      <tr>
         <td>St�elba:</td>
         <td>+10</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>5d2+10</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Percival vznikl v Lu�i�tnick� gild� v roce 912 P. T. jako prototyp nov� zbran�, kterou tehdy vyv�jeli. Nane�t�st� v gildovn� s�ni propukl podez�el� ohe�, ni��c v�vojov� pl�ny a exotick� materi�ly pot�ebn� k tvorb� dal��ch Percival�. Gilda se ze sv�ch ztr�t nikdy nevzpamatovala a Percivala v roce 918 P. T. prodala elf�m. Od t� doby u� mnohokt�t zm�nil majitele. (Speci�ln� s�ly: Hbitost a Masakr)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/57.png" width="39px" height="141px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Thor</td>
      </tr>
      <tr>
         <td>�tok:</td>
         <td>+12</td>
      </tr>
      <tr>
         <td>Zran�n�:</td>
         <td>2d5+12</td>
      </tr>
      <tr>
         <td colspan="2" class="popis">P�vod Thoru je sice ztracen v �ase, ale tato mocn� barbarsk� zbra� byla pou��v�na v mnoh�ch bitv�ch mnoha majiteli po stalet�, naposledy v bitv� u Shimengardu v roce 902 P. T. S�la �deru tohoto kladiva je tak siln�, �e m��e odhodit nep��tele n�kolik stop daleko od majitele. (Speci�ln� s�ly: S�la)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>

   <table cellspacing="0" cellpadding="2" border="0" width="550px">
      <tr>
         <td rowspan="5" style="width: 150px;" class="pravy"><img src="obrazky/artefakty/88.png" width="72px" height="78px" /></td>
         <td style="width: 80px;">Jm�no:</td>
         <td style="width: 270px;">Valeria</td>
      </tr>
      <tr>
         <td>Zbroj:</td>
         <td>+20</td>
      </tr>
      <tr>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td colspan="2" class="popis">Schv�leno kr�lem Davidem IV. z Erathie b�hem V�lek o d�evo, Valeria za�tituje u�ivatele nejen p�ed norm�ln�mi ranami, ale pom�h� mu zadr�et mnoho p�il�taj�c�ch ��p� t�m, �e magicky zaost�� nositelovu pozornost na let projektilu. To sam� o�arov�n�, kter� umo��uje �t�tov� efekt, tak� enormn� zvy�uje nositelovu p�esnost (Speci�ln� s�ly: �t�t a +30 P�esnost)</td>
      </tr>
      <tr>
         <td>Cena:</td>
         <td>20000</td>
      </tr>
   </table>

   <p>&nbsp;</p>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
