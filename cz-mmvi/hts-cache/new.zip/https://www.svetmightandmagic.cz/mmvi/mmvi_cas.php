<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Hern� �as</h2>
   <p>&nbsp;</p>
   
   <p>�asov� �sek ve sv�t� Might and Magic neodr�� p��mo n� re�ln� �as, ale je oproti n�mu �m�rn� zrychlen�, co� je vcelku pochopiteln�. V p�epo�tu trv� 1 hern� minuta p�esn� 2 vte�iny na�eho re�ln�ho �asu, tedy naopak b�hem 1 minuty na�eho �asu uplyne ve h�e 30 hern�ch minut. Jeden hern� den pak ub�hne za na�ich 48 minut. Stejn� jako v realit� m� i ve sv�t� Might and Magic den 24 hodin.</p>
   <p>Rozd�l je v�ak v po��t�n� kalend��n�ho �asu, proto�e kalend�� se ��d� lun�rn�m cyklem a ka�d� m�s�c ve h�e tak m� jen 28 dn�, tedy p�esn� 4 t�dny. Znalost f�z� M�s�ce m� svou v�znamnou �lohu p�i �e�en� n�kter�ch �kol� nebo p�i orientaci v pou��v�n� n�kter�ch bonusov�ch p�edm�t�. Na po��tku m�s�ce je samotn� M�s�c v Novu a tato f�ze trv� 3 dny. N�sleduj�c� 4 dny pak M�s�c z�st�v� v 1/4, dal�� 3 dny je pak v 1/2 a pak je po 4 dny ve 3/4. 15-t�m dnem za��n� �pln�k a ten setrv�v� celkem 3 dny. Po��naje 18-t�m dnem se cel� cyklus obrac� a M�s�c za�ne ve stejn�ch �asov�ch intervalech couvat a� op�t na po��tku dal��ho m�s�ce dos�hne Novu. Graficky je to zn�zorn�no na n�sleduj�c�m obr�zku.</p>
   
   <div style="text-align: center;">
      <img src="obrazky/mesice.png" width="600px" height="87px" alt="" />
   </div>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
