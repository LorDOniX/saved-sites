<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
      p.center {text-align: center;}
      h2 {text-indent: 0px; text-align: center;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Prolog</h2>
   <p>&nbsp;</p>
   
   <p>Jak je tomu u Might and Magic standardem, hra za��n� velmi poveden�m intrem, kter� v�m p�ibl��� po��tek invaze Kreegan� a z�chranu va�� dru�iny dobrodruh� z obsazen� Dobr� vody. Pokud zrovna neovl�date angli�tinu, neni t�eba zoufat, d�ky Ravenovi nyn� m�te mo�nost si p�e��st �esk� p�eklad �vodn�ho videa.</p>
   
   <p  class="kurziva">P�i�li z hlubin nicoty. Prad�vn� nep��tel prad�vn�ch lid�. Nikdo u� dnes nev�, pro� n�s tak nen�vid� a vlastn� ani pro� proti n�m vyhl�sili v�lku. N�kte�� ��kaj�, �e boj s t�mto zlem poch�z� p��mo z v�le boh�. A�koliv je jejich p�vod a z�m�r zahalen tajemstv�m, jejich pl�n je jednoduch� - p�ij�t, obsadit a dob�t. Te� jsou zde, v na�em sv�t�, aby n�s zni�ili jako mnoh� p�ed n�mi. A oni to ud�laj� ... pokud je n�kdo nezastav�.</p>

   <p class="kurziva">(hrdinka): Pod�vejte ... vid�m cestu!</p>

   <p class="kurziva">(hrdinka): Falagare!</p>

   <p class="kurziva">(Falagar): Poj�te se mnou. Mus�te se toho je�t� mnoho nau�it, ne� se jim budete moci postavit. Av�ak nezvan� host� u� p�ich�zej�, hnustn� stv�ry a zl� du�e se potuluj� po kraji. Tyto znamen� mohou m�t ale i jin� v�znam. Mo�n� zna�� v�s osud - vzep��t se v�li nebes!</p>
   
   <p>Samotn� prolog se objev� a� pot�, co si vytvo��te svou dru�inu a p�ipoj�te se ke h�e. Ve stru�nosti v�m p�ibl��� ve�ker� podstatn� ud�losti, kter� p�edch�zely va�emu vlastn�mu putov�n� za z�chranou Enrothu.</p>
   
   <p class="center">Pot�, co se ti poda�ilo uniknout smrti za Noci<br /> padaj�c�ch hv�zd, zjistil jsi, �e se nach�z�� tak<br /> daleko od Dobr� vody, jak t� jen Falagarova<br /> magie dok�zala p�en�st.</p>
   <p class="center">T�i l�ta uplynula od t� doby, kdy ti Falagar<br /> sd�lil v jak�ch dovednostech tv�ho povol�n�<br /> t� m��e vycvi�it.</p>
   <p class="center">Ale ten �as, kdy u� t� nemohl nau�it v�ce,<br /> nakonec nastal a ty ses kone�n� odv�il vydat<br /> do sv�ta za sv�m vlastn�m dobrodru�stv�m a<br /> sl�vou.</p>
   <p class="center">A v tom, daleko p�edaleko od vlastn�ho<br /> domova jsi n�hodou narazil na d�kazy o<br /> stra�liv�m spiknut�, do kter�ho je zapleten<br /> nov� n�bo�ensk� kult.</p>
   <p class="center">P�t dopis� kr�le Rolanda jeho �en� Catherine<br /> a dopis Kr�le ��bl� proklet�mu zr�dci<br /> jmn�nem Sulman jsi objevil v opu�t�n�m<br /> goblin�m t�bo�i�ti.</p>
   <p class="center">Tv�j osud, jak se zd�, je neodd�liteln� spjat s<br /> t�mito dopisy a stra�livou Noc�, a tv� role v<br /> nadch�zej�c�ch ud�lostech m��e b�t mnohem v�t��,<br /> ne� by si kdokoli dok�zal p�edstavit.<br /> Za��n� jen s m�lem, s hrstkou zlat�ch,<br /> vlastn�m d�vtipem a horou schopnost�. Cest<br /> p�ed tebou je nekone�n� -- v�e m� jen ve<br /> sv�ch vlastn�ch ruk�ch.</p>
   <p class="center">Hodn� �t�st�</p>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
