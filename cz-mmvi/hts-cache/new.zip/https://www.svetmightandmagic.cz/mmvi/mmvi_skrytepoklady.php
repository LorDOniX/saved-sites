<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
         p {margin-left: 20px;}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Skryt� poklady</h2>
   
   <p>Bylo by s podivem, kdyby Might and Magic 6 neobsahoval podobn� jako jin� RPG hry bonusy v podob� skryt�ch poklad�. K nim se obvykle hr�� dostane sp��e d�lem n�hody, proto�e se schov�vaj� za podobu b�n�ch p�edm�t� a mnohdy jsou velmi dob�e ukryty. Jedn� se nap�. o lou�e, kusy sk�ly nebo plastiky v dungeonech. N�sleduj�c� seznam je p�evzat z webu <A href="http://members.aol.com/tenernie/Misc/Hidden.html">http://members.aol.com/tenernie/Misc/Hidden.html</a>. O jeho zpracov�n� a pe�liv� ov��en� (v�etn� zakreslen� do map) se postaral KILLER.</p>
   
   <h3>Nov� Sorpigal</h3>
   
   <p><span class="tucne">Oblast Nov�ho Sorpigalu:</span> Kus sk�ly (A) na pob�e�� je ve skute�nosti truhla.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/o01.jpg" width="385px" height="386px" />
   </div>
   
   <p><span class="tucne">Goblinn� hl�ska:</span> V�chodn� st�na chodby (1) obsahuje zbroj.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/01.jpg" width="500px" height="153px" />
   </div>
   
   <p><span class="tucne">Opu�t�n� chr�m:</span> Obsahuje celkem dva skryt� poklady. Klece uvnit� mu��rny (1) obsahuj� kouzeln� svitky a neozna�en� lou� (2) na zdi generuje n�hodn� o�arovan� prsten. Lou�i objevil Keeper (1.5.2015) - jedn� se o sedmou lou�i v po�ad� sm�rem od vstupu do tunelu.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/02.jpg" width="565px" height="350px" />
   </div>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/33.jpg" width="195px" height="263px" />
   </div>
   
   <p><span class="tucne">Gharrikova kov�rna:</span> Ve st�n�ch m�stnosti s ��slem 13 se nach�zej� schovan� knihy kouzel (tip od johny.mullera, podzim 2017).</p>

   <div style="margin-top: 15px; padding: 5px; text-align: center;">
<img src="obrazky/sk_oblasti/34.jpg" width="259px" height="347px" />
   </div>
   
   <h3>Hrad Ironfist</h3>
   
   <p><span class="tucne">Oblast Hradu Ironfist:</span> Strom (A) vedle str�n� ukr�v� svitek s kouzlem D鹻 meteorit�.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/o02.jpg" width="384px" height="385px" />
   </div>
   
   <p><span class="tucne">Jeskyn� dragoun�:</span> Plastika na zdi (1) na severn� stran� chodby (pobl�� truhly s fl�tnou) p�id�v� +10 �t�st� jedn� postav�. Truhla, kter� obsahuje Rozkazy gildy St�n� (2) p�i druh�m otev�en� obsahuje dal�� zlato a vybaven�.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/04.jpg" width="351px" height="404px" />
   </div>
   
   <p><span class="tucne">Corlagonovo panstv�:</span> Plastika kostlivce (1) vysoko ve v�klenku na zdi je ve skute�nosti truhla. Lze ji otev��t pomoc� kouzla Telekineze nebo pomoc� kouzla Skok s rozeb�hem.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/05.jpg" width="359px" height="470px" />
   </div>
   
   <p><span class="tucne">Chr�m Baa:</span> Lou� (1) na ji�n� stran� chodby p�id�v� 5 000 zlat�ch.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/06.jpg" width="421px" height="486px" />
   </div>
   
   <p><span class="tucne">�kryt St�nov� gildy:</span> Jakmile po z�chran� Sharry dungeon opust�te, dojde uvnit� k men��m zm�n�m - ve v�zen� (1) se objev� sudy s magickou tekutinou.</p>
   <!--<p><span class="tucne">(Edit: jaro 2012):</span> Na z�klad� Templayerovo p�ipom�nky v Knize n�v�t�v byl dopln�n bod 2 - v ohni�ti krbu lze nal�zt n�hodn� generovan� prsten.</p>-->
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/07.jpg" width="327px" height="437px" />
   </div>
   
   <h3>Z�toka pa�er�k�</h3>
   
   <p><span class="tucne">Chr�m Slunce:</span> Ka�d� z lou�� (1-4) obsahuje svitek s kouzlem Slune�n� paprsek.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/13.jpg" width="338px" height="190px" />
   </div>
   
   <h3>Mist</h3>
   
   <p><span class="tucne">V�spa St��brn�ch helem:</span> Prost�edn� lavice (1) v kapli na lev� stran� obsahuje knihu s kouzlem Ledov� hrot.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/09.jpg" width="402px" height="468px" />
   </div>
   
   <h3>Kriegspire</h3>
   
   <p><span class="tucne">Hrad Kriegspire:</span> Ka�d� z lou�� (1-2) p�i okraj�ch obsahuje 15 000 zlat�ch.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/28.jpg" width="378px" height="284px" />
   </div>
   
   <p><span class="tucne">Agarova laborato�:</span> Ka�d� ze t�� lustr� (1-3) obsahuje po jednom kusu diamantu.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/32.jpg" width="217px" height="396px" />
   </div>
   
   <h3>B�l� �apka</h3>
   
   <p><span class="tucne">Pevnost Icewind:</span> Ob� pochodn� (1) na st�n�ch sm�rem k pokoj�m m��ou p�idat do invent��e velmi dobrou pokr�vku hlavy, ale p�id� ji jen ta lou�, na kterou kliknete prvn�. Ta druh� u� pot� nebude fungovat.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/26.jpg" width="266px" height="351px" />
   </div>
   
   <h3>St��brn� z�toka</h3>
   
   <p><span class="tucne">Pevnost St��brn�ch helem:</span> Lavice (1) na prav� stran� (�elem k olt��i) obsahuje Mocnou h�l.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/23.jpg" width="397px" height="462px" />
   </div>
   
   <p><span class="tucne">Vojev�dcova pevnost:</span> Slavnost� pochode� (1) v rohu s�lu obsahuje velmi dobrou sekeru.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/24.jpg" width="488px" height="368px" />
   </div>
   
   <p><span class="tucne">Monolit:</span> V �vodn� m�stnosti (1) je nutn� kliknout na men�� k�men a pak na v�t�� k�men a to opakovat celkem 6x. Posledn� klik pak p�id� velmi dobr� �t�t, velmi dobr� boty a knihu s kouzlem Spla�en� p�st.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/25.jpg" width="487px" height="506px" />
   </div>
   
   <h3>(Ne)ov��en� poklady</h3>
   
   <p>N�sleduj�c� trojici skryt�ch poklad� se poda�ilo ov��it a� pozd�ji, chyb� jen Chr�m Tsantsa (jsou jinak takt� sou�ast� seznamu uveden�ho v odkazu v �vodu).</p>
   
   <p><span class="tucne">Gharrikova kov�rna (Nov� Sorpigal):</span> (24.04.2015, do�e�eno - Keeper) Jakmile spust�te most p�es l�vu a posunete p�ku zp�t do p�vodn� polohy (nen� to nutn� a ani to nemus� j�t), tak po kliknut� nad horn� r�m dve�� nad mostem, z�sk� aktu�ln� postava +25 k odolnosti proti ohni trvale.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/18.jpg" width="640px" height="480px" />
   </div>
   
   <p><span class="tucne">Chr�m Tsantsa (Z�toka pa�er�k�):</span> Je to podobn� zm�n� v �krytu St�nov� gildy. Pot� co opust�te dungeon po z�chran� Sherrel, tak se v jej�m b�val�m v�zen� maj� objevit sudy s magickou tekutinou.</p>
   
   <p><span class="tucne">Stoky Svobodn�ho p��stavu (Svobodn� p��stav):</span> (25.02.2010, do�e�eno - Elemir) Tato ��st navazuje na zn�m� teleport existuj�c� uvnit� Vy���ho chr�mu Baa, kter� v�s po vstupu na n�j transportuje do Stok pod Svobodn�m p��stavem. Pokud ho m�te v chr�mu ji� aktivovan�, tak u v�chodu pobl�� bodu 1 ve stok�ch se ve zdi nach�z� tajn� dve�e, kter� vedou do m�stnosti s teleportem. Jakmile na n�j vstoup�te, objev� se v�zva, zda-li chcete stoky opustit. Pokud jste v�ak teleport ve Vy���m chr�mu je�t� neaktivovali, tak se nic nestane.</p>
   
   <div style="margin-top: 15px; padding: 5px; text-align: center;">
      <img src="obrazky/sk_oblasti/14.jpg" width="512px" height="299px" />
   </div>
   
   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
