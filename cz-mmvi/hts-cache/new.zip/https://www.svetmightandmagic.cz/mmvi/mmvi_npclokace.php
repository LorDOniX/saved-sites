<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>NPC postavy k najmut� v domech</h2>
   <p>&nbsp;</p>
   
   <p>Jak u� bylo v p�edchoz� kapitole �e�eno, NPC postavy k najmut�, kter� jsou obyvateli dom�, se b�hem hry nem�n�. To plat� i o tom, kdy postavu z dru�iny propust�te - ta se pak jednodu�e vr�t� zas do sv�ho domu. V�hodou t�chto postav tedy je, �e je naleznete v�dy na stejn�m m�st� a m��ete se na to spolehnout (samoz�ejm� tohle lze u voln� se pohybuj�c�ch NPC obej�t nap�. pomoc� triku se save/load, ale nebudeme si p�eci kazit hru :)). Nev�hodou je, �e ta u�ite�n�j�� povol�n� naleznete a� ve v�t��ch m�stech. V Nov�m Sorpigalu �ij� nap�. jen dv� NPC v domech a to je�t� na t�ko p��stupn�m m�st� (severn� ostrov). O NPC v domech jinak plat� tot�, co o voln� se pohybuj�c�ch NPC.</p>
   <p>V n�sleduj�c�m p�ehledu jsem se pokusil pou��t upraven� zv�t�eniny mapek, n�kdy to neni zcela ide�ln�, ale snad se v nich neztrat�te. Tam, kde by mapka byla a� p��li� nesrozumiteln� jsem um�st�n� postav popsal jen slovn� (nap�. hrad Kriegspire), nebo jsem popis mapky zna�n� zjednodu�il (nap�. vesnice pod hradem Darkmoor).</p>

   <h4>Nov� Sorpigal - severn� ostrov</h4>
   
   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/01.jpg" width="485px" height="356px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Orville Corvair</td>
         <td>u�enec</td>
         <td>2</td>
         <td>Naomi Highland</td>
         <td>fel�ar</td>         
      </tr>
   </table>
   </div>

   <h4>Hrad Ironfist - vesnice</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/02.jpg" width="247px" height="196px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Gordon Styles</td>
         <td>zbroj��</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>

   <h4>Z�toka pa�er�k� - vesnice</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/03.jpg" width="245px" height="248px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Stephanie Pavlov</td>
         <td>mision��</td>
         <td>3</td>
         <td>Svetlanta Irktusk</td>
         <td>mistr kouzel</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Jean Acton</td>
         <td>jednatel</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>

   <h4>Z�toka pa�er�k� - severn� ostrov</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/04.jpg" width="247px" height="280px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Cody Ripper</td>
         <td>zeman</td>
         <td>6</td>
         <td>Linda Nichols</td>
         <td>u�e�</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Kachiko Toranaga</td>
         <td>bard</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>

   <h4>Ml�n� ostrovy - Mist</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/13.jpg" width="492px" height="441px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Kathleen Mester</td>
         <td>mystik</td>
         <td>3</td>
         <td>Hugger Brother</td>
         <td>n�mo�n�k</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Myyra Hian</td>
         <td>okultista</td>
         <td>4</td>
         <td>Selena Stipe</td>
         <td>pir�t</td>
      </tr>
   </table>
   </div>

   <h4>Svobodn� p��stav</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/05.jpg" width="629px" height="612px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Cheryl Ahmanson</td>
         <td>tkadlec</td>
         <td>13</td>
         <td>Nikobi</td>
         <td>pr�zkumn�k</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Richard Harp</td>
         <td>kupec</td>
         <td>14</td>
         <td>Rosemarie Reyjavik</td>
         <td>obchodn�k</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Chitania Retiani</td>
         <td>hrn���</td>
         <td>15</td>
         <td>Beauregard Wolf</td>
         <td>�ejd��</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Stephen Iago</td>
         <td>obchodn�k</td>
         <td>16</td>
         <td>Lori Tao</td>
         <td>n�sledovn�k Baa</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Iris Poppyfield</td>
         <td>bard</td>
         <td>17</td>
         <td>Fabian Sun</td>
         <td>ubytovatel</td>
      </tr>
      <tr>
         <td>6</td>
         <td>Heidi Strumper</td>
         <td>aristokrat</td>
         <td>18</td>
         <td>Hans Schultz</td>
         <td>mystik</td>
      </tr>
      <tr>
         <td>7</td>
         <td>Tor Brock</td>
         <td>hrn���</td>
         <td>19</td>
         <td>Ral</td>
         <td>tesa�</td>
      </tr>
      <tr>
         <td>8</td>
         <td>Amber Praetor</td>
         <td>bard</td>
         <td>20</td>
         <td>Donald Dorfus</td>
         <td>mistr kouzel</td>
      </tr>
      <tr>
         <td>9</td>
         <td>Sandra Trudoor</td>
         <td>n�sledovn�k Baa</td>
         <td>21</td>
         <td>Wilma Cook</td>
         <td>mistr port�l�</td>
      </tr>
      <tr>
         <td>10</td>
         <td>Doreen Espana</td>
         <td>��fkucha�</td>
         <td>22</td>
         <td>George Almond</td>
         <td>kamen�k</td>
      </tr>
      <tr>
         <td>11</td>
         <td>Mort Arnosti</td>
         <td>lovec ko�e�in</td>
         <td>23</td>
         <td>Isao Tizare</td>
         <td>d�t�</td>
      </tr>
      <tr>
         <td>12</td>
         <td>Lyle Roma</td>
         <td>aristokrat</td>
         <td>24</td>
         <td>Rexella Van Imp</td>
         <td>akolyta</td>
      </tr>
   </table>
   </div>

   <h4>Svobodn� p��stav - vesnice Rockham</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/06.jpg" width="333px" height="242px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>25</td>
         <td>Miriam Boyer</td>
         <td>mistr zbroj��</td>
         <td>26</td>
         <td>Lisa Janway</td>
         <td>bedn��</td>
      </tr>
   </table>
   </div>

   <h4>Mo��l proklet�ch - vesnice</h4>
   
   <p>Popsat jednoduch�m zp�sobem vesnici pod hradem Darkmoor nelze a to zejm�na d�ky tomu, �e je rozd�lena na p��zemn� ��st a patro. Koncentrace domk� je v n� tak vysok�, �e u nich nelze dost dob�e zobrazit popisky. Z tohoto d�vodu jsem n�kter� z nich slou�il v�dy pod jeden popisek a popiskem tak jen nazna�il, ve kter� ��sti vesnice p��slu�n� obyvatele hledat. Obecn� plat�, �e ��sla od 1 do 6 jsou pou�ity pro p��zem� (vyjma 3) a ��sla od 7 v��e pro patra. Patra jsou celkem dv� a jsou s p��zem�m spojena chodbami, kde lze t� nal�zt n�kolik domk� (jsou po��t�ny do p��zem�).</p>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/14.jpg" width="207px" height="253px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td rowspan="2">1</td>
         <td>Hugger Brother</td>
         <td>kupec</td>
         <td rowspan="2">6</td>
         <td rowspan="2">Lilly June</td>
         <td rowspan="2">mistr kouzel</td>
      </tr>
      <tr>
         <td>Ethel Armstrong</td>
         <td>p�sa�</td>
      </tr>
      <tr>
         <td rowspan="2">2</td>
         <td rowspan="2">Eva Semple</td>
         <td rowspan="2">instruktor</td>
         <td rowspan="2">7</td>
         <td>Gohei Matsu</td>
         <td>dud�k</td>
      </tr>
      <tr>
         <td>Indihir Vilandi</td>
         <td>nosi�</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Wendy Featherhill</td>
         <td>okultista</td>
         <td>8</td>
         <td>Beth Thompson</td>
         <td>mistr vody</td>
      </tr>
      <tr>
         <td rowspan="3">4</td>
         <td>Avilia Asheed</td>
         <td>pr�zkumn�k</td>
         <td rowspan="3">9</td>
         <td rowspan="3">Mihi Mihi Nanook</td>
         <td rowspan="3">d�ln�k</td>
      </tr>
      <tr>
         <td>Kern Carnegie</td>
         <td>mistr zbran�</td>
      </tr>
      <tr>
         <td>Flossie Setering</td>
         <td>hrn���</td>
      </tr>
      <tr>
         <td rowspan="4">5</td>
         <td>Stacy Flanders</td>
         <td>n�sledovn�k Baa</td>
         <td rowspan="4">10</td>
         <td rowspan="4">Dolores Craft</td>
         <td rowspan="4">kucha�</td>
      </tr>
      <tr>
         <td>Chandra Stripling</td>
         <td>sedl�k</td>
      </tr>
      <tr>
         <td>Belinda Pikeman</td>
         <td>kucha�</td>
      </tr>
      <tr>
         <td>Daphne Calloway</td>
         <td>poradce</td>
      </tr>
   </table>
   </div>

   <h4>Dra�� p�sky - o�za</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/15.jpg" width="206px" height="189px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td rowspan="2">1</td>
         <td>Noah White</td>
         <td>instruktor</td>
         <td rowspan="2">4</td>
         <td>Barrad Unter</td>
         <td>bank��</td>
      </tr>
      <tr>
         <td>Faith Kellenmoor</td>
         <td>obchodn�k</td>
         <td>Norris Horton</td>
         <td>advok�t</td>
      </tr>
      <tr>
         <td rowspan="2">2</td>
         <td>Jo Handlebaum</td>
         <td>mistr kouzel</td>
         <td rowspan="2">5</td>
         <td>Ian Trom</td>
         <td>kupec</td>
      </tr>
      <tr>
         <td>Naomi Wind</td>
         <td>mistr port�l�</td>
         <td>Darth Cartwright</td>
         <td>mistr zbroj��</td>
      </tr>
      <tr>
         <td rowspan="2">3</td>
         <td>Gertrude Whaler</td>
         <td>mistr vzduchu</td>
         <td rowspan="2">6</td>
         <td>Jason Duster</td>
         <td>zakl�na�</td>
      </tr>
      <tr>
         <td>Deliah Bwana</td>
         <td>mistr vody</td>
         <td>Paul Hapsburg</td>
         <td>mistr fel�ar</td>
      </tr>
   </table>
   </div>

   <h4>Blackshire</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/07.jpg" width="278px" height="367px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Stile Bloke</td>
         <td>mistr zbran�</td>
         <td>4</td>
         <td>David Pike</td>
         <td>jezdec</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Bejamin Sotherland</td>
         <td>jednatel</td>
         <td>5</td>
         <td>Lorn Hammer</td>
         <td>��fkucha�</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Leo Grant</td>
         <td>kucha�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>

   <h4>Kriegspire - vesnice Edenbrook</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/08.jpg" width="277px" height="214px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Carl Moramir</td>
         <td>mistr fel�ar</td>
         <td>6</td>
         <td>Sila Daewon</td>
         <td>instruktor</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Heather Mitchell</td>
         <td>vyjednava�</td>
         <td>7</td>
         <td>Eunbo Kim</td>
         <td>poradce</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Droppa MaPantz</td>
         <td>bl�zen</td>
         <td>8</td>
         <td>Rockwell Humdring</td>
         <td>expert fel�ar</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Rodinia Sidara</td>
         <td>dud�k</td>
         <td>9</td>
         <td>Ahmed A�sanzi</td>
         <td>pr�vodce</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Vance Cornelius</td>
         <td>u�itel</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>
   
   <p>By� by se mohlo zd�t, �e samotn� hrad Kriegspire je opu�t�n�, nen� tomu tak. Na hrad� krom u�itele mistrovstv� v luku bydl� je�t� 7 dal��ch postav, kter� si m��ete najmout. Naleznete je na jednotliv�ch "balk�nc�ch hradu, tak�e ide�ln� je ovl�dat kouzlo let.</p>
   
   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>-</td>
         <td>Larry Dorfman</td>
         <td>zbroj��</td>
         <td>-</td>
         <td>Drusis Tiberio</td>
         <td>u�enec</td>
      </tr>
      <tr>
         <td>-</td>
         <td>Joy Brown</td>
         <td>kov��</td>
         <td>-</td>
         <td>Iris Amble</td>
         <td>pr�vodce</td>
      </tr>
      <tr>
         <td>-</td>
         <td>Tracy Neather</td>
         <td>aristokrat</td>
         <td>-</td>
         <td>Candice Streep</td>
         <td>stopa�</td>
      </tr>
      <tr>
         <td>-</td>
         <td>Ty Cognac</td>
         <td>hr��</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>

   <h4>Rajsk� �dol�</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/16.jpg" width="282px" height="205px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Ta Li No Gharma</td>
         <td>mlyn��</td>
         <td>7</td>
         <td>Beverly Sweetwater</td>
         <td>u�enec</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Yvonne D�arcy</td>
         <td>kucha�</td>
         <td>8</td>
         <td>Miles Loman</td>
         <td>pr�kopn�k</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Wolf Armstrong</td>
         <td>fel�ar</td>
         <td>9</td>
         <td>Anthony Hargraine</td>
         <td>stopa�</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Tyger Helms</td>
         <td>navig�tor</td>
         <td>10</td>
         <td>Michael Tuck</td>
         <td>pr�vodce</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Florimel Evylen</td>
         <td>aristokrat</td>
         <td>11</td>
         <td>Ken Chomais</td>
         <td>alchymista</td>
      </tr>
      <tr>
         <td>6</td>
         <td>Zeke Magellan</td>
         <td>n�mo�n�k</td>
         <td>12</td>
         <td>Christian Vela</td>
         <td>u�enec</td>
      </tr>
   </table>
   </div>

   <h4>Mraziv� vrchovina - m�sto B�l� �apka</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/09.jpg" width="339px" height="256px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Peace Stringer</td>
         <td>nevoln�k</td>
         <td>7</td>
         <td>Shel Stineway</td>
         <td>pir�t</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Trevor Jones</td>
         <td>lupi�</td>
         <td>8</td>
         <td>Les Parker</td>
         <td>zeman</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Gerrold Dane</td>
         <td>sedl�k</td>
         <td>9</td>
         <td>Ray Boswell</td>
         <td>okultista</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Harper Nike</td>
         <td>�ejd��</td>
         <td>10</td>
         <td>Piter Harkonnen</td>
         <td>mistr port�l�</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Marc Teagan</td>
         <td>vyjdenava�</td>
         <td>11</td>
         <td>Abe Markoviac</td>
         <td>badatel</td>
      </tr>
      <tr>
         <td>6</td>
         <td>Sly Silverstone</td>
         <td>cik�n</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>
   
   <h4>Mraziv� vrchovina - hrad Stromgard</h4>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/10.jpg" width="195px" height="195px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>12</td>
         <td>Saul Fogg</td>
         <td>akolyta</td>
         <td>14</td>
         <td>Trent Jameson</td>
         <td>krej��</td>
      </tr>
      <tr>
         <td>13</td>
         <td>Arther Jelnic</td>
         <td>dud�k</td>
         <td>15</td>
         <td>Yves Meeks</td>
         <td>d�ln�k</td>
      </tr>
   </table>
   </div>

   <h4>Mraziv� vrchovina - hrad Stone</h5>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/11.jpg" width="252px" height="200px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>16</td>
         <td>Barry Shepherd</td>
         <td>bard</td>
         <td>19</td>
         <td>Josef Logger</td>
         <td>mistr vzduchu</td>
      </tr>
      <tr>
         <td>17</td>
         <td>Sharla Quinn</td>
         <td>mistr fel�ar</td>
         <td>20</td>
         <td>Jult Bandito</td>
         <td>mistr vody</td>
      </tr>
      <tr>
         <td>18</td>
         <td>Dom Malikto</td>
         <td>kartograf</td>
         <td>21</td>
         <td>Rosita Alexander</td>
         <td>aristokrat</td>
      </tr>
   </table>
   </div>

   <h4>St��brn� z�toka</h5>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/12.jpg" width="370px" height="354px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Carol Rossini</td>
         <td>��edn�k</td>
         <td>16</td>
         <td>Ginger Astor</td>
         <td>u�itel</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Hugger Brother</td>
         <td>z�me�n�k</td>
         <td>17</td>
         <td>Alice Ofenhauser</td>
         <td>advok�t</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Vera Grasslin</td>
         <td>bard</td>
         <td>18</td>
         <td>Jacques Roscomon</td>
         <td>bl�zen</td>
      </tr>
      <tr>
         <td>4</td>
         <td>Julie Cooper</td>
         <td>farm��</td>
         <td>19</td>
         <td>Cassandra Timmon</td>
         <td>akolyta</td>
      </tr>
      <tr>
         <td>5</td>
         <td>Miro Shinek</td>
         <td>jezdec</td>
         <td>20</td>
         <td>Egor Ivanovich</td>
         <td>komin�k</td>
      </tr>
      <tr>
         <td>7</td>
         <td>Ellen Rockway</td>
         <td>cik�n</td>
         <td>21</td>
         <td>Judith Shoemaker</td>
         <td>�vec</td>
      </tr>
      <tr>
         <td>8</td>
         <td>Jasmine Spicer</td>
         <td>expert fel�ar</td>
         <td>22</td>
         <td>Harriet Waters</td>
         <td>bedn��</td>
      </tr>
      <tr>
         <td>9</td>
         <td>Shiela Wind</td>
         <td>z�me�n�k</td>
         <td>23</td>
         <td>Anawah</td>
         <td>nosi�</td>
      </tr>
      <tr>
         <td>10</td>
         <td>Bronwyn Blue</td>
         <td>nosi�</td>
         <td>24</td>
         <td>Dolores Fisher</td>
         <td>stopa�</td>
      </tr>
      <tr>
         <td>11</td>
         <td>Hugger Brother</td>
         <td>komin�k</td>
         <td>25</td>
         <td>Nigan</td>
         <td>mistr zbran�</td>
      </tr>
      <tr>
         <td>12</td>
         <td>Graham Dancey</td>
         <td>advok�t</td>
         <td>26</td>
         <td>Kai Lian</td>
         <td>tkadlec</td>
      </tr>
      <tr>
         <td rowspan="2">13</td>
         <td rowspan="2">Hugger Brother</td>
         <td rowspan="2">komin�k</td>
         <td rowspan="2">27</td>
         <td>Castor Lithqow</td>
         <td>advok�t</td>
      </tr>
      <tr>
         <td>Melody Stone</td>
         <td>kartograf</td>
      </tr>
      <tr>
         <td>14</td>
         <td>Olivia Trumpet</td>
         <td>hrn���</td>
         <td>28</td>
         <td>Soon Lu</td>
         <td>mistr vody</td>
      </tr>
      <tr>
         <td>15</td>
         <td>Gretchen Fallzen</td>
         <td>krej��</td>
         <td>29</td>
         <td>Madeleine Towers</td>
         <td>obchodn�k</td>
      </tr>
   </table>
   </div>
   
   <p>Pozn�mka: Na z�pad od p��stavu se nach�z� maj�k, kde bydl� Daniel Forosmini (povol�n�m ubytovatel).</p>

   <h4>�ho�� vody - osada u hradu Alamos</h5>

   <div style="text-align: center; margin-top: 15px;">
      <img src="obrazky/npc/17.jpg" width="308px" height="228px" />
   </div>

   <div style="text-align: center; margin-top: 25px;">
   <table cellspacing="0" cellpadding="3px" border="0" width="600px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
         <td style="width: 40px">��slo</td>
         <td style="width: 130px">Jm�no postavy</td>
         <td style="width: 130px">Povol�n� postavy</td>
      </tr>
      <tr>
         <td>1</td>
         <td>Edna Harmenov</td>
         <td>d�ln�k</td>
         <td>4</td>
         <td>Shileka Toreena</td>
         <td>mistr vzduchu</td>
      </tr>
      <tr>
         <td>2</td>
         <td>Gail Ashtengard</td>
         <td>nevoln�k</td>
         <td>5</td>
         <td>Randall Norris</td>
         <td>navig�tor</td>
      </tr>
      <tr>
         <td>3</td>
         <td>Elijah Skylark</td>
         <td>d�t�</td>
         <td>-</td>
         <td>-</td>
         <td>-</td>
      </tr>
   </table>
   </div>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
