<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" >
<head>
   <title>Might and Magic VI</title>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
   <meta http-equiv="Content-Style-Type" content="text/css" />
   <meta name="description" content="V�tejte na Elemir�s Page, str�nk�ch v�novan�ch sv�tu Might and Magic a hr�m Crusaders of Might and Magic, Arcomage, Requiem, a Lords of Xulima." />
   <meta name="keywords" content="Might and Magic, MM, M&amp;M, 1, I, 2, II, 3, III, 4, IV, 5, V, 6, VI, 7, VII, 8, VIII, 9, IX, WoX, World of Xeen, SoX, Swords of Xeen, XEEN, Crusaders of Might and Magic, Arcomage, Requiem: Avenging Angel" />
   <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
   <link rel="stylesheet" href="../styl.css" type="text/css" />
   <style type="text/css">
         table {margin-left: 20px}
   </style>
</head>
<body>
<div id="hlavni">

   <div id="menu_horni">
      <div id="hnl">
         <div class="tlacitka_hnl"><a href="../mmi/mmi_index.php"><img src="../images/tl_mmi.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmii/mmii_index.php"><img src="../images/tl_mmii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmiii/mmiii_index.php"><img src="../images/tl_mmiii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmw/mmw_index.php"><img src="../images/tl_mmw.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mms/mms_index.php"><img src="../images/tl_mms.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvi/mmvi_index.php"><img src="../images/tl_mmvi_a.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmvii/mmvii_index.php"><img src="../images/tl_mmvii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmviii/mmviii_index.php"><img src="../images/tl_mmviii.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../mmix/mmix_index.php"><img src="../images/tl_mmix.png" /></a></div>
         <div class="tlacitka_hnl"><a href="../cmm/cmm_index.php"><img src="../images/tl_cmm.png" /></a></div>
      </div>
   </div>

   <div id="vnl">
      <div class="tlacitka_vnl"><a class="horni" href="../index.php">Hlavn� menu str�nek</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="mmvi_index.php">Obsah sekce</a></div>
      <div class="tlacitka_vnl"><a class="horni" href="../forum/index.php">F�rum</a></div>
      <div class="tlacitka_vnl_zadne"></div>
   </div>

   <div id="obsah">

   <h2>Kouzeln� knihy, svitky a h�lky</h2>
   <p>&nbsp;</p>
   
   <p>Cest, jak ve sv�t� Might and Magic pou��vat magii je hned n�kolik. M��ete vyu��vat o�arovan� p�edm�ty, kouzeln� h�lky nebo svitky s kouzly. Svitky maj� tu v�hodu, �e k jejich pou��v�n� postava nemus� ovl�dat p��slu�nou �kolu magie a mohou je tak pou��vat v�echna povol�n� bez rozd�lu. Svitky v�ak slou�� jen k jednor�zov�mu pou�it�, jakmile z n�j kouzlo zakouzl�te, svitek zmiz�. Podobn� je to i s h�lkami - po spot�ebov�n� n�boj� jsou tak� bezcen�.</p>
   <p>Ze svitk� postava ses�l� kouzlo v�dy tak, jakoby m�la v p��slu�n� magick� dovednosti 5 bod� a byla v n� na �rovni mistr. P�i pou��v�n� svitk� se nijak neuva�uje skute�n� velikost bod� postavy nebo �rove� dovednosti a proto i m�g s v�t�� hodnotou dovednosti ses�l� kouzlo se stejn�m efektem jako ryt�� bez znalosti dovednosti - tedy uveden�ch 5 bod� v �rovni mistr. U h�lek je to slo�it�j�� a zat�m jsem nena�el vhodn� kl�� pro v�po�et jejich efektu. Ka�dop�dn� ka�d� typ h�lek v sob� sm� ukr�vat jen kouzlo ur�it� �rovn� a narozd�l od svitk�, h�lky existuj� p�ibli�n� jen pro �tvrtinu kouzel (zejm�na �to�n�ch), viz tabulka na konci kapitoly.</p>
	 <p>K trval�mu nau�en� kouzla slou�� kouzeln� knihy. Kouzla jsou v �est�m d�le rozd�lena na norm�ln�, expertn� a mistrovskou �rove�, ale nijak to nesouvis� s pot�ebnou �rovn� dovednosti. Postava si zcela vysta�� s pohou znalost� p��slu�n� �koly magie. V�echna magick� povol�n� se tedy mohou ihned od po��tku u�it i kouzla mistrovsk� �rovn� a tak� je �sp�n� ses�lat.</p>
   <p>N�sleduj�c� tabulka ukazuje p�ehled vyobrazen� jednotliv�ch �rovn� svitk� a kouzeln�ch knih.</p>
   
   <div style="text-align: center;">
   <table cellspacing="0" cellpadding="3px" border="1" width="320px" style="margin: auto;">
      <tr class="hlavicka_tabulky">
         <td style="width: 120px;">�rove�</td>
         <td style="width: 100px;">Kniha</td>
         <td style="width: 100px;">Svitek</td>
      </tr>
      <tr>
         <td>Norm�ln�</td>
         <td><img src="obrazky/svitky/mmvi_kniha01.png" width="73px" height="62px" alt="" /></td>
         <td><img src="obrazky/svitky/mmvi_svitek01.png" width="67px" height="39px" alt="" /></td>
      </tr>
      <tr>
         <td>Norm�ln�</td>
         <td><img src="obrazky/svitky/mmvi_kniha02.png" width="72px" height="61px" alt="" /></td>
         <td><img src="obrazky/svitky/mmvi_svitek02.png" width="67px" height="40px" alt="" /></td>
      </tr>
      <tr>
         <td>Expertn�</td>
         <td><img src="obrazky/svitky/mmvi_kniha03.png" width="72px" height="53px" alt="" /></td>
         <td><img src="obrazky/svitky/mmvi_svitek03.png" width="70px" height="38px" alt="" /></td>
      </tr>
      <tr>
         <td>Expertn�</td>
         <td><img src="obrazky/svitky/mmvi_kniha04.png" width="72px" height="62px" alt="" /></td>
         <td><img src="obrazky/svitky/mmvi_svitek04.png" width="72px" height="37px" alt="" /></td>
      </tr>
      <tr>
         <td>Mistrovsk�</td>
         <td><img src="obrazky/svitky/mmvi_kniha05.png" width="72px" height="61px" alt="" /></td>
         <td><img src="obrazky/svitky/mmvi_svitek04.png" width="72px" height="37px" alt="" /></td>
      </tr>
   </table>
   </div>
   
   <p>Dal��ch 9 tabulek ukazuje p�ehled v�ech kouzeln�ch knih a svitk�, kter� ve h�e m��eme zakoupit nebo nal�zt, v�etn� ceny za jejich n�kup v gild�ch nebo magick�ch obchodech. K pou��v�n� svitk� nepot�ebujete zn�t p��slu�nou dovednost magie a cena svitku je v porovn�n� s cenou p��slu�n� kouzeln� knihy desetinov�.</p>

   <h3>Magie ohn�</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Pochode�</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Ohniv� ��p</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Ochrana p�ed ohn�m</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Ohniv� �ipka</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Zrychlen�</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Ohniv� koule</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>Kruh ohn�</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Ohniv� proud</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>D鹻 meteorit�</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Inferno</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Zpopeln�n�</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>Magie vzduchu</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>�arod�jovo oko</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Statick� n�boj</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Ochrana p�ed elekt�inou</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Jiskry</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Pe���ko</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>�t�t</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>Blesk</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Skok</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>Imploze</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>L�t�n�</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Hv�zdn� spou��</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>Magie vody</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Procitnut�</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Mraziv� proud</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Ochrana p�ed mrazem</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Jedovat� sprej</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Ch�ze po vod�</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Ledov� hrot</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>O�arovat p�edm�t</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Kyselinov� v�r</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>M�stsk� br�na</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Ledov� �der</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Lloyd�v maj�k</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>Magie zem�</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Omr��en�</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Magick� ��p</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Ochrana p�ed magi�</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Smrt�c� roj</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Kamenn� k��e</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>�epele</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>Odkamen�n�</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Kamenn� v�buch</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>Zkamen�n�</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Kv�t smrti</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Masivn� deformace</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>Magie ducha</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Duchovn� ��p</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Po�ehn�n�</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>L��iv� dotek</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>��astn� den</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Odstran�n� proklet�</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Str�n� and�l</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>Hrdinstv�</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Od�arov�n� nemrtv�ch</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>O�iv mrtv�</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Sd�len� �ivot</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Vzk���en�</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>Magie mysli</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Meditace</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Sejmi strach</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Ment�ln� �der</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>P�esnost</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>Odstra� ochromen�</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Odstra� ochromen�</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>Hromadn� strach</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Oslaben� mysli</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>Odstra� ��lenstv�</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Psychick� �ok</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Telekineze</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>Magie t�la</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Odstra� slabost</td>
         <td>norm�ln�</td>
         <td>100</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Prvn� pomoc</td>
         <td>norm�ln�</td>
         <td>200</td>
         <td>20</td>
      </tr>
      <tr>
         <td>Ochrana p�ed jedem</td>
         <td>norm�ln�</td>
         <td>300</td>
         <td>30</td>
      </tr>
      <tr>
         <td>Zra�</td>
         <td>norm�ln�</td>
         <td>400</td>
         <td>40</td>
      </tr>
      <tr>
         <td>L��ba zran�n�</td>
         <td>expertn�</td>
         <td>500</td>
         <td>50</td>
      </tr>
      <tr>
         <td>L��ba zran�n�</td>
         <td>expertn�</td>
         <td>750</td>
         <td>75</td>
      </tr>
      <tr>
         <td>Rychlost</td>
         <td>expertn�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Uzdrav nemoc</td>
         <td>expertn�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>Moc</td>
         <td>mistrovsk�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Spla�en� p�st</td>
         <td>mistrovsk�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Mocn� l��ba</td>
         <td>mistrovsk�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
   </table>

   <h3>B�l� magie</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Vytvo�en� j�dla</td>
         <td>norm�ln�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Zlat� dotek</td>
         <td>norm�ln�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>Odstran�n� magie</td>
         <td>norm�ln�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>Zpomalen�</td>
         <td>norm�ln�</td>
         <td>2500</td>
         <td>250</td>
      </tr>
      <tr>
         <td>Zni�en� nemrtv�ch</td>
         <td>expertn�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Den Boh�</td>
         <td>expertn�</td>
         <td>3500</td>
         <td>350</td>
      </tr>
      <tr>
         <td>Duhov� sv�tlo</td>
         <td>expertn�</td>
         <td>4000</td>
         <td>400</td>
      </tr>
      <tr>
         <td>Hodina s�ly</td>
         <td>expertn�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
      <tr>
         <td>Paral�za</td>
         <td>mistrovsk�</td>
         <td>6000</td>
         <td>600</td>
      </tr>
      <tr>
         <td>Slune�n� paprsek</td>
         <td>mistrovsk�</td>
         <td>7500</td>
         <td>750</td>
      </tr>
      <tr>
         <td>Bo�sk� z�sah</td>
         <td>mistrovsk�</td>
         <td>10000</td>
         <td>1000</td>
      </tr>
   </table>

   <h3>�ern� magie</h3>

   <table cellspacing="0" cellpadding="3px" width="500px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 150px;">N�zev</td>
         <td style="width: 200px;">�rove� kouzla</td>
         <td style="width: 75px;">Cena knihy</td>
         <td style="width: 75px;">Cena svitku</td>
      </tr>
      <tr>
         <td>Zmrtv�chvst�n�</td>
         <td>norm�ln�</td>
         <td>1000</td>
         <td>100</td>
      </tr>
      <tr>
         <td>Toxick� mrak</td>
         <td>norm�ln�</td>
         <td>1500</td>
         <td>150</td>
      </tr>
      <tr>
         <td>Masov� proklet�</td>
         <td>norm�ln�</td>
         <td>2000</td>
         <td>200</td>
      </tr>
      <tr>
         <td>St�epina</td>
         <td>norm�ln�</td>
         <td>2500</td>
         <td>250</td>
      </tr>
      <tr>
         <td>Smr��ovac� paprsek</td>
         <td>expertn�</td>
         <td>3000</td>
         <td>300</td>
      </tr>
      <tr>
         <td>Den ochrany</td>
         <td>expertn�</td>
         <td>3500</td>
         <td>350</td>
      </tr>
      <tr>
         <td>Dotek Smrti</td>
         <td>expertn�</td>
         <td>4000</td>
         <td>400</td>
      </tr>
      <tr>
         <td>M�s��n� paprsek</td>
         <td>expertn�</td>
         <td>5000</td>
         <td>500</td>
      </tr>
      <tr>
         <td>Dra�� dech</td>
         <td>mistrovsk�</td>
         <td>6000</td>
         <td>600</td>
      </tr>
      <tr>
         <td>Armagedon</td>
         <td>mistrovsk�</td>
         <td>7500</td>
         <td>750</td>
      </tr>
      <tr>
         <td>Temn� tajemstv�</td>
         <td>mistrovsk�</td>
         <td>10000</td>
         <td>1000</td>
      </tr>
   </table>
   
   <p>N�sleduj�c� tabulka uv�d� p�ehled kouzeln�ch h�lek a druh kouzla, kter� v sob� ukr�vaj�. Vztah mezi konkr�tn�m druhem h�lky a v�sledn�m efektem kouzla se mi zat�m nepoda�ilo zcela objasnit, ale z toho, co jsem objevil by se dalo ��ci, �e h�lka ses�l� kouzlo na jeho skute�n� �rovni a jako by m�la hodnotu p��slu�n� dovednosti v rozmez� 6 - 8 bod�. Rozd�len� kouzel podle �rovn� je jen p�ibli�n�, v �est�m d�le nejsou kouzla striktn� rozd�lena.</p>
   
   <h3>Kouzeln� h�lky</h3>

   <table cellspacing="0" cellpadding="3px" width="550px" border="0">
      <tr class="hlavicka_tabulky">
         <td style="width: 175px;">N�zev h�lky</td>
         <td style="width: 120px;">�rove� kouzla</td>
         <td style="width: 180px;">Ses�l�</td>
         <td style="width: 75px;">Cena h�lky</td>
      </tr>
      <tr>
         <td>H�lka ohn�</td>
         <td>norm�ln�</td>
         <td>Ohniv� ��p</td>
         <td>1000</td>
      </tr>
      <tr>
         <td>H�lka statick� elekt�iny</td>
         <td>norm�ln�</td>
         <td>Statick� v�boj</td>
         <td>1000</td>
      </tr>
      <tr>
         <td>H�lka mrazu</td>
         <td>norm�ln�</td>
         <td>Mraziv� proud</td>
         <td>1000</td>
      </tr>
      <tr>
         <td>H�lka omra�ov�n�</td>
         <td>norm�ln�</td>
         <td>Omr��en�</td>
         <td>1000</td>
      </tr>
      <tr>
         <td>H�lka ��p�</td>
         <td>norm�ln�</td>
         <td>Duchovn� ��p</td>
         <td>1000</td>
      </tr>
      <tr>
         <td>�arovn� h�lka ohn�</td>
         <td>norm�ln�</td>
         <td>Ohniv� �ipka</td>
         <td>1500</td>
      </tr>
      <tr>
         <td>�arovn� h�lka jisker</td>
         <td>norm�ln�</td>
         <td>Jiskry</td>
         <td>1500</td>
      </tr>
      <tr>
         <td>�arovn� h�lka jedu</td>
         <td>norm�ln�</td>
         <td>Jedovat� sprej</td>
         <td>1500</td>
      </tr>
      <tr>
         <td>�arovn� h�lka Mysli</td>
         <td>norm�ln�</td>
         <td>Ment�ln� �der</td>
         <td>1500</td>
      </tr>
      <tr>
         <td>�arovn� h�lka zra�ov�n�</td>
         <td>norm�ln�</td>
         <td>Zra�</td>
         <td>1500</td>
      </tr>
      <tr>
         <td>Alakornov� h�lka Ohniv�ch koul�</td>
         <td>expertn�</td>
         <td>Ohniv� koule</td>
         <td>2000</td>
      </tr>
      <tr>
         <td>Alakornov� h�lka Ledu</td>
         <td>expertn�</td>
         <td>Ledov� hrot</td>
         <td>2000</td>
      </tr>
      <tr>
         <td>Alakornov� h�lka Roje</td>
         <td>expertn�</td>
         <td>Smrt�c� roj</td>
         <td>2000</td>
      </tr>
      <tr>
         <td>Alakornov� h�lka �epel�</td>
         <td>expertn�</td>
         <td>�epele</td>
         <td>2000</td>
      </tr>
      <tr>
         <td>Alakornov� h�lka Zaklet�</td>
         <td>expertn�</td>
         <td>�arm</td>
         <td>2000</td>
      </tr>
      <tr>
         <td>Magick� h�lka V�buch�</td>
         <td>expertn�</td>
         <td>Kamenn� v�buch</td>
         <td>2500</td>
      </tr>
      <tr>
         <td>Magick� h�lka Blesk�</td>
         <td>expertn�</td>
         <td>Blesk</td>
         <td>2500</td>
      </tr>
      <tr>
         <td>Magick� h�lka Kamen�</td>
         <td>expertn�</td>
         <td>D鹻 meteorit�</td>
         <td>2500</td>
      </tr>
      <tr>
         <td>Magick� h�lka Paral�zy</td>
         <td>mistrovsk�</td>
         <td>Ochromen�</td>
         <td>2500</td>
      </tr>
      <tr>
         <td>Magick� h�lka Mra�en</td>
         <td>norm�ln�</td>
         <td>Toxick� mrak</td>
         <td>2500</td>
      </tr>
      <tr>
         <td>Mystick� h�lka Imploze</td>
         <td>mistrovsk�</td>
         <td>Imploze</td>
         <td>3000</td>
      </tr>
      <tr>
         <td>Mystick� h�lka Pok�iven�</td>
         <td>mistrovsk�</td>
         <td>Masivn� deformace</td>
         <td>3000</td>
      </tr>
      <tr>
         <td>Mystick� h�lka St�epin</td>
         <td>norm�ln�</td>
         <td>St�epina</td>
         <td>3000</td>
      </tr>
      <tr>
         <td>Mystick� h�lka Smr��ov�n�</td>
         <td>norm�ln�</td>
         <td>Smr��ovac� paprsek</td>
         <td>3000</td>
      </tr>
      <tr>
         <td>Mystick� h�lka Smrti</td>
         <td>mistrovsk�</td>
         <td>Zpopeln�n�</td>
         <td>3000</td>
      </tr>
   </table>

   <div id="copyright">
      <div id="cop">copyright 2002 - 2022 by Petr 'Elemir' Lev�k v�echna pr�va vyhrazena</div>
   </div>

   </div>
</div>
</body>
</html>
